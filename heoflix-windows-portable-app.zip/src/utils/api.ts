/**
 * Safe API response parser to completely eliminate
 * "SyntaxError: Unexpected token '<', ..." and "unexpected JSON input" errors.
 */

export interface SafeApiResponse<T = any> {
  ok: boolean;
  status: number;
  data: T | null;
  error?: string;
}

export async function safeParseResponse<T = any>(res: Response): Promise<SafeApiResponse<T>> {
  try {
    const text = await res.text();
    if (!text || !text.trim()) {
      return {
        ok: res.ok,
        status: res.status,
        data: null,
        error: res.ok ? undefined : `Server returned empty response (Status ${res.status})`,
      };
    }

    // Attempt parsing JSON
    const trimmed = text.trim();
    if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
      try {
        const json = JSON.parse(trimmed);
        return {
          ok: res.ok,
          status: res.status,
          data: json,
          error: json.error || (!res.ok ? `Error ${res.status}` : undefined),
        };
      } catch (parseErr: any) {
        return {
          ok: false,
          status: res.status,
          data: null,
          error: `Failed to parse response: ${parseErr.message}`,
        };
      }
    }

    // Response is not JSON (e.g. HTML from server fallback or 404/500 page)
    return {
      ok: false,
      status: res.status,
      data: null,
      error: res.ok
        ? "Received unexpected non-JSON response from server"
        : `Server returned error page (Status ${res.status}): ${res.statusText}`,
    };
  } catch (err: any) {
    return {
      ok: false,
      status: res.status,
      data: null,
      error: err.message || "Network error while reading server response",
    };
  }
}
