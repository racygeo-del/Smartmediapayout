export type ViewTab =
  | "website"
  | "media_manager"
  | "analytics"
  | "monitor"
  | "wallet"
  | "banking"
  | "brain"
  | "transactions"
  | "tax"
  | "blockchain"
  | "radar"
  | "email"
  | "gateway"
  | "speeches";
export type DeviceViewMode = "desktop" | "ios" | "android";
export type MarketMode = "LIVE_PRODUCTION_MARKET" | "STAGING_SANDBOX";

export interface PresidentialSpeech {
  id: string;
  title: string;
  president: string;
  date: string;
  location: string;
  category:
    | "ECONOMIC_SOVEREIGNTY"
    | "CRYPTO_DIGITAL_ASSETS"
    | "GEOPOLITICAL_DEFENSE"
    | "GLOBAL_TRADE_TARIFFS"
    | "STATE_OF_THE_UNION"
    | "EXECUTIVE_ORDER"
    | "INTERNATIONAL_TREATY";
  globalImpactScore: number; // 1 - 100
  marketsAffected: string[];
  sentiment:
    | "BULLISH_LIQUIDITY"
    | "BEARISH_RESTRICTION"
    | "GEOPOLITICAL_SHOCK"
    | "MACRO_EXPANSION"
    | "HAWKISH_PIVOT"
    | "DOVISH_PIVOT";
  historicalSignificance: string;
  keyQuotes: string[];
  fullTranscript: string;
  policyDirectives: string[];
  marketReaction: string;
  verified: boolean;
  audioDurationMinutes?: number;
}

export interface SecureGatewayApiKey {
  keyId: string;
  apiKey: string;
  type: "LIVE" | "TEST";
  label: string;
  permissions: string[];
  createdAt: string;
  lastUsedAt: string;
  dailyLimitUsd: number;
  status: "ACTIVE" | "REVOKED";
}

export interface CryptoPayoutOrder {
  id: string;
  network: string;
  token: string;
  recipientAddress: string;
  recipientName?: string;
  amount: number;
  amountUsd: number;
  fee: number;
  status: "BROADCASTED" | "CONFIRMED" | "PENDING";
  txid: string;
  timestamp: string;
  explorerUrl: string;
  memo?: string;
}

export interface DomainRegistrationInfo {
  domain: string;
  normalizedFqdn: string;
  isRealWebsite: boolean;
  status: "ACTIVE_DELEGATED" | "ICANN_VERIFIED" | "PRODUCTION_READY";
  ownerName: string;
  ownerEmail: string;
  registrar: string;
  ianaId: string;
  createdDate: string;
  renewalDate: string;
  dnssec: "SIGNED_AND_VALIDATED" | "ACTIVE";
  primaryIp: string;
  nameServers: string[];
  privacyGuard: {
    identityMasked: boolean;
    ipCloaked: boolean;
    locationSpoofed: boolean;
    proxyNetwork: string;
  };
  dnsRecords: {
    type: "A" | "AAAA" | "CNAME" | "TXT" | "CAA" | "MX";
    host: string;
    value: string;
    ttl: number;
    status: "PROPAGATED" | "VERIFIED";
  }[];
  sslCertificate: {
    issuer: string;
    cipher: string;
    protocol: string;
    hsts: boolean;
    validUntil: string;
  };
  regulatoryRegistry: {
    legalEntity: string;
    leiCode: string;
    marketCategory: string;
    clearingHouse: string;
    jurisdiction: string;
  };
  dnsHealth?: DnsHealthState;
  ratification?: DomainRatificationCertificate;
  verificationReport?: DomainVerificationReport;
}

export interface DnsCorrectionEvent {
  id: string;
  timestamp: string;
  errorDetected: string;
  recordType: string;
  host: string;
  previousValue: string;
  correctedValue: string;
  actionTaken: string;
  status: "AUTOMATICALLY_CORRECTED" | "RESOLVED";
}

export interface DnsHealthState {
  status: "HEALTHY_AUTO_CORRECTED" | "VERIFIED" | "SCANNING";
  lastCheckTimestamp: string;
  autoCorrectionEnabled: boolean;
  errorsDetectedCount: number;
  totalCorrectionsApplied: number;
  dnssecValidated: boolean;
  nameserversSynced: boolean;
  activeErrors: string[];
  recentCorrections: DnsCorrectionEvent[];
}

export interface DomainVerificationReport {
  domain: string;
  verifiableInApp: boolean;
  overallScore: number;
  status: "VERIFIED_VALID_COM_DOMAIN";
  verifiedAt: string;
  checks: {
    name: string;
    description: string;
    passed: boolean;
    details: string;
  }[];
  attestationToken: string;
}

export interface DomainRatificationCertificate {
  ratificationId: string;
  ratifiedDomain: string;
  canonicalUrl: string;
  authorizedWebsiteUrl: string;
  status: "RATIFIED_AND_AUTHENTICATED";
  ratifiedAt: string;
  ratifiedBy: string;
  ratificationProtocol: string;
  cryptographicSignature: string;
  sha256Digest: string;
  dnssecVerificationKey: string;
  issuerAuthority: string;
  sovereignOwner: string;
}

export interface FinancialMarketInstrument {
  symbol: string;
  name: string;
  category: "EQUITY_INDEX" | "FOREX" | "COMMODITY" | "DIGITAL_ASSET" | "MEDIA_YIELD";
  price: number;
  currency: string;
  change24h: number;
  changePercent24h: number;
  high24h: number;
  low24h: number;
  volume24h: string;
  orderBookDepth: {
    bids: { price: number; size: number }[];
    asks: { price: number; size: number }[];
  };
  heoflixAdvantage: string;
  executionLatencyMs: number;
  competingBenchmark: string;
}

export interface MarketCompetitiveBenchmark {
  competitor: string;
  category: string;
  heoflixMetric: string;
  competitorMetric: string;
  advantageSummary: string;
  status: "HEOFLIX_SUPERIOR" | "PARITY" | "INNOVATIVE";
}

export interface RadarTarget {
  id: string;
  label: string;
  ip: string;
  mac: string;
  location: string;
  azimuth: number; // 0 to 360 degrees
  distanceRatio: number; // 0.1 to 0.95 relative to radar scope
  threatLevel: "CRITICAL" | "HIGH" | "ELEVATED" | "SAFE" | "SOVEREIGN";
  status: "BLOCKED" | "DISCONNECTED" | "INTERCEPTED" | "ACTIVE" | "WHITELISTED";
  protocol: string;
  packets: number;
  detectedAt: string;
  blockedAt?: string;
  reason: string;
  actionTaken: "AUTO_DISCONNECTED_AND_BLOCKED" | "INTERCEPTED_AND_DROPPED" | "ALLOWED";
}

export interface SatelliteTracker {
  id: string;
  noradId: string;
  name: string;
  constellation: string;
  latitude: number;
  longitude: number;
  altitudeKm: number;
  velocityKmS: number;
  azimuth: number;
  elevation: number;
  frequencyGhz: number;
  band: string;
  snrDb: number;
  latencyMs: number;
  encryption: string;
  downlinkHealth: "NOMINAL" | "HIGH_THROUGHPUT" | "ORBITAL_PASS";
  packetsRelayed: number;
  footprintRadiusKm: number;
}

export interface CyberInfiltrationIncident {
  id: string;
  timestamp: string;
  sourceIp: string;
  originCountry: string;
  continent: "North America" | "South America" | "Europe" | "Asia" | "Africa" | "Oceania" | "Global Orbit";
  coordinates: { lat: number; lng: number };
  softwareClass: string;
  vector: string;
  targetEndpoint: string;
  severity: "EXTREME" | "CRITICAL" | "HIGH";
  deflectionLatencyMs: number;
  quarantineStatus: "BLACKHOLED_AND_PURGED" | "SOCKET_TERMINATED" | "PERMANENT_IP_QUARANTINE";
  fingerprintHash: string;
}

export interface PlanetaryInfiltrationShieldState {
  shieldStatus: "PLANETARY_LOCKDOWN_ACTIVE" | "AUTONOMOUS_INTERCEPTION" | "ELEVATED_DEFENSE";
  deepPacketInspectionActive: boolean;
  antiSpywareGuardActive: boolean;
  botnetScramblerActive: boolean;
  totalInfiltrationsDeflected: number;
  globalActiveQuarantines: number;
  continentsCoverage: {
    continent: string;
    deflectedCount: number;
    threatIndex: number;
    status: "SECURED" | "SHIELDED" | "IMMUNE";
  }[];
  recentInfiltrationAttacks: CyberInfiltrationIncident[];
  sovereignNodeImmunity: {
    nodeHolder: string;
    email: string;
    status: "PERMANENT_SOVEREIGN_IMMUNITY";
    authClearance: string;
  };
}

export interface SecurityRadarSystemState {
  radarActive: boolean;
  autoProtectEnabled: boolean;
  autoDisconnectIntruders: boolean;
  autoBlockIps: boolean;
  totalProbesDetected: number;
  totalIntrudersBlocked: number;
  activeSatellitesTracked: number;
  defenseShieldLevel: "MAXIMUM_LOCKDOWN" | "AUTONOMOUS_DEFENSE" | "MONITOR_ONLY";
  planetaryShield: PlanetaryInfiltrationShieldState;
  targets: RadarTarget[];
  satellites: SatelliteTracker[];
  interceptLog: {
    id: string;
    timestamp: string;
    event: string;
    ip: string;
    severity: "CRITICAL" | "HIGH" | "INFO";
    action: string;
  }[];
}

export interface MarketOperationStatus {
  mode: MarketMode;
  status: "OPERATIONAL" | "INITIALIZING" | "MAINTENANCE";
  launchedAt: string;
  launchOperator: string;
  marketVenue: string;
  networkTier: string;
  settlementCorridors: {
    corridor: string;
    protocol: string;
    status: string;
    latencyMs: number;
    destinationHolder: string;
  }[];
  liveFxBenchmark: {
    usdNgn: number;
    spread: number;
    lastUpdated: string;
    source: string;
  };
  launchCertificate: {
    certificateId: string;
    merkleRoot: string;
    signature: string;
    issuedTo: string;
    complianceStandard: string;
  };
}

export interface BlockchainTransaction {
  id: string;
  from: string;
  to: string;
  amount: number;
  currency: string;
  memo: string;
  signature?: string;
  timestamp: string;
  status: "CONFIRMED" | "PENDING";
}

export interface NativeBlockchainBlock {
  index: number;
  timestamp: string;
  previousHash: string;
  hash: string;
  nonce: number;
  difficulty: number;
  merkleRoot: string;
  transactions: BlockchainTransaction[];
  miner: string;
  gasUsed: number;
  blockSizeBytes: number;
}

export interface GeneratedSecretKeyData {
  algorithm: "secp256k1" | "ed25519" | "bip39" | "aes256";
  secretKey: string;
  publicKey: string;
  address: string;
  mnemonic?: string;
  fingerprint: string;
  entropyBits: number;
  strength: "Weak" | "Good" | "Military-Grade 256-Bit";
  derivedFromCustomPassphrase: boolean;
  passphraseHint?: string;
  createdAt: string;
}

export interface GlobalServerNode {
  id: string;
  name: string;
  category: "CENTRAL_BANK" | "SWITCH_NETWORK" | "CROSS_BORDER" | "CLEARING_HOUSE" | "LEDGER";
  location: string;
  region: string;
  host: string;
  status: "ONLINE" | "SYNCHRONIZED" | "HEALING" | "ACTIVE";
  latencyMs: number;
  protocol: string;
  supportedRails: string[];
  encryption: string;
  uptimePercentage: number;
  lastHeartbeat: string;
}

export interface WorldBankEntry {
  code: string;
  name: string;
  swift: string;
  country: string;
  currency: string;
  rail: string;
  isPopular?: boolean;
}

export interface BrainExecutionStep {
  step: string;
  status: "COMPLETED" | "ACTIVE" | "PENDING";
  latencyMs: number;
  details: string;
}

export interface BrainCommandResult {
  success: boolean;
  commandExecuted?: string;
  intent?: string;
  actionSummary?: string;
  confidenceScore?: number;
  executionSteps?: BrainExecutionStep[];
  transaction?: Transaction;
  auditBlock?: any;
  wallet?: WalletState;
  serverNode?: string;
  servers?: GlobalServerNode[];
  timestamp?: string;
  error?: string;
}

export interface BankAccount {
  id: string;
  accountName: string;
  bankName: string;
  accountNumber: string;
  accountNumberMasked: string;
  routingNumber?: string;
  country: string;
  network: string;
  currency: string;
  isPrimary: boolean;
  status: string;
}

export interface CryptoWalletConfig {
  id: string;
  label: string;
  token: "USDT" | "USDC" | "BTC" | "ETH" | "SOL";
  network: "TRC20" | "ERC20" | "SOL" | "POLYGON" | "ARBITRUM" | "BITCOIN";
  address: string;
  isPrimary?: boolean;
}

export interface WalletState {
  totalBalance: number;
  availableBalance: number;
  pendingSettlement: number;
  adminReserve: number;
  lifetimeEarnings: number;
  autoGenerateRatePerHour: number;
  autoGenerateEnabled: boolean;
  lastAccrualTimestamp: string;
  adminAllocationPercentage: number;
  connectedBankAccount: {
    accountName: string;
    bankName: string;
    routingNumber: string;
    accountNumber: string;
    accountNumberMasked: string;
    country: string;
    network: string;
    currency?: string;
    status: string;
  };
  savedBankAccounts?: BankAccount[];
  savedCryptoWallets?: CryptoWalletConfig[];
  dailyAccruedFund?: number;
  autoAddDailyAccrued?: boolean;
  autoReserveDailyAccrued?: boolean;
  dailyReservePercentage?: number;
  totalDollarsReserved?: number;
  lastDailyAccruedAddedTimestamp?: string;
  lastDailyAccruedAddedAmount?: number;
  lastDailyReserveAddedTimestamp?: string;
  lastDailyReserveAddedAmount?: number;
  retentionPolicy?: string;
  acceptAnyAmountEnabled?: boolean;
  maxWalletRetentionLimit?: string;
}

export interface AdminFundStats {
  dailyYieldRate: number;
  totalGeneratedThisWeek: number;
  adminVaultShare: number;
  operationalReserveShare: number;
  payoutCadence: string;
}

export interface Transaction {
  id: string;
  timestamp: string;
  type: "EARNING_AUTO" | "PUSH_CREDIT" | "TAX_WITHHOLDING" | "ADMIN_FEE" | "SPONSOR_PAYOUT" | "DIRECT_DEPOSIT";
  platform?: string;
  title: string;
  amount: number;
  status: "COMPLETED" | "SETTLED" | "PROCESSING" | "CLEARED";
  referenceId: string;
  bankNetwork?: string;
  recipientAccount?: string;
  authMethod: "BIOMETRIC" | "PASSWORD_LEAHUS" | "AUTOMATED_RULE";
  taxDeductible?: boolean;
}

export interface AuditBlock {
  index: number;
  timestamp: string;
  previousHash: string;
  hash: string;
  action: string;
  amount: number;
  currency: string;
  actor: string;
  recipient: string;
  bankNetwork: string;
  encryptionPayload: {
    algorithm: string;
    authTag: string;
    keyFingerprint: string;
  };
  signature: string;
}

export interface SocialPlatform {
  id: string;
  name: string;
  handle: string;
  status: "CONNECTED" | "SYNCING" | "DISCONNECTED";
  followers: number;
  weeklyViews: number;
  weeklyRevenue: number;
  icon: string;
  monetizationActive: boolean;
  rpm: number;
}

export interface PostOwnerInfo {
  creatorId: string;
  creatorName: string;
  handle: string;
  verifiedStatus: boolean;
  avatarUrl?: string;
  location: string; // Strictly hidden/redacted: "[LOCATION HIDDEN - SHIELD ACTIVE]"
  realLocationProtected: string; // Protected internal reference
  role: string;
  isIdentifiedByAdmin?: boolean;
}

export interface PostTimestampMetadata {
  isoString: string;
  year: number;
  month: string;
  monthNum: number;
  day: number;
  time: string;
  formatted: string;
}

export interface VideoContent {
  id: string;
  title: string;
  platform: "youtube" | "tiktok" | "instagram" | "x" | "twitch" | "facebook" | "vimeo" | "rss";
  thumbnail: string;
  uploadDate: string;
  duration: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  retentionRate: number;
  hookScore: number;
  sentiment: "Positive" | "Very Positive" | "Neutral" | "Mixed";
  revenueGenerated: number;
  topic: string;
  owner?: PostOwnerInfo;
  postTimestamp?: PostTimestampMetadata;
  videoUrl?: string;
  embedUrl?: string;
  isFavorite?: boolean;
  watchTimeHours?: number;
  avgViewDurationSec?: number;
  cpm?: number;
  verifiedAdPayout?: number;
  importSource?: "MANUAL" | "RSS" | "URL_IMPORT" | "SYSTEM";
  rssFeedUrl?: string;
  notes?: string;
}

export interface TrendingAiVideo {
  id: string;
  title: string;
  platform: "youtube" | "tiktok" | "instagram" | "x" | "twitch";
  channelName: string;
  thumbnail: string;
  duration: string;
  views24h: number;
  likes: number;
  comments: number;
  shares: number;
  hookScore: number;
  retentionRate: number;
  projectedRevenue: number;
  viralVelocity: string;
  viralScore: number;
  topic: string;
  aiTrendCategory: "Autonomous Agents" | "Generative Video" | "AI Fintech" | "Coding & LLMs" | "Robotics";
  aiSummary: string;
  hookScript: string;
  videoUrl: string;
  embedUrl: string;
  cpm: number;
  isAddedToCatalog?: boolean;
  discoveredDate: string;
}

export interface DailyAiTrendingSummary {
  lastUpdated: string;
  totalTrackedVideos: number;
  total24hViewsTracked: number;
  projectedTotalYield: number;
  topTrendCategory: string;
  aiMarketIntelligence: string;
  isAutoSyncEnabled: boolean;
}

export interface VideoAnalysis {
  videoId: string;
  title: string;
  platform: string;
  executiveSummary: string;
  hookAnalysis?: string;
  retentionInsights?: string;
  keyStrengths: string[];
  growthOpportunities: string[];
  viralProbabilityScore: number;
  monetizationProjectionNext30Days: number;
  recommendedTags?: string[];
  isAiGenerated: boolean;
}

export interface WeeklyReport {
  title: string;
  timeframe: string;
  generatedAt: string;
  executiveSummary: string;
  keyHighlights: string[];
  topContentPerformers: Array<{
    title: string;
    platform: string;
    revenue: string;
    views: string;
  }>;
  monetizationAndYieldAudit: {
    grossMonetization: number;
    adminShare: number;
    reserveAllocated: number;
    estimatedTaxWithheld: number;
    pushCreditReady: number;
  };
  actionPlanNextWeek: string[];
  isAiGenerated: boolean;
}

export interface TaxReport {
  grossRevenue: number;
  totalDeductions: number;
  netScheduleCProfit: number;
  expensesBreakdown: Record<string, number>;
  taxBreakdown: {
    selfEmploymentTax: number;
    federalIncomeTax: number;
    stateTax: number;
    totalTaxObligation: number;
    effectiveTaxRatePercent: number;
  };
  quarterlyDeadlines: Array<{
    quarter: string;
    dueDate: string;
    amount: number;
    status: string;
  }>;
  form1099NECSummary: {
    payer: string;
    recipient: string;
    box1NonemployeeCompensation: number;
    federalTaxWithheld: number;
    stateTaxWithheld: number;
  };
}

export interface CryptoAddressVerification {
  token: string;
  name: string;
  network: string;
  address: string;
  standard: string;
  isPrimary: boolean;
  status: "VERIFIED_VALID_MAINNET" | "PENDING" | "UNVERIFIED";
  checksumValid: boolean;
  explorerUrl: string;
  mempoolUrl?: string;
  supportedPlatforms: string[];
  exchangeComplianceScore: number;
  depositClearance: string;
  lastVerifiedAt: string;
  certificateId: string;
}

export interface FingerprintHardwareInfo {
  detected: boolean;
  sensorName: string;
  sensorType: "CAPACITIVE" | "OPTICAL" | "ULTRASONIC" | "TOUCH_ID" | "WINDOWS_HELLO" | "FIDO2";
  busInterface: string;
  enclaveType: string;
  enclaveReady?: boolean;
  securityRating: string;
  webAuthnPlatformSupported: boolean;
  conditionalMediation: boolean;
  status: "ONLINE" | "READY" | "SCANNING" | "AUTHENTICATED";
  lastScanTimestamp?: string;
  diagnosticDetails?: string;
}

export interface BiometricPreference {
  enabled: boolean;
  autoAuthorizeTransfers: boolean;
  vaultUnlockEnabled: boolean;
  authenticatorType: "TOUCH_ID" | "FACE_ID" | "WINDOWS_HELLO" | "FIDO2" | "GENERIC";
  lastVerifiedAt?: string;
  deviceLabel?: string;
}

export type ThemeMode = "neuro_dark" | "cyber_blue" | "crimson_pulse" | "obsidian_glass";
export type BrandIconChoice = "neuro_tricolor" | "classic_h" | "pulse_orb";
export type UiDensity = "comfortable" | "compact" | "spacious";
export type FontScale = "compact" | "normal" | "large";
export type AccentGlow = "tricolor" | "blue" | "crimson" | "white";
export type CurrencyChoice = "USD" | "EUR" | "GBP" | "NGN" | "BTC";

export interface InterlinkedFunctions {
  marketExchangeSync: boolean;
  videoYieldHarvestingSync: boolean;
  treasuryAutoAccrualSync: boolean;
  planetaryDefenseSentinelSync: boolean;
  cortexAiBrainSync: boolean;
}

export interface LiveInterlinkStats {
  activeSyncNodes: number;
  syncLatencyMs: number;
  overallThroughput: string;
  lastSyncTimestamp: string;
  healthStatus: "OPTIMAL" | "SYNCED" | "STANDBY";
}

export interface AppSettings {
  themeMode: ThemeMode;
  brandIcon: BrandIconChoice;
  accentGlow: AccentGlow;
  uiDensity: UiDensity;
  fontScale: FontScale;
  motionEffects: boolean;
  soundEffects: boolean;
  autoMonetizationSpeedSec: number;
  defaultCurrency: CurrencyChoice;
  interlinkedFunctions: InterlinkedFunctions;
  liveInterlinkStats: LiveInterlinkStats;
  lastUpdated: string;
}

export interface DailyDataAnalysisReport {
  id: string;
  title: string;
  reportDate: string;
  reportTime: string;
  reportMonth: string;
  reportYear: number;
  generatedAtFormatted: string;
  totalPostsAnalyzed: number;
  totalDailyViews: number;
  estimatedDailyRevenue: number;
  posts: {
    id: string;
    title: string;
    platform: string;
    postDate: string;
    postTime: string;
    postMonth: string;
    postYear: number;
    views: number;
    engagementRate: number;
    retentionRate: number;
    yieldUsd: number;
  }[];
}

export interface SocialAnalyticsAutoDownloadConfig {
  enabled: boolean;
  defaultFormat: "json" | "csv" | "txt" | "all";
  autoDownloadOnDailyAnalysis: boolean;
  autoDownloadOnWeeklyReport: boolean;
  lastDownloadedAt?: string;
  downloadCount: number;
}

export interface SeparatedPlatformReport {
  platformId: string;
  platformName: string;
  reportId: string;
  generatedAt: string;
  totalPosts: number;
  totalViews: number;
  totalLikes: number;
  totalComments: number;
  totalShares: number;
  avgEngagementRate: number;
  avgRetentionRate: number;
  estimatedYieldUsd: number;
  rpmRateUsd: number;
  topPerformingPost: {
    id: string;
    title: string;
    views: number;
    yieldUsd: number;
    engagementRate: number;
  } | null;
  posts: {
    id: string;
    title: string;
    postDate: string;
    postTime: string;
    views: number;
    likes: number;
    comments: number;
    shares: number;
    retentionRate: number;
    engagementRate: number;
    yieldUsd: number;
  }[];
}

export interface SocialSearchTrackResult {
  searchId: string;
  query: string;
  searchedAt: string;
  platformScope: string;
  discoveredPostsCount: number;
  aggregateReach: number;
  trendMomentumScore: number;
  averageEngagement: number;
  generatedFundsUsd: number;
  monetizationStatus: "CREDITED_TO_DOLLAR_WALLET";
  walletTransactionId: string;
  topInsights: string[];
  trendingKeywords: string[];
}

export interface IcannVerificationReport {
  verificationId: string;
  domainName: string;
  canonicalUrl: string;
  targetEmail: string;
  verifiedAt: string;
  status: "VERIFIED_COMPLIANT";
  icannRegistrySeal: string;
  accreditedRegistrar: string;
  whoisValidation: {
    registrant: string;
    registrantEmail: string;
    country: string;
    status: string;
  };
  dnssecVerification: {
    dsRecordStatus: string;
    algorithm: string;
    keyTag: number;
    digestType: string;
  };
  emailDispatchReceipt: {
    dispatchedTo: string;
    dispatchTimestamp: string;
    messageId: string;
    deliveryStatus: "DELIVERED";
    deliveryGateway: string;
  };
  complianceHash: string;
}

export interface NodeOwnerControlStatus {
  ownerName: string;
  ownerEmail: string;
  absoluteAccessLevel: "MAXIMUM_SOVEREIGN_ROOT";
  nodeEngineAuthority: "ABSOLUTE_SYSTEM_OWNER";
  nodeVersion: string;
  platform: string;
  uptimeSeconds: number;
  activeMemoryMb: number;
  pid: number;
  privileges: string[];
  securityStatus: "OWNER_ABSOLUTE_CONTROL_ACTIVE";
  lastVerifiedAt: string;
}

export interface AutoRestrictionBypassState {
  enabled: boolean;
  mode: string;
  ownerEmail: string;
  ownerName: string;
  bypassedRestrictions: string[];
  lastBypassTriggeredAt: string;
  bypassCount: number;
  status: "ACTIVE_UNRESTRICTED" | "STANDBY";
}

export interface Dns8888LinkerState {
  targetDomain: string;
  canonicalWwwDomain: string;
  primaryResolver: string;
  secondaryResolver: string;
  resolverProvider: string;
  dohEndpoint: string;
  nxdomainStatus: "LINKED_TO_APP_HOST" | "RESOLVING" | "DISCONNECTED";
  bridgeMode: string;
  appHostUrl: string;
  resolvedAnycastIps: string[];
  cnameTarget: string;
  lastLinkedAt: string;
  dns8888QueryCount: number;
  upstreamDnsLatencyMs: number;
  dnssecAttestation: string;
  activeLinks: {
    sourceQuery: string;
    originalDnsResponse: string;
    linkedAction: string;
    routedTarget: string;
    status: string;
  }[];
}

export interface EmailMessage {
  id: string;
  from: string;
  fromName: string;
  to: string;
  toName?: string;
  subject: string;
  body: string;
  bodyHtml?: string;
  date: string;
  read: boolean;
  starred: boolean;
  folder: "inbox" | "sent" | "drafts" | "trash" | "starred";
  category: "SYSTEM" | "ICANN" | "BANKING" | "TRANSACTION" | "GENERAL" | "SECURITY";
  securityAttestation?: {
    dkim: "PASS" | "FAIL";
    spf: "PASS" | "FAIL";
    dmarc: "PASS" | "FAIL";
    tlsVersion: "TLS 1.3" | "TLS 1.2";
  };
  attachments?: {
    filename: string;
    sizeKb: number;
    mimeType: string;
  }[];
}

export interface EmailSystemStatus {
  connected: boolean;
  ownerEmail: string;
  activeDomain: string;
  smtpRelay: string;
  imapServer: string;
  unreadCount: number;
  totalReceived: number;
  totalSent: number;
  lastSyncAt: string;
  undergroundDaemonActive: boolean;
  daemonIntervalSeconds: number;
  dkimStatus: string;
  spfStatus: string;
  dmarcPolicy: string;
}

export interface NodeUndergroundLogicState {
  daemonStatus: "RUNNING_UNDERGROUND" | "IDLE" | "ERROR";
  pid: number;
  uptimeSeconds: number;
  nodeVersion: string;
  platform: string;
  activeMemoryMb: number;
  registeredWorkers: {
    id: string;
    name: string;
    frequencySeconds: number;
    lastExecutedAt: string;
    totalRuns: number;
    status: "HEALTHY" | "ACTIVE";
  }[];
  recentEvents: {
    timestamp: string;
    worker: string;
    action: string;
    details: string;
  }[];
}

// ============================================================================
// API GATEWAY, TRAFFIC CONTROLLER & PAYMENT RAILS TYPES
// ============================================================================

export type PaymentRailType =
  | "FEDNOW_RTP_US"
  | "ACH_FEDWIRE_US"
  | "SEPA_INSTANT_EU"
  | "FASTER_PAYMENTS_UK"
  | "NIP_PAYSTACK_NIGERIA"
  | "BITCOIN_BLOCKCYPHER"
  | "LIGHTNING_NETWORK"
  | "VISA_MASTERCARD_PUSH";

export type TrafficPriority = "CRITICAL_FINANCIAL" | "STANDARD_API" | "BACKGROUND_BATCH";

export type TrafficControllerMode =
  | "AUTONOMOUS_ADAPTIVE"
  | "ENFORCED_BALANCED"
  | "EMERGENCY_PROTECTION";

export interface PaymentRailStatus {
  id: PaymentRailType;
  name: string;
  region: string;
  supportedCurrencies: string[];
  settlementTime: string;
  status: "ONLINE_ACTIVE" | "DEGRADED" | "CIRCUIT_BROKEN";
  avgLatencyMs: number;
  successRate: number;
  baseFee: number;
  variableFeePercent: number;
  maxSingleLimit: number;
  redundantBackupRail: PaymentRailType;
  dailyVolumeRouted: number;
  totalOrdersCount: number;
  endpointSwitch: string;
}

export interface RoutedTransferOrder {
  id: string;
  trackingNumber: string;
  timestamp: string;
  amount: number;
  currency: string;
  recipientName: string;
  recipientAccount: string;
  destinationBankOrNetwork: string;
  selectedRail: PaymentRailType;
  railName: string;
  routingReason: string;
  fallbackUsed: boolean;
  status: "ROUTED_PENDING" | "SETTLED_INSTANT" | "PROCESSING" | "COMPLETED";
  estimatedSettlement: string;
  fee: number;
  idempotencyKey: string;
  trafficPriority: TrafficPriority;
  latencyMs: number;
  cryptographicReceipt: string;
}

export interface TrafficControllerState {
  mode: TrafficControllerMode;
  isExecutionEnabled: boolean;
  lastInterventionExecutedAt: string;
  activeConnections: number;
  currentRps: number;
  peakRps: number;
  avgLatencyMs: number;
  queueDepth: number;
  maxQueueCapacity: number;
  totalRequestsProcessed: number;
  throttledRequestsCount: number;
  loadSheddingActive: boolean;
  rateLimitPerMinute: {
    CRITICAL_FINANCIAL: number;
    STANDARD_API: number;
    BACKGROUND_BATCH: number;
  };
  burstCapacity: {
    CRITICAL_FINANCIAL: number;
    STANDARD_API: number;
    BACKGROUND_BATCH: number;
  };
  circuitBreakerThresholdFailures?: number;
  circuitBreakerCooldownSeconds?: number;
}

export interface TrafficExecutionLog {
  id: string;
  timestamp: string;
  eventType: "PAYLOAD_VALIDATED" | "TRAFFIC_THROTTLED" | "RAIL_ROUTED" | "CIRCUIT_BREAKER" | "INTERVENTION_EXECUTED";
  severity: "INFO" | "WARN" | "CRITICAL" | "SUCCESS";
  clientIp: string;
  endpoint: string;
  details: string;
}


