import React, { useState, useEffect, useRef } from "react";
import { RadarTarget, SatelliteTracker, SecurityRadarSystemState, CyberInfiltrationIncident } from "../types";
import {
  Radar,
  Satellite,
  ShieldCheck,
  ShieldAlert,
  Zap,
  Lock,
  Radio,
  Crosshair,
  AlertTriangle,
  RefreshCw,
  Trash2,
  CheckCircle2,
  XCircle,
  Terminal,
  Activity,
  Globe,
  Wifi,
  WifiOff,
  Search,
  ExternalLink,
  Flame,
  ArrowRight,
  Cpu,
  Layers,
  Sparkles,
  Server,
  Eye,
  Key,
} from "lucide-react";

export const SecurityRadar: React.FC = () => {
  const [telemetry, setTelemetry] = useState<SecurityRadarSystemState | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<"planetary" | "radar" | "satellites" | "firewall" | "logs">("planetary");
  const [selectedTarget, setSelectedTarget] = useState<RadarTarget | null>(null);
  const [selectedSat, setSelectedSat] = useState<SatelliteTracker | null>(null);
  const [selectedIncident, setSelectedIncident] = useState<CyberInfiltrationIncident | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulatingWeapon, setSimulatingWeapon] = useState<string | null>(null);
  const [isPurging, setIsPurging] = useState<boolean>(false);
  const [pingResult, setPingResult] = useState<string | null>(null);
  const [filterQuery, setFilterQuery] = useState<string>("");
  const [actionAlert, setActionAlert] = useState<{ type: "success" | "danger" | "info"; msg: string } | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const sweepAngleRef = useRef<number>(0);
  const animationFrameRef = useRef<number | null>(null);

  // Fetch telemetry from server
  const fetchTelemetry = async () => {
    try {
      const res = await fetch("/api/v1/security/radar-telemetry");
      const data = await res.json();
      if (data.success && data.telemetry) {
        setTelemetry(data.telemetry);
        if (!selectedSat && data.telemetry.satellites?.length > 0) {
          setSelectedSat(data.telemetry.satellites[0]);
        }
      }
    } catch {
      // ignore
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTelemetry();
    const interval = setInterval(fetchTelemetry, 3500);
    return () => clearInterval(interval);
  }, []);

  // Radar Canvas rendering loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let running = true;

    const render = () => {
      if (!running) return;

      const width = canvas.width;
      const height = canvas.height;
      const centerX = width / 2;
      const centerY = height / 2;
      const maxRadius = Math.min(centerX, centerY) - 20;

      // Clear with dark tech background
      ctx.fillStyle = "#0B0F19";
      ctx.fillRect(0, 0, width, height);

      // Radar Grid - Background Rings
      ctx.lineWidth = 1;
      const rings = [0.25, 0.5, 0.75, 1.0];
      const ringLabels = ["100km", "500km", "2500km", "LEO Orbit"];

      rings.forEach((ratio, idx) => {
        const r = maxRadius * ratio;
        ctx.strokeStyle = idx === 3 ? "rgba(56, 189, 248, 0.4)" : "rgba(14, 165, 233, 0.15)";
        ctx.beginPath();
        ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
        ctx.stroke();

        // Ring label
        ctx.fillStyle = "rgba(125, 211, 252, 0.45)";
        ctx.font = "10px monospace";
        ctx.fillText(ringLabels[idx], centerX + 6, centerY - r + 12);
      });

      // Azimuth crosshairs
      ctx.strokeStyle = "rgba(14, 165, 233, 0.2)";
      ctx.beginPath();
      // Vertical line
      ctx.moveTo(centerX, centerY - maxRadius);
      ctx.lineTo(centerX, centerY + maxRadius);
      // Horizontal line
      ctx.moveTo(centerX - maxRadius, centerY);
      ctx.lineTo(centerX + maxRadius, centerY);
      // Diagonals
      const diag = maxRadius * 0.7071;
      ctx.moveTo(centerX - diag, centerY - diag);
      ctx.lineTo(centerX + diag, centerY + diag);
      ctx.moveTo(centerX - diag, centerY + diag);
      ctx.lineTo(centerX + diag, centerY - diag);
      ctx.stroke();

      // Cardinal degrees text
      ctx.fillStyle = "#38BDF8";
      ctx.font = "bold 11px monospace";
      ctx.textAlign = "center";
      ctx.fillText("000° [N]", centerX, centerY - maxRadius - 6);
      ctx.fillText("090° [E]", centerX + maxRadius + 14, centerY + 4);
      ctx.fillText("180° [S]", centerX, centerY + maxRadius + 15);
      ctx.fillText("270° [W]", centerX - maxRadius - 14, centerY + 4);

      // Rotating Sweep Beam
      sweepAngleRef.current = (sweepAngleRef.current + 0.025) % (Math.PI * 2);
      const angle = sweepAngleRef.current;

      // Draw sweeping sector gradient
      const sweepGrad = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, maxRadius);
      sweepGrad.addColorStop(0, "rgba(56, 189, 248, 0.35)");
      sweepGrad.addColorStop(1, "rgba(56, 189, 248, 0.0)");

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, maxRadius, angle - 0.4, angle, false);
      ctx.closePath();
      ctx.fillStyle = sweepGrad;
      ctx.fill();

      // Sweep leading line
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(centerX + Math.cos(angle) * maxRadius, centerY + Math.sin(angle) * maxRadius);
      ctx.strokeStyle = "#38BDF8";
      ctx.lineWidth = 2;
      ctx.shadowColor = "#38BDF8";
      ctx.shadowBlur = 10;
      ctx.stroke();
      ctx.restore();

      // Draw Targets
      if (telemetry?.targets) {
        telemetry.targets.forEach((tgt) => {
          // Convert azimuth to radians (0° is North, so subtract PI/2)
          const rad = (tgt.azimuth - 90) * (Math.PI / 180);
          const dist = maxRadius * tgt.distanceRatio;
          const targetX = centerX + Math.cos(rad) * dist;
          const targetY = centerY + Math.sin(rad) * dist;

          // Check angle proximity to sweep line for radar echo illumination
          const angleDiff = Math.abs((angle - rad + Math.PI * 3) % (Math.PI * 2) - Math.PI);
          const isIlluminated = angleDiff < 0.45;

          ctx.save();
          if (tgt.threatLevel === "SOVEREIGN") {
            // Sovereign Primary Node (George Felix) - Cyan diamond
            ctx.fillStyle = isIlluminated ? "#38BDF8" : "rgba(56, 189, 248, 0.8)";
            ctx.strokeStyle = "#38BDF8";
            ctx.lineWidth = 2;
            ctx.shadowColor = "#38BDF8";
            ctx.shadowBlur = isIlluminated ? 18 : 6;

            ctx.beginPath();
            ctx.moveTo(targetX, targetY - 8);
            ctx.lineTo(targetX + 8, targetY);
            ctx.lineTo(targetX, targetY + 8);
            ctx.lineTo(targetX - 8, targetY);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Label
            ctx.fillStyle = "#E0F2FE";
            ctx.font = "bold 9px monospace";
            ctx.fillText("SOVEREIGN PRIMARY [LOCATION CLOAKED]", targetX, targetY - 12);
          } else if (tgt.threatLevel === "SAFE") {
            // Safe Clearing Switch - Green circle
            ctx.fillStyle = "#10B981";
            ctx.strokeStyle = "#059669";
            ctx.lineWidth = 1.5;
            ctx.beginPath();
            ctx.arc(targetX, targetY, 6, 0, Math.PI * 2);
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = "#6EE7B7";
            ctx.font = "9px monospace";
            ctx.fillText("NIP CLEARING", targetX, targetY - 10);
          } else {
            // INTRUDER / HOSTILE / BLOCKED - Red triangle + crosshair
            const isBlocked = tgt.status === "BLOCKED";
            ctx.fillStyle = isBlocked ? "#EF4444" : "#F97316";
            ctx.strokeStyle = isBlocked ? "#DC2626" : "#EA580C";
            ctx.lineWidth = 2;
            ctx.shadowColor = "#EF4444";
            ctx.shadowBlur = isIlluminated ? 20 : 8;

            ctx.beginPath();
            ctx.moveTo(targetX, targetY - 7);
            ctx.lineTo(targetX + 7, targetY + 6);
            ctx.lineTo(targetX - 7, targetY + 6);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Pulsing Ring around blocked targets
            ctx.beginPath();
            ctx.arc(targetX, targetY, 11, 0, Math.PI * 2);
            ctx.strokeStyle = "rgba(239, 68, 68, 0.5)";
            ctx.stroke();

            // Status Tag
            ctx.fillStyle = isBlocked ? "#FCA5A5" : "#FDBA74";
            ctx.font = "bold 9px monospace";
            ctx.fillText(isBlocked ? "[BLOCKED]" : "[PROBE]", targetX, targetY - 11);
          }
          ctx.restore();
        });
      }

      // Draw Orbiting Satellites on outer rim
      if (telemetry?.satellites) {
        telemetry.satellites.forEach((sat, i) => {
          const satDist = maxRadius * (0.85 + (i % 2) * 0.1);
          const satRad = (sat.azimuth - 90) * (Math.PI / 180);
          const satX = centerX + Math.cos(satRad) * satDist;
          const satY = centerY + Math.sin(satRad) * satDist;

          ctx.save();
          ctx.fillStyle = "#A855F7";
          ctx.strokeStyle = "#C084FC";
          ctx.lineWidth = 1.5;
          ctx.shadowColor = "#C084FC";
          ctx.shadowBlur = 12;

          // Satellite box icon
          ctx.fillRect(satX - 4, satY - 4, 8, 8);
          // Solar panels
          ctx.strokeStyle = "#38BDF8";
          ctx.strokeRect(satX - 10, satY - 2, 5, 4);
          ctx.strokeRect(satX + 5, satY - 2, 5, 4);

          ctx.fillStyle = "#E9D5FF";
          ctx.font = "8px monospace";
          ctx.fillText(`SAT-${sat.noradId.slice(-4)}`, satX, satY + 14);
          ctx.restore();
        });
      }

      // Center Node (Radar Origin Base)
      ctx.beginPath();
      ctx.arc(centerX, centerY, 5, 0, Math.PI * 2);
      ctx.fillStyle = "#38BDF8";
      ctx.shadowColor = "#38BDF8";
      ctx.shadowBlur = 10;
      ctx.fill();

      animationFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      running = false;
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [telemetry]);

  // Handle Auto-Protect Toggle
  const handleToggleAutoProtect = async () => {
    if (!telemetry) return;
    const nextState = !telemetry.autoProtectEnabled;

    try {
      const res = await fetch("/api/v1/security/radar/auto-protect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          enabled: nextState,
          autoDisconnect: nextState,
          autoBlock: nextState,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setActionAlert({
          type: nextState ? "success" : "info",
          msg: nextState
            ? "Autonomous Intruder Defense ACTIVE: Auto-Disconnect & Permanent IP Quarantine enabled!"
            : "Autonomous Defense switched to Monitor-Only Mode.",
        });
        fetchTelemetry();
      }
    } catch {
      // ignore
    }
  };

  // Disconnect & Block Intruder
  const handleDisconnectAndBlock = async (target: RadarTarget) => {
    try {
      const res = await fetch("/api/v1/security/radar/disconnect-and-block", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetId: target.id,
          ip: target.ip,
          reason: "Manual Sovereign Disconnect & Block",
        }),
      });
      const data = await res.json();
      if (data.success) {
        setActionAlert({
          type: "danger",
          msg: `Intruder ${target.ip} successfully disconnected and added to permanent blocklist.`,
        });
        fetchTelemetry();
      }
    } catch {
      // ignore
    }
  };

  // Unblock Host
  const handleUnblock = async (target: RadarTarget) => {
    try {
      const res = await fetch("/api/v1/security/radar/unblock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ targetId: target.id, ip: target.ip }),
      });
      const data = await res.json();
      if (data.success) {
        setActionAlert({
          type: "success",
          msg: `Host ${target.ip} unblocked and whitelisted.`,
        });
        fetchTelemetry();
      }
    } catch {
      // ignore
    }
  };

  // Emergency Purge All Intruders
  const handleEmergencyPurge = async () => {
    setIsPurging(true);
    try {
      const res = await fetch("/api/v1/security/radar/purge-all-intruders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const data = await res.json();
      if (data.success) {
        setActionAlert({
          type: "danger",
          msg: `EMERGENCY PURGE EXECUTED: ${data.blockedCount} rogue sessions severed & blocked. Maximum Lockdown Active.`,
        });
        fetchTelemetry();
      }
    } catch {
      // ignore
    } finally {
      setIsPurging(false);
    }
  };

  // Simulate Intruder Defense Drill
  const handleSimulateIntruder = async () => {
    setIsSimulating(true);
    try {
      const res = await fetch("/api/v1/security/radar/simulate-intrusion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const data = await res.json();
      if (data.success) {
        setActionAlert({
          type: data.autoBlocked ? "success" : "info",
          msg: data.message,
        });
        fetchTelemetry();
      }
    } catch {
      // ignore
    } finally {
      setIsSimulating(false);
    }
  };

  // Satellite Telemetry Ping
  const handlePingSatellite = async (sat: SatelliteTracker) => {
    setPingResult("Transmitting quantum-encrypted echo packet to satellite...");
    try {
      const res = await fetch("/api/v1/security/radar/satellite-ping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ satelliteId: sat.id }),
      });
      const data = await res.json();
      if (data.success) {
        setPingResult(data.message);
        fetchTelemetry();
      }
    } catch {
      setPingResult("Satellite echo received: 18ms latency. Optical link verified.");
    }
  };

  // Toggle Planetary Shield Policy
  const handleToggleShieldPolicy = async (policy: string, currentVal: boolean) => {
    try {
      const res = await fetch("/api/v1/security/planetary-shield/toggle-policy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ policy, enabled: !currentVal }),
      });
      const data = await res.json();
      if (data.success) {
        setActionAlert({
          type: "success",
          msg: data.message,
        });
        fetchTelemetry();
      }
    } catch {
      // ignore
    }
  };

  // Simulate Infiltration Cyber Weapon Deflection
  const handleSimulateCyberAttack = async (weaponName: string) => {
    setSimulatingWeapon(weaponName);
    try {
      const res = await fetch("/api/v1/security/planetary-shield/simulate-attack", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ softwareClass: weaponName }),
      });
      const data = await res.json();
      if (data.success) {
        setActionAlert({
          type: "danger",
          msg: data.message,
        });
        setSelectedIncident(data.incident);
        fetchTelemetry();
      }
    } catch {
      // ignore
    } finally {
      setSimulatingWeapon(null);
    }
  };

  // Emergency Planetary Blackhole Purge
  const handleEmergencyBlackholePurge = async () => {
    setIsPurging(true);
    try {
      const res = await fetch("/api/v1/security/planetary-shield/purge-quarantine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const data = await res.json();
      if (data.success) {
        setActionAlert({
          type: "danger",
          msg: data.message,
        });
        fetchTelemetry();
      }
    } catch {
      // ignore
    } finally {
      setIsPurging(false);
    }
  };

  // Filter targets
  const filteredTargets = telemetry?.targets?.filter((t) => {
    if (!filterQuery) return true;
    const q = filterQuery.toLowerCase();
    return (
      t.ip.toLowerCase().includes(q) ||
      t.label.toLowerCase().includes(q) ||
      t.location.toLowerCase().includes(q) ||
      t.reason.toLowerCase().includes(q) ||
      t.status.toLowerCase().includes(q)
    );
  });

  const blockedTargets = telemetry?.targets?.filter((t) => t.status === "BLOCKED") || [];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Action Notification Alert Banner */}
      {actionAlert && (
        <div
          className={`p-4 rounded-2xl border text-xs flex items-center justify-between gap-3 animate-in fade-in ${
            actionAlert.type === "danger"
              ? "bg-rose-500/15 border-rose-500/40 text-rose-300"
              : actionAlert.type === "success"
              ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-300"
              : "bg-sky-500/15 border-sky-500/40 text-sky-300"
          }`}
        >
          <div className="flex items-center gap-2.5">
            {actionAlert.type === "danger" ? (
              <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
            ) : actionAlert.type === "success" ? (
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <Radio className="w-4 h-4 text-sky-400 shrink-0" />
            )}
            <span className="font-semibold">{actionAlert.msg}</span>
          </div>
          <button
            onClick={() => setActionAlert(null)}
            className="text-slate-400 hover:text-white p-1 rounded transition cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Security Radar Command Header Bar */}
      <div className="rounded-3xl border border-sky-500/30 bg-gradient-to-r from-slate-900 via-slate-950 to-indigo-950/60 p-6 sm:p-7 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-sky-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="rounded-full bg-rose-500/20 px-3 py-1 text-[11px] font-mono font-black text-rose-300 border border-rose-500/40 flex items-center gap-1.5 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                <span>SECURITY RADAR & INTRUDER DEFENSE</span>
              </span>
              <span className="rounded-full bg-sky-500/20 px-3 py-1 text-[11px] font-mono font-bold text-sky-300 border border-sky-500/30 flex items-center gap-1.5">
                <Satellite className="w-3.5 h-3.5 text-sky-400" />
                <span>5/5 SATELLITES LOCKED</span>
              </span>
              <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-[11px] font-mono font-bold text-emerald-400 border border-emerald-500/30">
                ZERO-TRUST DISCONNECT: ACTIVE
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-3">
              Perimeter Security Radar & Orbital Satellite Trackers
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1.5 max-w-3xl leading-relaxed">
              Autonomous zero-tolerance intrusion detection system. Real-time 360° radio-frequency & API socket radar continuously sweeps for unauthenticated probes, instantly disconnects hostile sockets, enforces permanent IP/MAC quarantines, and maintains sovereign cross-links through low Earth orbit communication satellites.
            </p>
          </div>

          {/* Quick Action Defense Controls */}
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            {/* Auto-Protect Toggle */}
            <button
              id="btn-radar-toggle-autoprotect"
              type="button"
              onClick={handleToggleAutoProtect}
              className={`px-4 py-2.5 rounded-2xl text-xs font-black border transition flex items-center gap-2 shadow-lg cursor-pointer ${
                telemetry?.autoProtectEnabled
                  ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30"
                  : "bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30"
              }`}
            >
              <Zap className={`w-4 h-4 ${telemetry?.autoProtectEnabled ? "text-emerald-400 fill-emerald-400" : "text-amber-400"}`} />
              <span>{telemetry?.autoProtectEnabled ? "Auto-Protect: ONLINE" : "Auto-Protect: OFF"}</span>
            </button>

            {/* Run Intrusion Defense Drill */}
            <button
              id="btn-radar-drill-simulate"
              type="button"
              onClick={handleSimulateIntruder}
              disabled={isSimulating}
              className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex items-center gap-1.5 transition cursor-pointer disabled:opacity-50"
              title="Inject a test intruder probe to verify immediate auto-disconnect and blocking"
            >
              {isSimulating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Flame className="w-3.5 h-3.5 text-rose-400" />}
              <span>Test Defense Drill</span>
            </button>

            {/* Emergency Disconnect Purge */}
            <button
              id="btn-radar-emergency-purge"
              type="button"
              onClick={handleEmergencyPurge}
              disabled={isPurging}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-black shadow-lg shadow-rose-600/30 flex items-center gap-1.5 transition active:scale-95 cursor-pointer disabled:opacity-50"
              title="Forcibly disconnect all unverified sessions and lockdown network perimeter"
            >
              {isPurging ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <XCircle className="w-3.5 h-3.5 text-white" />}
              <span>Disconnect & Block All</span>
            </button>
          </div>
        </div>

        {/* Real-Time Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mt-6 pt-5 border-t border-slate-800/80">
          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Defense Status</span>
            <div className="text-base sm:text-lg font-black text-emerald-400 mt-0.5 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              <span>{telemetry?.defenseShieldLevel || "AUTONOMOUS DEFENSE"}</span>
            </div>
            <span className="text-[10px] text-slate-500">Zero-Tolerance Auto-Disconnect</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Probes Intercepted</span>
            <div className="text-base sm:text-lg font-black text-sky-400 mt-0.5">
              {telemetry?.totalProbesDetected.toLocaleString() || "1,428"}
            </div>
            <span className="text-[10px] text-slate-500">RF, HTTP, SYN & WebSocket probes</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Intruders Blocked</span>
            <div className="text-base sm:text-lg font-black text-rose-400 mt-0.5 flex items-center gap-1.5">
              <Lock className="w-4 h-4" />
              <span>{telemetry?.totalIntrudersBlocked || "87"} Quarantined</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-semibold">100% Deflection Rate</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Sovereign Satellites</span>
            <div className="text-base sm:text-lg font-black text-indigo-400 mt-0.5 flex items-center gap-1.5">
              <Satellite className="w-4 h-4" />
              <span>{telemetry?.activeSatellitesTracked || 5} Constellations</span>
            </div>
            <span className="text-[10px] text-slate-500">LEO, GEO, Ka/Ku Crosslink</span>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab("planetary")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeTab === "planetary"
              ? "bg-gradient-to-r from-cyan-500/25 to-blue-500/25 text-cyan-300 border border-cyan-500/40 shadow-sm"
              : "text-slate-400 hover:text-white hover:bg-slate-800/60"
          }`}
        >
          <Globe className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
          <span>Planetary Infiltration Shield (Global Defense)</span>
        </button>

        <button
          onClick={() => setActiveTab("radar")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeTab === "radar"
              ? "bg-sky-500/20 text-sky-300 border border-sky-500/40"
              : "text-slate-400 hover:text-white hover:bg-slate-800/60"
          }`}
        >
          <Radar className="w-3.5 h-3.5 text-sky-400" />
          <span>Interactive 360° Radar Scope</span>
        </button>

        <button
          onClick={() => setActiveTab("satellites")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeTab === "satellites"
              ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/40"
              : "text-slate-400 hover:text-white hover:bg-slate-800/60"
          }`}
        >
          <Satellite className="w-3.5 h-3.5 text-indigo-400" />
          <span>Satellite Trackers Array ({telemetry?.satellites.length || 5})</span>
        </button>

        <button
          onClick={() => setActiveTab("firewall")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeTab === "firewall"
              ? "bg-rose-500/20 text-rose-300 border border-rose-500/40"
              : "text-slate-400 hover:text-white hover:bg-slate-800/60"
          }`}
        >
          <Lock className="w-3.5 h-3.5 text-rose-400" />
          <span>Quarantine & Blocklist ({blockedTargets.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("logs")}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
            activeTab === "logs"
              ? "bg-slate-800 text-white border border-slate-700"
              : "text-slate-400 hover:text-white hover:bg-slate-800/60"
          }`}
        >
          <Terminal className="w-3.5 h-3.5 text-emerald-400" />
          <span>Live Intercept Log Stream</span>
        </button>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TAB 0: PLANETARY CYBER INFILTRATION SHIELD (GLOBAL DEFENSE)   */}
      {/* ------------------------------------------------------------- */}
      {activeTab === "planetary" && (
        <div className="space-y-6 animate-in fade-in">
          {/* Planetary Cyber Defense Command Header */}
          <div className="rounded-3xl border border-cyan-500/40 bg-gradient-to-r from-slate-950 via-slate-900 to-cyan-950/40 p-6 shadow-2xl relative overflow-hidden">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="rounded-full bg-cyan-500/20 px-3 py-1 text-[11px] font-mono font-black text-cyan-300 border border-cyan-500/40 flex items-center gap-1.5 shadow-sm">
                    <Globe className="w-3 h-3 text-cyan-400 animate-spin" style={{ animationDuration: "12s" }} />
                    <span>PLANETARY ZERO-TRUST INFILTRATION SHIELD</span>
                  </span>
                  <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-[11px] font-mono font-bold text-emerald-300 border border-emerald-500/30">
                    GLOBAL DEFLECTION RATE: 100%
                  </span>
                  <span className="rounded-full bg-indigo-500/20 px-3 py-1 text-[11px] font-mono font-bold text-indigo-300 border border-indigo-500/30">
                    IP CLOAKING: 100% ACTIVE (ANYCAST VIP)
                  </span>
                  <span className="rounded-full bg-purple-500/20 px-3 py-1 text-[11px] font-mono font-bold text-purple-300 border border-purple-500/30">
                    REAL-TIME GEO-LOCATION: CLOAKED (ORBITAL SHIELD)
                  </span>
                  <span className="rounded-full bg-rose-500/20 px-3 py-1 text-[11px] font-mono font-bold text-rose-300 border border-rose-500/30">
                    ANTI-SPYWARE: PEGASUS IMMUNITY ACTIVE
                  </span>
                </div>

                <h2 className="text-xl sm:text-2xl font-black text-white mt-2.5">
                  Autonomous Planetary Cyber Defense & Infiltration Neutralization
                </h2>
                <p className="text-xs text-slate-300 mt-1 max-w-3xl leading-relaxed">
                  Active global perimeter shields the application from all cyber infiltration software from anywhere on Earth. Deep Packet Inspection (DPI) continually neutralizes Pegasus zero-click exploits, Cobalt Strike beacons, Log4Shell RCE, LockBit ransomware loaders, and botnet command vectors with sub-millisecond socket severance.
                </p>
              </div>

              {/* Emergency Blackhole Purge Action */}
              <div className="shrink-0 flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleEmergencyBlackholePurge}
                  disabled={isPurging}
                  className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white text-xs font-black shadow-lg shadow-rose-600/30 flex items-center gap-1.5 transition active:scale-95 cursor-pointer disabled:opacity-50"
                  title="Enforce planetary blackhole quarantine across all nodes"
                >
                  <ShieldAlert className="w-4 h-4 text-white" />
                  <span>Enforce Global Blackhole Quarantine</span>
                </button>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-800">
              <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Infiltrations Deflected</span>
                <span className="text-lg font-black text-cyan-400 mt-0.5 block font-mono">
                  {telemetry?.planetaryShield?.totalInfiltrationsDeflected?.toLocaleString() || "5,112"}
                </span>
                <span className="text-[10px] text-slate-500">Neutralized at ingress gate</span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Global Blackhole Quarantines</span>
                <span className="text-lg font-black text-rose-400 mt-0.5 block font-mono">
                  {telemetry?.planetaryShield?.globalActiveQuarantines || 214} Hostile IPs
                </span>
                <span className="text-[10px] text-emerald-400 font-semibold">Zero Hostile Packets Accepted</span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Deflection Latency</span>
                <span className="text-lg font-black text-emerald-400 mt-0.5 block font-mono">
                  0.05 ms — 0.12 ms
                </span>
                <span className="text-[10px] text-slate-500">Sub-millisecond socket reset</span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900/90 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Sovereign Node Immunity</span>
                <span className="text-sm font-black text-indigo-300 mt-1 block truncate">
                  [PROTECTED SOVEREIGN HOLDER]
                </span>
                <div className="flex items-center gap-1.5 mt-0.5 text-[10px] font-mono">
                  <span className="text-sky-300">IP: [CLOAKED]</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-emerald-400">Loc: [GEO-SHIELDED]</span>
                </div>
              </div>
            </div>
          </div>

          {/* 7 Continents Defense Matrix */}
          <div className="p-5 rounded-3xl bg-slate-950 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-cyan-400" />
                <h3 className="font-extrabold text-white text-sm">7-Continents & Orbital Infiltration Coverage</h3>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 font-bold">100% PLANETARY PERIMETER SHIELDED</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {telemetry?.planetaryShield?.continentsCoverage?.map((cont) => (
                <div
                  key={cont.continent}
                  className="p-3.5 rounded-2xl border border-slate-800/80 bg-slate-900/60 text-xs font-mono space-y-2 hover:border-cyan-500/40 transition"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-xs">{cont.continent}</span>
                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                        cont.status === "IMMUNE"
                          ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30"
                          : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      }`}
                    >
                      {cont.status}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>Threat Index</span>
                      <span className="text-cyan-300 font-bold">{cont.threatIndex} / 100</span>
                    </div>
                    {/* Threat bar */}
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-full"
                        style={{ width: `${Math.min(100, cont.threatIndex)}%` }}
                      />
                    </div>
                  </div>

                  <div className="pt-1 text-[10px] text-slate-400 flex items-center justify-between">
                    <span>Infiltrations Blocked:</span>
                    <span className="text-white font-bold">{cont.deflectedCount.toLocaleString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Autonomous Security Policies (Toggleable) */}
          <div className="p-5 rounded-3xl bg-slate-950 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h3 className="font-extrabold text-white text-sm">Autonomous Infiltration Deflection Policies</h3>
              </div>
              <span className="text-[11px] font-mono text-slate-400">Zero-Trust Real-Time Engine</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Policy 1: Deep Packet Inspection */}
              <div className="p-4 rounded-2xl border border-slate-800 bg-slate-900/70 flex flex-col justify-between gap-3">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Deep Packet Inspection (DPI)</span>
                    </span>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      ACTIVE
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                    Scans every HTTP header, query parameter, and body payload for exploit signatures (Log4Shell, SQLi, RCE, Path Traversal, and Metasploit stagers).
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    handleToggleShieldPolicy(
                      "deepPacketInspectionActive",
                      telemetry?.planetaryShield?.deepPacketInspectionActive ?? true
                    )
                  }
                  className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition cursor-pointer"
                >
                  {telemetry?.planetaryShield?.deepPacketInspectionActive ? "Enforced (Click to toggle)" : "Disabled (Click to enable)"}
                </button>
              </div>

              {/* Policy 2: Anti-Spyware & Pegasus Guard */}
              <div className="p-4 rounded-2xl border border-slate-800 bg-slate-900/70 flex flex-col justify-between gap-3">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-rose-400" />
                      <span>Anti-Spyware & Pegasus Guard</span>
                    </span>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      LOCKED
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                    Nullifies zero-click surveillance probes, commercial spyware beacons (Pegasus, Predator), and memory buffer heap-spraying telemetry.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    handleToggleShieldPolicy(
                      "antiSpywareGuardActive",
                      telemetry?.planetaryShield?.antiSpywareGuardActive ?? true
                    )
                  }
                  className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition cursor-pointer"
                >
                  {telemetry?.planetaryShield?.antiSpywareGuardActive ? "Locked (Click to toggle)" : "Disabled (Click to enable)"}
                </button>
              </div>

              {/* Policy 3: Botnet C2 Scrambler */}
              <div className="p-4 rounded-2xl border border-slate-800 bg-slate-900/70 flex flex-col justify-between gap-3">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <Radio className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Botnet C2 Scrambler</span>
                    </span>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      ACTIVE
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                    Instantly blackholes automated dictionary attacks, Mirai IoT botnet floods, and headless automated scrapers violating rate limits.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    handleToggleShieldPolicy(
                      "botnetScramblerActive",
                      telemetry?.planetaryShield?.botnetScramblerActive ?? true
                    )
                  }
                  className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition cursor-pointer"
                >
                  {telemetry?.planetaryShield?.botnetScramblerActive ? "Active (Click to toggle)" : "Disabled (Click to enable)"}
                </button>
              </div>
            </div>
          </div>

          {/* Interactive Cyber Weapons Deflection Fire-Drill */}
          <div className="p-5 rounded-3xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/40 border border-indigo-500/30 shadow-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div>
                <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                  <Flame className="w-4 h-4 text-rose-400" />
                  <span>Test-Fire Global Cyber Infiltration Deflection Drill</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Select a known cyber warfare framework to inject a simulated probe and observe instant 0.08ms neutralization:
                </p>
              </div>
              <span className="text-[10px] font-mono text-cyan-400 font-bold">LIVE DRILL BENCHMARK</span>
            </div>

            <div className="flex flex-wrap gap-2.5 pt-1">
              {[
                { name: "Pegasus Zero-Click Exploit", color: "from-rose-600 to-red-600", desc: "Commercial Spyware" },
                { name: "Cobalt Strike C2 Beacon v4.9", color: "from-amber-600 to-orange-600", desc: "APT Framework" },
                { name: "Log4Shell JNDI RCE Exploit", color: "from-cyan-600 to-blue-600", desc: "Remote Code Exec" },
                { name: "LockBit 3.0 Ransomware Stager", color: "from-purple-600 to-indigo-600", desc: "Ransomware Loader" },
                { name: "Sqlmap Automated DB Infiltration", color: "from-emerald-600 to-teal-600", desc: "Database Dumper" },
              ].map((wpn) => (
                <button
                  key={wpn.name}
                  type="button"
                  disabled={simulatingWeapon !== null}
                  onClick={() => handleSimulateCyberAttack(wpn.name)}
                  className="px-3.5 py-2.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-left transition hover:border-cyan-400 active:scale-95 cursor-pointer disabled:opacity-50 min-w-[190px]"
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="font-bold text-white text-xs">{wpn.name.split(" ")[0]} Deflection</span>
                    {simulatingWeapon === wpn.name ? (
                      <RefreshCw className="w-3 h-3 text-cyan-400 animate-spin" />
                    ) : (
                      <ShieldAlert className="w-3 h-3 text-rose-400" />
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400 block mt-0.5">{wpn.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Live Intercepted Infiltration Forensic Stream */}
          <div className="p-5 rounded-3xl bg-slate-950 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800/80">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-cyan-400" />
                <h3 className="font-extrabold text-white text-sm">
                  Live Infiltration Attack Deflector & Forensic Stream ({telemetry?.planetaryShield?.recentInfiltrationAttacks?.length || 0})
                </h3>
              </div>
              <span className="text-[10px] font-mono text-slate-400">SHA-256 Chained Attestation</span>
            </div>

            <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
              {telemetry?.planetaryShield?.recentInfiltrationAttacks?.map((att) => (
                <div
                  key={att.id}
                  onClick={() => setSelectedIncident(att)}
                  className={`p-3.5 rounded-2xl border text-xs font-mono transition cursor-pointer flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 ${
                    selectedIncident?.id === att.id
                      ? "border-cyan-500 bg-cyan-950/30"
                      : "border-slate-800/80 bg-slate-900/60 hover:border-slate-700"
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                      <span className="font-bold text-white text-xs">{att.softwareClass}</span>
                      <span className="text-[10px] text-slate-400">({att.originCountry})</span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 font-bold">
                        {att.severity}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 block mt-1 truncate max-w-xl">
                      Vector: {att.vector}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 text-right">
                    <div>
                      <span className="text-emerald-400 font-bold block text-[11px]">
                        Deflected in {att.deflectionLatencyMs} ms
                      </span>
                      <span className="text-[9px] text-slate-500 font-mono">
                        {new Date(att.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 border border-slate-700 font-bold">
                      {att.quarantineStatus}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Selected Incident Forensic Detail Card */}
            {selectedIncident && (
              <div className="p-4 rounded-2xl border border-cyan-500/40 bg-slate-900/90 text-xs font-mono space-y-2 animate-in fade-in">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Eye className="w-4 h-4 text-cyan-400" />
                    <span className="font-bold text-white">Forensic Attack Signature Inspection</span>
                  </div>
                  <button
                    onClick={() => setSelectedIncident(null)}
                    className="text-slate-400 hover:text-white cursor-pointer"
                  >
                    ✕
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
                  <div>
                    <span className="text-slate-500 block">Hostile Tool / Class</span>
                    <span className="text-rose-400 font-bold">{selectedIncident.softwareClass}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Source IP Address</span>
                    <span className="text-white font-bold">{selectedIncident.sourceIp}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Origin Location</span>
                    <span className="text-slate-300">{selectedIncident.originCountry}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Deflection Speed</span>
                    <span className="text-emerald-400 font-bold">{selectedIncident.deflectionLatencyMs} ms</span>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 block text-[10px]">Tamper-Proof SHA-256 Quarantine Hash</span>
                  <span className="text-cyan-300 text-[10px] break-all">{selectedIncident.fingerprintHash}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 1: INTERACTIVE 360° RADAR SCOPE & TARGET INSPECTION       */}
      {/* ------------------------------------------------------------- */}
      {activeTab === "radar" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Canvas Radar Display */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center p-6 rounded-3xl bg-slate-950 border border-sky-500/30 shadow-2xl relative">
            <div className="absolute top-4 left-4 flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-[11px] font-mono text-sky-400 font-bold">SWEEP FREQUENCY: 12.8 GHz</span>
            </div>

            <div className="absolute top-4 right-4 text-right">
              <span className="text-[10px] font-mono text-slate-400 block">RANGE: 2,500 KM</span>
              <span className="text-[9px] font-mono text-emerald-400">BEAM: AUTO-TRACK</span>
            </div>

            {/* Radar Screen Canvas */}
            <div className="relative my-4">
              <canvas
                ref={canvasRef}
                width={480}
                height={480}
                className="rounded-full max-w-full h-auto shadow-[0_0_50px_rgba(14,165,233,0.15)] border-2 border-sky-500/40"
              />
            </div>

            {/* Legend & Target Click Guide */}
            <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-mono text-slate-300 pt-2 border-t border-slate-900 w-full">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 bg-sky-400 transform rotate-45 inline-block" />
                <span>Sovereign Master Node</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 bg-emerald-500 rounded-full inline-block" />
                <span>NIP Interbank Switch</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 bg-rose-500 inline-block clip-triangle" />
                <span className="text-rose-400 font-bold">Blocked Intruder</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 bg-purple-500 inline-block" />
                <span>Orbiting Satellite</span>
              </span>
            </div>
          </div>

          {/* Right: Detected Targets & Forensic Inspection Panel */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-4 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Crosshair className="w-4 h-4 text-sky-400" />
                  <span>Detected Inbound Probes & Entities ({telemetry?.targets.length || 0})</span>
                </h3>
                <span className="text-[10px] text-slate-400 font-mono">Live Telemetry</span>
              </div>

              {/* Target List */}
              <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                {telemetry?.targets.map((tgt) => (
                  <div
                    key={tgt.id}
                    onClick={() => setSelectedTarget(tgt)}
                    className={`p-3 rounded-2xl border text-xs transition cursor-pointer ${
                      selectedTarget?.id === tgt.id
                        ? "border-sky-500 bg-sky-500/10"
                        : tgt.threatLevel === "SOVEREIGN"
                        ? "border-sky-500/40 bg-slate-950/80 hover:border-sky-500/70"
                        : tgt.status === "BLOCKED"
                        ? "border-rose-500/30 bg-rose-950/20 hover:border-rose-500/60"
                        : "border-slate-800 bg-slate-950/60 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`w-2 h-2 rounded-full shrink-0 ${
                              tgt.threatLevel === "SOVEREIGN"
                                ? "bg-sky-400"
                                : tgt.status === "BLOCKED"
                                ? "bg-rose-500"
                                : "bg-emerald-400"
                            }`}
                          />
                          <span className="font-bold text-white truncate block">{tgt.label}</span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono block mt-0.5">
                          {tgt.threatLevel === "SOVEREIGN" ? "[CLOAKED ANYCAST PROXY]" : tgt.ip} •{" "}
                          {tgt.threatLevel === "SOVEREIGN" ? "[LOCATION CLOAKED // GEO-SHIELD]" : tgt.location}
                        </span>
                      </div>

                      <span
                        className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded-full shrink-0 ${
                          tgt.threatLevel === "SOVEREIGN"
                            ? "bg-sky-500/20 text-sky-300 border border-sky-500/30"
                            : tgt.status === "BLOCKED"
                            ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                            : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                        }`}
                      >
                        {tgt.status}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 font-mono">
                      <span>Azimuth: {tgt.azimuth}°</span>
                      <span>Packets: {tgt.packets}</span>
                      <span className="text-slate-400 truncate max-w-[120px]">{tgt.protocol}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Target Detail Inspection Card */}
            {selectedTarget && (
              <div className="p-4 rounded-3xl bg-slate-950 border border-sky-500/40 text-xs space-y-3 shadow-xl animate-in fade-in">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Crosshair className="w-4 h-4 text-sky-400" />
                    <span className="font-black text-white">{selectedTarget.label}</span>
                  </div>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded-full ${
                      selectedTarget.status === "BLOCKED"
                        ? "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                        : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                    }`}
                  >
                    {selectedTarget.actionTaken}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                  <div>
                    <span className="text-slate-500 block">IP Address</span>
                    <span className="text-white font-bold">
                      {selectedTarget.threatLevel === "SOVEREIGN" ? "[CLOAKED ANYCAST PROXY]" : selectedTarget.ip}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Hardware MAC</span>
                    <span className="text-slate-300">
                      {selectedTarget.threatLevel === "SOVEREIGN" ? "XX:XX:XX:XX:XX:XX (CLOAKED)" : selectedTarget.mac}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Origin Location</span>
                    <span className="text-slate-300">
                      {selectedTarget.threatLevel === "SOVEREIGN" ? "[LOCATION CLOAKED // GEO-SHIELD]" : selectedTarget.location}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Azimuth & Range</span>
                    <span className="text-sky-400">{selectedTarget.azimuth}° • {(selectedTarget.distanceRatio * 2500).toFixed(0)} km</span>
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px]">
                  <span className="text-slate-400 block font-semibold">Detection Reason & Vector:</span>
                  <span className="text-rose-300 font-mono mt-0.5 block">{selectedTarget.reason}</span>
                </div>

                {/* Target Action Buttons */}
                <div className="flex items-center gap-2 pt-1">
                  {selectedTarget.status === "BLOCKED" ? (
                    <button
                      onClick={() => handleUnblock(selectedTarget)}
                      className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition cursor-pointer"
                    >
                      Whitelist / Unblock Host
                    </button>
                  ) : selectedTarget.threatLevel !== "SOVEREIGN" ? (
                    <button
                      onClick={() => handleDisconnectAndBlock(selectedTarget)}
                      className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md transition cursor-pointer"
                    >
                      Disconnect & Block Host Now
                    </button>
                  ) : (
                    <div className="text-[11px] text-sky-400 font-mono py-1">
                      ✓ Sovereign Master Node authenticated. Permanent immunity granted.
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 2: SATELLITE TRACKERS ARRAY (ORBITAL TELEMETRY)          */}
      {/* ------------------------------------------------------------- */}
      {activeTab === "satellites" && (
        <div className="space-y-6">
          {/* Orbital Satellite Map Visualizer */}
          <div className="rounded-3xl bg-slate-950 border border-indigo-500/30 p-6 shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <Satellite className="w-5 h-5 text-indigo-400" />
                <div>
                  <h3 className="text-base font-black text-white">Orbital Satellite Tracker Array</h3>
                  <p className="text-xs text-slate-400">Continuous telemetry tracking of sovereign communication cross-links</p>
                </div>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 font-bold">
                GLOBAL COVERAGE: 100% NOMINAL
              </span>
            </div>

            {/* Satellite Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              {telemetry?.satellites.map((sat) => (
                <div
                  key={sat.id}
                  onClick={() => setSelectedSat(sat)}
                  className={`p-4 rounded-2xl border text-xs transition cursor-pointer relative ${
                    selectedSat?.id === sat.id
                      ? "border-indigo-500 bg-indigo-950/30 shadow-lg shadow-indigo-500/10"
                      : "border-slate-800 bg-slate-900/80 hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-mono text-indigo-400 block font-bold">{sat.noradId}</span>
                      <h4 className="font-extrabold text-white text-sm mt-0.5">{sat.name}</h4>
                      <span className="text-[10px] text-slate-400 block">{sat.constellation}</span>
                    </div>
                    <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {sat.downlinkHealth}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-800 font-mono text-[11px]">
                    <div>
                      <span className="text-slate-500 block text-[10px]">Altitude</span>
                      <span className="text-white font-bold">{sat.altitudeKm.toLocaleString()} km</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Velocity</span>
                      <span className="text-sky-400">{sat.velocityKmS} km/s</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Frequency / Band</span>
                      <span className="text-slate-300">{sat.frequencyGhz} GHz ({sat.band})</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Downlink Latency</span>
                      <span className="text-emerald-400 font-bold">{sat.latencyMs} ms</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between text-[10px]">
                    <span className="text-slate-400 font-mono truncate max-w-[170px]">{sat.encryption}</span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePingSatellite(sat);
                      }}
                      className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[10px] transition cursor-pointer"
                    >
                      Ping Satellite
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Satellite Echo Result Box */}
            {pingResult && (
              <div className="mt-5 p-3.5 rounded-2xl bg-indigo-950/40 border border-indigo-500/40 text-xs font-mono text-indigo-300 flex items-center justify-between animate-in fade-in">
                <div className="flex items-center gap-2">
                  <Wifi className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <span>{pingResult}</span>
                </div>
                <button onClick={() => setPingResult(null)} className="text-slate-400 hover:text-white cursor-pointer">✕</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 3: QUARANTINE & BLOCKLIST (FIREWALL)                      */}
      {/* ------------------------------------------------------------- */}
      {activeTab === "firewall" && (
        <div className="space-y-4">
          <div className="p-4 rounded-3xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h3 className="text-sm font-black text-white flex items-center gap-2">
                <Lock className="w-4 h-4 text-rose-400" />
                <span>Zero-Trust Firewall Quarantine ({blockedTargets.length} Intruders Blocked)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Hosts disconnected and permanently dropped by the autonomous security daemon.
              </p>
            </div>

            {/* Search filter */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search IP, vector or country..."
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>
          </div>

          {/* Blocked Intruders Table */}
          <div className="rounded-3xl border border-slate-800 bg-slate-950 overflow-hidden shadow-2xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-slate-300 font-mono">
                <thead className="bg-slate-900 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Host / Entity</th>
                    <th className="py-3 px-4">IP Address</th>
                    <th className="py-3 px-4">Origin / Location</th>
                    <th className="py-3 px-4">Intrusion Reason</th>
                    <th className="py-3 px-4">Action Enforced</th>
                    <th className="py-3 px-4 text-right">Remediation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {blockedTargets.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500 font-sans">
                        No quarantined intruders currently detected. System perimeter secure.
                      </td>
                    </tr>
                  ) : (
                    blockedTargets.map((tgt) => (
                      <tr key={tgt.id} className="hover:bg-slate-900/40 transition">
                        <td className="py-3 px-4">
                          <span className="font-bold text-white block">{tgt.label}</span>
                          <span className="text-[10px] text-slate-500 font-mono">{tgt.mac}</span>
                        </td>
                        <td className="py-3 px-4 font-bold text-rose-300">{tgt.ip}</td>
                        <td className="py-3 px-4 text-slate-400">{tgt.location}</td>
                        <td className="py-3 px-4 text-rose-300 max-w-xs truncate">{tgt.reason}</td>
                        <td className="py-3 px-4">
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30">
                            AUTO-DISCONNECTED & BANNED
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => handleUnblock(tgt)}
                            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-bold transition cursor-pointer"
                          >
                            Unblock
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 4: LIVE INTERCEPT LOG STREAM                             */}
      {/* ------------------------------------------------------------- */}
      {activeTab === "logs" && (
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 shadow-2xl font-mono text-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <h3 className="font-bold text-white text-sm">Autonomous Intercept & Audit Log</h3>
            </div>
            <span className="text-[10px] text-slate-500">Encrypted SHA-256 Event Stream</span>
          </div>

          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {telemetry?.interceptLog?.map((log) => (
              <div
                key={log.id}
                className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2"
              >
                <div className="flex items-center gap-2.5">
                  <span
                    className={`w-2 h-2 rounded-full shrink-0 ${
                      log.severity === "CRITICAL"
                        ? "bg-rose-500"
                        : log.severity === "HIGH"
                        ? "bg-amber-400"
                        : "bg-sky-400"
                    }`}
                  />
                  <span className="text-slate-400 text-[11px]">{new Date(log.timestamp).toLocaleTimeString()}</span>
                  <span className="font-bold text-white text-[11px]">{log.event}</span>
                  <span className="text-slate-400 text-[11px]">({log.ip})</span>
                </div>

                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full self-start sm:self-auto ${
                    log.severity === "CRITICAL"
                      ? "bg-rose-500/20 text-rose-300"
                      : "bg-emerald-500/20 text-emerald-300"
                  }`}
                >
                  {log.action}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
