import React from "react";

interface HmrStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
}

/**
 * HMR Status Modal is kept hidden to maintain a pristine, production-ready UI while
 * Hot Module Replacement continues running smoothly and silently in the background.
 */
export const HmrStatusModal: React.FC<HmrStatusModalProps> = () => {
  return null;
};
