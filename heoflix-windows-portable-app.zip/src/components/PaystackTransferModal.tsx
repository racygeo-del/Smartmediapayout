import React from "react";
import { WalletState } from "../types";
import { PaystackPaymentGateway } from "./PaystackPaymentGateway";
import { X, Zap, ShieldCheck } from "lucide-react";

interface PaystackTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  wallet: WalletState;
  onUpdateWallet?: (newWallet: WalletState) => void;
  onRefreshAllData?: () => void;
  onOpenSecurityModal?: (title?: string) => void;
  isUnlocked?: boolean;
}

export const PaystackTransferModal: React.FC<PaystackTransferModalProps> = ({
  isOpen,
  onClose,
  wallet,
  onUpdateWallet,
  onRefreshAllData,
  onOpenSecurityModal,
  isUnlocked = false,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="modal-paystack-transfer"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6 overflow-y-auto animate-in fade-in"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-5xl rounded-3xl bg-slate-950 border border-sky-500/40 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Top Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-extrabold text-white flex items-center gap-2">
                <span>Paystack Payments &amp; Transfers Gateway</span>
                <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-500/30">
                  NIP INSTANT RAIL
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Send &amp; receive dollars, connect Paystack website wallet, and execute direct interbank transfers
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
            aria-label="Close Paystack Modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6">
          <PaystackPaymentGateway
            wallet={wallet}
            onUpdateWallet={onUpdateWallet}
            onRefreshAllData={onRefreshAllData}
            onOpenSecurityModal={onOpenSecurityModal}
            isUnlocked={isUnlocked}
            onClose={onClose}
            isModal={true}
          />
        </div>
      </div>
    </div>
  );
};
