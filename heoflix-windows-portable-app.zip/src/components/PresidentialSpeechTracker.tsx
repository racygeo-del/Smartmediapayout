import React, { useState, useEffect } from "react";
import {
  Mic,
  Radio,
  Activity,
  Globe,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Play,
  Square,
  Volume2,
  FileText,
  Search,
  Filter,
  Plus,
  X,
  Sparkles,
  Zap,
  CheckCircle2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Scale,
  DollarSign,
  Building,
  Flag,
  Share2,
  Copy,
  Check,
} from "lucide-react";
import { PresidentialSpeech } from "../types";

export const PresidentialSpeechTracker: React.FC = () => {
  const [speeches, setSpeeches] = useState<PresidentialSpeech[]>([]);
  const [filteredSpeeches, setFilteredSpeeches] = useState<PresidentialSpeech[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");
  const [selectedSentiment, setSelectedSentiment] = useState<string>("ALL");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [expandedSpeechId, setExpandedSpeechId] = useState<string | null>("speech_potus_01");

  // Record New Speech Modal State
  const [isRecordModalOpen, setIsRecordModalOpen] = useState<boolean>(false);
  const [formTitle, setFormTitle] = useState<string>("");
  const [formPresident, setFormPresident] = useState<string>("Joseph R. Biden Jr.");
  const [formLocation, setFormLocation] = useState<string>("Oval Office, The White House, Washington D.C.");
  const [formCategory, setFormCategory] = useState<PresidentialSpeech["category"]>("CRYPTO_DIGITAL_ASSETS");
  const [formTranscript, setFormTranscript] = useState<string>("");
  const [formQuotes, setFormQuotes] = useState<string>("");
  const [formDirectives, setFormDirectives] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Audio Playback State (Web Speech API)
  const [playingSpeechId, setPlayingSpeechId] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Quick preset speech templates
  const presets = [
    {
      label: "Trump Nashville Bitcoin Address",
      title: "Presidential Keynote on American Sovereign Bitcoin Leadership & Crypto Innovation",
      president: "Donald J. Trump",
      location: "Nashville, Tennessee",
      category: "CRYPTO_DIGITAL_ASSETS" as const,
      quotes: "If crypto is going to define the future, I want it mined, minted, and made in the USA.\nNever sell your bitcoin.",
      transcript:
        "We will create a National Strategic Bitcoin Reserve. We will ensure that America becomes the crypto capital of the planet and the Bitcoin superpower of the world. From now on, the rules will be written by people who build your industry, not people who want to suppress it.",
    },
    {
      label: "Biden Digital Assets Executive Order",
      title: "Executive Order on Ensuring Responsible Development of Digital Assets",
      president: "Joseph R. Biden Jr.",
      location: "Oval Office, The White House",
      category: "CRYPTO_DIGITAL_ASSETS" as const,
      quotes: "The rise of digital assets creates an opportunity to reinforce United States leadership in the global financial system.",
      transcript:
        "The United States has a vital interest in ensuring that global financial architecture continues to reflect transparent democratic values. Advances in distributed ledger technology have created monumental markets that require responsible whole-of-government leadership.",
    },
    {
      label: "State of the Union Economic Address",
      title: "State of the Union Address on Reciprocal Tariffs, Energy Dominance & US Manufacturing",
      president: "Donald J. Trump",
      location: "U.S. Capitol, Washington D.C.",
      category: "GLOBAL_TRADE_TARIFFS" as const,
      quotes: "We are restoring our nation's manufacturing might and rebuilding our critical trade alliances.",
      transcript:
        "Our strategy has broken the mold of failed Washington trade deals and replaced them with fair and reciprocal trade. The years of American wealth being depleted through unbalanced treaties are officially over.",
    },
  ];

  const fetchSpeeches = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/v1/presidential-speeches");
      const data = await res.json();
      if (data.success && Array.isArray(data.speeches)) {
        setSpeeches(data.speeches);
        setFilteredSpeeches(data.speeches);
      }
    } catch (e) {
      console.error("Failed to fetch presidential speeches:", e);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchMetrics = async () => {
    try {
      const res = await fetch("/api/v1/presidential-speeches/telemetry/metrics");
      const data = await res.json();
      if (data.success && data.metrics) {
        setMetrics(data.metrics);
      }
    } catch (e) {
      console.error("Failed to fetch speech telemetry:", e);
    }
  };

  useEffect(() => {
    fetchSpeeches();
    fetchMetrics();
  }, []);

  // Filter speeches
  useEffect(() => {
    let list = [...speeches];
    if (selectedCategory !== "ALL") {
      list = list.filter((s) => s.category === selectedCategory);
    }
    if (selectedSentiment !== "ALL") {
      list = list.filter((s) => s.sentiment === selectedSentiment);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (s) =>
          s.title.toLowerCase().includes(q) ||
          s.president.toLowerCase().includes(q) ||
          s.location.toLowerCase().includes(q) ||
          s.fullTranscript.toLowerCase().includes(q) ||
          s.keyQuotes.some((quote) => quote.toLowerCase().includes(q))
      );
    }
    setFilteredSpeeches(list);
  }, [selectedCategory, selectedSentiment, searchQuery, speeches]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Submit New Speech Form
  const handleRecordSpeech = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formTranscript.trim()) {
      showToast("Please provide both a Speech Title and Transcript content.");
      return;
    }

    setIsSubmitting(true);
    try {
      const quotesArray = formQuotes
        .split("\n")
        .map((q) => q.trim())
        .filter(Boolean);

      const directivesArray = formDirectives
        .split("\n")
        .map((d) => d.trim())
        .filter(Boolean);

      const res = await fetch("/api/v1/presidential-speeches", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: formTitle,
          president: formPresident,
          location: formLocation,
          category: formCategory,
          fullTranscript: formTranscript,
          keyQuotes: quotesArray,
          policyDirectives: directivesArray,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showToast("Presidential speech successfully recorded & analyzed!");
        setIsRecordModalOpen(false);
        setFormTitle("");
        setFormTranscript("");
        setFormQuotes("");
        setFormDirectives("");
        fetchSpeeches();
        fetchMetrics();
        setExpandedSpeechId(data.speech?.id || null);
      } else {
        showToast(data.error || "Failed to record speech.");
      }
    } catch (err: any) {
      showToast(err.message || "Network error logging speech.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Speech Audio playback with SpeechSynthesis
  const handleToggleSpeechAudio = (speech: PresidentialSpeech) => {
    if (!("speechSynthesis" in window)) {
      showToast("Audio synthesis is not supported on this device.");
      return;
    }

    if (playingSpeechId === speech.id && isSpeaking) {
      window.speechSynthesis.cancel();
      setPlayingSpeechId(null);
      setIsSpeaking(false);
      return;
    }

    window.speechSynthesis.cancel();
    const textToRead = speech.keyQuotes[0] || speech.fullTranscript.slice(0, 300);
    const utterance = new SpeechSynthesisUtterance(
      `Presidential address by President ${speech.president}. ${textToRead}`
    );
    utterance.rate = 0.95;
    utterance.pitch = 0.95;

    utterance.onend = () => {
      setPlayingSpeechId(null);
      setIsSpeaking(false);
    };

    utterance.onerror = () => {
      setPlayingSpeechId(null);
      setIsSpeaking(false);
    };

    window.speechSynthesis.speak(utterance);
    setPlayingSpeechId(speech.id);
    setIsSpeaking(true);
  };

  const getSentimentBadge = (sentiment: PresidentialSpeech["sentiment"]) => {
    switch (sentiment) {
      case "BULLISH_LIQUIDITY":
        return {
          label: "BULLISH LIQUIDITY EXPANSION",
          color: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
          icon: <TrendingUp className="w-3 h-3 text-emerald-400" />,
        };
      case "BEARISH_RESTRICTION":
        return {
          label: "BEARISH REGULATORY RESTRICTION",
          color: "bg-rose-500/15 text-rose-400 border-rose-500/30",
          icon: <TrendingDown className="w-3 h-3 text-rose-400" />,
        };
      case "GEOPOLITICAL_SHOCK":
        return {
          label: "GEOPOLITICAL EMERGENCY / SHOCK",
          color: "bg-amber-500/15 text-amber-300 border-amber-500/30",
          icon: <AlertTriangle className="w-3 h-3 text-amber-400" />,
        };
      case "HAWKISH_PIVOT":
        return {
          label: "HAWKISH SOVEREIGN SANCTIONS",
          color: "bg-purple-500/15 text-purple-300 border-purple-500/30",
          icon: <Scale className="w-3 h-3 text-purple-400" />,
        };
      default:
        return {
          label: "MACRO INDUSTRIAL EXPANSION",
          color: "bg-sky-500/15 text-sky-300 border-sky-500/30",
          icon: <Activity className="w-3 h-3 text-sky-400" />,
        };
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in pb-16">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 rounded-2xl bg-slate-900 border border-sky-500/50 p-4 text-xs font-bold text-white shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-4">
          <Sparkles className="w-4 h-4 text-sky-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* TOP HERO HEADER */}
      <div className="relative overflow-hidden rounded-3xl border border-sky-500/30 bg-gradient-to-r from-slate-950 via-slate-900 to-sky-950/40 p-6 sm:p-8 shadow-2xl">
        <div className="absolute -top-12 -right-12 h-44 w-44 rounded-full bg-sky-500/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 h-44 w-44 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="flex items-center gap-1.5 rounded-full bg-sky-500/20 px-3 py-1 text-xs font-extrabold text-sky-300 border border-sky-500/40 shadow-sm">
                <Radio className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
                <span>POTUS EXECUTIVE TRACKING ENGINE</span>
              </span>

              <span className="rounded-full bg-emerald-500/20 px-3 py-1 text-xs font-bold text-emerald-400 border border-emerald-500/40">
                GLOBAL IMPACT RADAR ACTIVE
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight">
              United States Presidential Speeches &amp; Global Impact Tracker
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              Real-time intelligence engine recording and analyzing historic and breaking speeches delivered by the President of the United States. Tracks global financial volatility, DXY dollar benchmark shifts, Bitcoin &amp; cryptocurrency liquidity ripples, and international trade sanctions.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              id="btn-record-presidential-speech"
              onClick={() => setIsRecordModalOpen(true)}
              className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-black text-xs sm:text-sm shadow-xl shadow-sky-500/20 transition cursor-pointer active:scale-95"
            >
              <Mic className="w-4 h-4 text-white" />
              <span>Record New Speech</span>
            </button>

            <button
              onClick={() => {
                fetchSpeeches();
                fetchMetrics();
              }}
              className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700 text-xs font-bold transition cursor-pointer"
            >
              <Activity className="w-4 h-4 text-sky-400" />
              <span>Sync Radar</span>
            </button>
          </div>
        </div>

        {/* Live Metrics Quick Strip */}
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-slate-800/80">
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Total Speeches Tracked</span>
            <div className="text-xl sm:text-2xl font-black text-white font-mono">{metrics?.totalSpeechesTracked || speeches.length}</div>
            <span className="text-[10px] text-emerald-400 font-medium">Verified Historical Dossiers</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Avg Global Magnitude</span>
            <div className="text-xl sm:text-2xl font-black text-sky-400 font-mono">{metrics?.averageGlobalImpactScore || 96}/100</div>
            <span className="text-[10px] text-slate-400">High World Market Sensitivity</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Bitcoin / Crypto Corridors</span>
            <div className="text-xl sm:text-2xl font-black text-amber-400 font-mono">{metrics?.cryptoSpecificCount || 2} Speeches</div>
            <span className="text-[10px] text-amber-300/80">88% Historical Correlation</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">DXY Dollar Benchmark</span>
            <div className="text-xl sm:text-2xl font-black text-emerald-400 font-mono">0.94 Alpha</div>
            <span className="text-[10px] text-slate-400">Direct FX Volatility Impact</span>
          </div>
        </div>
      </div>

      {/* FILTER & SEARCH BAR */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900 border border-slate-800">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search presidential speeches, presidents, topics, or key phrases..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Category Selector */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-bold focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
          >
            <option value="ALL">All Categories</option>
            <option value="CRYPTO_DIGITAL_ASSETS">Crypto &amp; Digital Assets</option>
            <option value="ECONOMIC_SOVEREIGNTY">Economic Sovereignty</option>
            <option value="GEOPOLITICAL_DEFENSE">Geopolitical Defense &amp; War</option>
            <option value="GLOBAL_TRADE_TARIFFS">Global Trade &amp; Tariffs</option>
            <option value="STATE_OF_THE_UNION">State of the Union</option>
            <option value="EXECUTIVE_ORDER">Executive Orders</option>
          </select>

          {/* Sentiment Selector */}
          <select
            value={selectedSentiment}
            onChange={(e) => setSelectedSentiment(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-bold focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
          >
            <option value="ALL">All Sentiments</option>
            <option value="BULLISH_LIQUIDITY">Bullish Liquidity</option>
            <option value="BEARISH_RESTRICTION">Bearish Restriction</option>
            <option value="GEOPOLITICAL_SHOCK">Geopolitical Shock</option>
            <option value="HAWKISH_PIVOT">Hawkish Pivot</option>
            <option value="MACRO_EXPANSION">Macro Expansion</option>
          </select>
        </div>
      </div>

      {/* SPEECHES LIST */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="p-12 text-center text-slate-400 space-y-3">
            <Radio className="w-8 h-8 text-sky-400 mx-auto animate-spin" />
            <p className="text-xs">Initializing presidential speech telemetry from secure archives...</p>
          </div>
        ) : filteredSpeeches.length === 0 ? (
          <div className="p-12 text-center rounded-3xl bg-slate-900 border border-slate-800 text-slate-400 space-y-3">
            <FileText className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-sm font-bold text-slate-300">No speeches match your current filters.</p>
            <p className="text-xs">Try resetting search filters or record a new speech into the engine.</p>
          </div>
        ) : (
          filteredSpeeches.map((speech) => {
            const isExpanded = expandedSpeechId === speech.id;
            const sentiment = getSentimentBadge(speech.sentiment);

            return (
              <div
                key={speech.id}
                className={`rounded-3xl border transition-all duration-200 overflow-hidden ${
                  isExpanded
                    ? "bg-slate-900/95 border-sky-500/40 shadow-2xl"
                    : "bg-slate-900/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900/90"
                }`}
              >
                {/* Speech Card Top Bar */}
                <div
                  onClick={() => setExpandedSpeechId(isExpanded ? null : speech.id)}
                  className="p-5 sm:p-6 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-4 min-w-0">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-500/20 via-indigo-500/20 to-emerald-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400 shrink-0 shadow-inner">
                      <Flag className="w-6 h-6 text-sky-300" />
                    </div>

                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-black uppercase text-sky-400 tracking-wider font-mono">
                          {speech.president}
                        </span>
                        <span className="text-slate-500 text-xs">&bull;</span>
                        <span className="text-xs text-slate-400">
                          {new Date(speech.date).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })}
                        </span>
                        <span className="text-slate-500 text-xs">&bull;</span>
                        <span className="text-xs text-slate-400 truncate">{speech.location}</span>
                      </div>

                      <h3 className="text-base sm:text-lg font-extrabold text-white leading-snug">
                        {speech.title}
                      </h3>

                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${sentiment.color}`}>
                          {sentiment.icon}
                          <span>{sentiment.label}</span>
                        </span>

                        <span className="rounded-full bg-slate-800 px-2.5 py-0.5 text-[10px] font-bold text-slate-300 border border-slate-700">
                          {speech.category.replace(/_/g, " ")}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Impact Rating Meter & Expand Toggle */}
                  <div className="flex items-center sm:flex-col items-end justify-between sm:justify-center gap-2 shrink-0 pt-3 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                    <div className="text-right">
                      <span className="text-[10px] font-bold uppercase text-slate-400 block tracking-wider">
                        Impact Index
                      </span>
                      <div className="text-lg sm:text-xl font-black text-emerald-400 font-mono">
                        {speech.globalImpactScore}/100
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleSpeechAudio(speech);
                        }}
                        className={`p-2 rounded-xl border transition cursor-pointer ${
                          playingSpeechId === speech.id && isSpeaking
                            ? "bg-rose-500/20 text-rose-300 border-rose-500/40"
                            : "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700"
                        }`}
                        title={playingSpeechId === speech.id && isSpeaking ? "Stop Speech Audio" : "Listen to Speech Audio Excerpt"}
                      >
                        {playingSpeechId === speech.id && isSpeaking ? (
                          <Square className="w-3.5 h-3.5 fill-current" />
                        ) : (
                          <Volume2 className="w-3.5 h-3.5" />
                        )}
                      </button>

                      <div className="text-slate-400">
                        {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Expanded Speech Dossier */}
                {isExpanded && (
                  <div className="p-5 sm:p-6 border-t border-slate-800/80 bg-slate-950/70 space-y-5 animate-in fade-in">
                    {/* Key Quotes Callout Box */}
                    {speech.keyQuotes.length > 0 && (
                      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-sky-950/40 to-indigo-950/40 border border-sky-500/30 space-y-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-sky-400 uppercase tracking-wider">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Historic Key Quotes</span>
                        </div>
                        <div className="space-y-2 text-xs sm:text-sm text-slate-200 italic font-serif leading-relaxed">
                          {speech.keyQuotes.map((q, idx) => (
                            <div key={idx} className="border-l-2 border-sky-400 pl-3">
                              &ldquo;{q}&rdquo;
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Significance & Markets Affected Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                        <span className="font-bold text-slate-400 uppercase tracking-wider block">
                          Global Historical Significance
                        </span>
                        <p className="text-slate-300 leading-relaxed">{speech.historicalSignificance}</p>
                      </div>

                      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                        <span className="font-bold text-slate-400 uppercase tracking-wider block">
                          Markets &amp; Clearing Corridors Affected
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {speech.marketsAffected.map((m, idx) => (
                            <span
                              key={idx}
                              className="px-2.5 py-1 rounded-lg bg-slate-950 text-slate-200 border border-slate-800 font-mono font-semibold text-[11px]"
                            >
                              &bull; {m}
                            </span>
                          ))}
                        </div>
                        <div className="pt-2 text-[11px] text-emerald-400 font-medium">
                          <strong>Market Reaction:</strong> {speech.marketReaction}
                        </div>
                      </div>
                    </div>

                    {/* Policy Directives */}
                    {speech.policyDirectives.length > 0 && (
                      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
                        <span className="font-bold text-slate-400 uppercase tracking-wider block">
                          Directives &amp; International Policy Actions Spawned
                        </span>
                        <ul className="space-y-1.5 text-slate-300">
                          {speech.policyDirectives.map((d, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <CheckCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0 mt-0.5" />
                              <span>{d}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Full Transcript Viewer */}
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-wider">
                        <span>Official Presidential Transcript</span>
                        <span className="text-[10px] font-mono text-slate-500">
                          {speech.fullTranscript.split(" ").length} Words &bull; Verified Record
                        </span>
                      </div>
                      <div className="max-h-60 overflow-y-auto p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs sm:text-sm text-slate-300 font-mono leading-relaxed select-text">
                        {speech.fullTranscript}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* RECORD NEW PRESIDENTIAL SPEECH MODAL */}
      {isRecordModalOpen && (
        <div
          id="modal-record-presidential-speech"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-5 overflow-y-auto animate-in fade-in"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-3xl rounded-3xl bg-slate-950 border border-sky-500/40 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/40 flex items-center justify-center">
                  <Mic className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">
                    Record Presidential Speech in Global Tracking Engine
                  </h3>
                  <p className="text-xs text-slate-400">
                    Log and evaluate world-impacting executive addresses, state of the union, or currency directives
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsRecordModalOpen(false)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form Body */}
            <form onSubmit={handleRecordSpeech} className="p-5 sm:p-6 overflow-y-auto space-y-4">
              {/* Presets Row */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Quick Load Preset Templates
                </span>
                <div className="flex flex-wrap gap-2">
                  {presets.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setFormTitle(p.title);
                        setFormPresident(p.president);
                        setFormLocation(p.location);
                        setFormCategory(p.category);
                        setFormQuotes(p.quotes);
                        setFormTranscript(p.transcript);
                      }}
                      className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700 transition cursor-pointer"
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Title & President Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 uppercase block">Speech Title</label>
                  <input
                    type="text"
                    required
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    placeholder="e.g. Executive Address on National Sovereign Bitcoin Reserve"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-semibold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 uppercase block">President Name</label>
                  <select
                    value={formPresident}
                    onChange={(e) => setFormPresident(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500 font-semibold"
                  >
                    <option value="Joseph R. Biden Jr.">Joseph R. Biden Jr. (46th POTUS)</option>
                    <option value="Donald J. Trump">Donald J. Trump (45th &amp; 47th POTUS)</option>
                    <option value="Barack Obama">Barack Obama (44th POTUS)</option>
                    <option value="George W. Bush">George W. Bush (43rd POTUS)</option>
                    <option value="Bill Clinton">Bill Clinton (42nd POTUS)</option>
                    <option value="Ronald Reagan">Ronald Reagan (40th POTUS)</option>
                    <option value="Franklin D. Roosevelt">Franklin D. Roosevelt (32nd POTUS)</option>
                  </select>
                </div>
              </div>

              {/* Location & Category Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 uppercase block">Speech Delivery Location</label>
                  <input
                    type="text"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    placeholder="e.g. Oval Office / United Nations / Congress"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300 uppercase block">Category &amp; Domain</label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                  >
                    <option value="CRYPTO_DIGITAL_ASSETS">Crypto &amp; Digital Assets Policy</option>
                    <option value="ECONOMIC_SOVEREIGNTY">Economic Sovereignty &amp; Banking</option>
                    <option value="GEOPOLITICAL_DEFENSE">Geopolitical Defense &amp; Conflict</option>
                    <option value="GLOBAL_TRADE_TARIFFS">Global Trade, Tariffs &amp; Supply Chains</option>
                    <option value="STATE_OF_THE_UNION">State of the Union Address</option>
                    <option value="EXECUTIVE_ORDER">Executive Order Proclamation</option>
                  </select>
                </div>
              </div>

              {/* Full Transcript */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300 uppercase block">
                  Official Transcript / Delivery Remarks (Required)
                </label>
                <textarea
                  required
                  rows={6}
                  value={formTranscript}
                  onChange={(e) => setFormTranscript(e.target.value)}
                  placeholder="Paste or dictate full speech text or official White House remarks..."
                  className="w-full p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {/* Key Quotes */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300 uppercase block">
                  Key Quotes (One per line)
                </label>
                <textarea
                  rows={2}
                  value={formQuotes}
                  onChange={(e) => setFormQuotes(e.target.value)}
                  placeholder="Quote 1: Never sell your bitcoin...&#10;Quote 2: America will lead the digital currency age..."
                  className="w-full p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {/* Policy Directives */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300 uppercase block">
                  Policy Directives &amp; Market Directives (One per line)
                </label>
                <textarea
                  rows={2}
                  value={formDirectives}
                  onChange={(e) => setFormDirectives(e.target.value)}
                  placeholder="e.g. Creation of the U.S. Strategic Bitcoin Reserve&#10;Emergency sanctions coordination via FinCEN"
                  className="w-full p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              {/* Action Buttons */}
              <div className="pt-3 flex items-center justify-end gap-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsRecordModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-black shadow-lg transition flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Sparkles className="w-4 h-4 text-white" />
                  <span>{isSubmitting ? "Evaluating Impact..." : "Record & Analyze Speech"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
