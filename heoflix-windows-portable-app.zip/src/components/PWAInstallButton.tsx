import React, { useState } from "react";
import { Download, Smartphone, X, Check, Apple, Monitor, FolderArchive } from "lucide-react";
import { usePWAInstall } from "../hooks/usePWAInstall";

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled) {
    return (
      <div id="pwa-status-installed" className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-medium">
        <Check className="w-3.5 h-3.5 text-emerald-400" />
        <span>Installed</span>
      </div>
    );
  }

  return (
    <>
      <div className="flex items-center gap-2">
        {isInstallable && (
          <button
            id="btn-install-app-native"
            onClick={install}
            className="flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm hover:from-emerald-400 hover:to-teal-500 transition active:scale-95"
            title="Install HEOFLIX on this device"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Install App</span>
          </button>
        )}

        <button
          id="btn-install-platforms-modal"
          onClick={() => setShowGuide(true)}
          className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/80 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white hover:bg-slate-700/80 transition cursor-pointer"
          title="Install on Windows, Android & iOS"
        >
          <Monitor className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden md:inline">Install Windows &amp; Mobile</span>
        </button>
      </div>

      {showGuide && (
        <div id="modal-pwa-guide" className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl text-slate-100 max-h-[90vh] overflow-y-auto scrollbar-thin">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-indigo-500 to-emerald-500 flex items-center justify-center font-bold text-white shadow-md text-sm">
                  H
                </div>
                <div>
                  <h3 className="font-bold text-slate-100 text-sm">Install HEOFLIX on Windows &amp; Mobile</h3>
                  <p className="text-xs text-slate-400">Open as desktop or mobile standalone application</p>
                </div>
              </div>
              <button
                id="btn-close-pwa-modal"
                onClick={() => setShowGuide(false)}
                className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3.5">
              {/* Windows PC Guide */}
              <div className="rounded-xl border border-slate-800 bg-slate-800/40 p-3.5">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 font-medium text-xs text-indigo-400">
                    <Monitor className="w-4 h-4" />
                    <span>Microsoft Windows (Chrome / Edge Desktop App)</span>
                  </div>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                    DESKTOP PWA
                  </span>
                </div>
                <ol className="text-xs text-slate-300 space-y-1.5 list-decimal pl-4">
                  <li>In <strong>Google Chrome</strong> or <strong>Microsoft Edge</strong>, click the <strong>Install icon (monitor with down arrow)</strong> on the right side of the address bar.</li>
                  <li>Or click the <strong>three dots (⋮)</strong> &gt; <strong>"Save and share"</strong> or <strong>"Apps"</strong> &gt; <strong>"Install HEOFLIX"</strong>.</li>
                  <li>Click <strong>Install</strong> to launch HEOFLIX in an independent Windows window with a Start Menu &amp; Taskbar icon.</li>
                </ol>
              </div>

              {/* Android Guide */}
              <div className="rounded-xl border border-slate-800 bg-slate-800/40 p-3.5">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 font-medium text-xs text-emerald-400">
                    <Smartphone className="w-4 h-4" />
                    <span>Google Android (Chrome / Edge / Samsung)</span>
                  </div>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                    MOBILE PWA
                  </span>
                </div>
                <ol className="text-xs text-slate-300 space-y-1.5 list-decimal pl-4">
                  <li>In Google Chrome or Samsung Internet, tap the <strong>three vertical dots (⋮)</strong>.</li>
                  <li>Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
                  <li>Confirm installation to add the official HEOFLIX icon directly to your home screen and app drawer.</li>
                </ol>
              </div>

              {/* iOS Guide */}
              <div className="rounded-xl border border-slate-800 bg-slate-800/40 p-3.5">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 font-medium text-xs text-sky-400">
                    <Apple className="w-4 h-4" />
                    <span>Apple iOS (iPhone / iPad)</span>
                  </div>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300">
                    STANDALONE
                  </span>
                </div>
                <ol className="text-xs text-slate-300 space-y-1.5 list-decimal pl-4">
                  <li>Open this app in <strong>Safari</strong> on your iPhone or iPad.</li>
                  <li>Tap the <strong>Share</strong> button (box with upward arrow) in Safari.</li>
                  <li>Scroll down and tap <strong>"Add to Home Screen"</strong>.</li>
                  <li>Tap <strong>"Add"</strong> in the top-right corner to open in full-screen standalone mode.</li>
                </ol>
              </div>

              {/* Windows Portable Code Download */}
              <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/30 p-3.5 flex items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <FolderArchive className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Download Windows Portable Package (.ZIP)</span>
                  </div>
                  <p className="text-[11px] text-slate-300">
                    Includes run-windows.bat &amp; setup scripts to run offline on PC.
                  </p>
                </div>
                <a
                  href="/api/v1/app/download-zip"
                  download="heoflix-windows-portable-app.zip"
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1 shrink-0 transition"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .ZIP</span>
                </a>
              </div>
            </div>

            <div className="mt-5 flex gap-2">
              {isInstallable && (
                <button
                  id="btn-confirm-prompt-install"
                  onClick={() => {
                    install();
                    setShowGuide(false);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-xs font-semibold text-white hover:from-emerald-400 hover:to-teal-500 transition shadow-lg text-center cursor-pointer"
                >
                  Trigger Install Prompt
                </button>
              )}
              <button
                id="btn-dismiss-pwa-modal"
                onClick={() => setShowGuide(false)}
                className="flex-1 py-2.5 rounded-xl bg-slate-800 text-xs font-semibold text-slate-300 hover:bg-slate-700 transition text-center cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
