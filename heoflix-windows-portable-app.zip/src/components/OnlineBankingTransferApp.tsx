import React, { useState, useEffect } from "react";
import {
  Send,
  Building,
  Building2,
  Coins,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  RefreshCw,
  ExternalLink,
  Sparkles,
  Lock,
  Download,
  Key,
  Globe,
  Radio,
  FileText,
  DollarSign,
  TrendingUp,
  Cpu,
  Layers,
  ArrowUpRight,
  CheckCircle,
  Terminal,
  Eye,
  X,
  CreditCard,
  Zap,
  Fingerprint,
  Link2,
  Smartphone,
  Activity,
  Search,
} from "lucide-react";
import { WalletState } from "../types";
import { downloadPaystackReceiptPdf, PaystackReceiptData } from "../utils/paystackReceiptPdf";

interface OnlineBankingTransferAppProps {
  wallet: WalletState;
  onTransferSuccess?: () => void;
  onUpdateWallet?: (newWallet: WalletState) => void;
  isUnlocked?: boolean;
}

export const OnlineBankingTransferApp: React.FC<OnlineBankingTransferAppProps> = ({
  wallet,
  onTransferSuccess,
  onUpdateWallet,
  isUnlocked = true,
}) => {
  // Destination: Bank Account or Crypto Wallet
  const [destinationType, setDestinationType] = useState<"BANK" | "CRYPTO">("BANK");

  // App & Connection Status
  const [appStatus, setAppStatus] = useState<any>(null);
  const [isLoadingStatus, setIsLoadingStatus] = useState<boolean>(true);
  const [isSearchingApi, setIsSearchingApi] = useState<boolean>(false);
  const [searchStep, setSearchStep] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Bank Form State
  const [selectedBankPreset, setSelectedBankPreset] = useState<"opay" | "firstbank" | "chase" | "custom">("opay");
  const [bankName, setBankName] = useState<string>("OPAY");
  const [accountNumber, setAccountNumber] = useState<string>("8134762646");
  const [accountName, setAccountName] = useState<string>("George Felix Egwu");
  const [routingNumber, setRoutingNumber] = useState<string>("999992");
  const [destinationCurrency, setDestinationCurrency] = useState<string>("USD");

  // Crypto Form State
  const [selectedCryptoPreset, setSelectedCryptoPreset] = useState<"btc" | "usdt_trc20" | "usdc_erc20" | "sol" | "custom">("btc");
  const [cryptoToken, setCryptoToken] = useState<string>("BTC");
  const [cryptoNetwork, setCryptoNetwork] = useState<string>("BITCOIN");
  const [cryptoAddress, setCryptoAddress] = useState<string>("34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW");
  const [cryptoMemo, setCryptoMemo] = useState<string>("Online Banking Crypto Payout from Dollar Wallet");

  // Transfer Amount State
  const [transferAmount, setTransferAmount] = useState<string>("5000");

  // Execution Pipeline State
  const [isTransferring, setIsTransferring] = useState<boolean>(false);
  const [executionStep, setExecutionStep] = useState<number>(0);
  const [transferResult, setTransferResult] = useState<any>(null);
  const [transferError, setTransferError] = useState<string | null>(null);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState<boolean>(false);

  // Play audio chime
  const playAudioCue = (success = true) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(success ? 659.25 : 330, ctx.currentTime);
      if (success) {
        osc.frequency.exponentialRampToValueAtTime(1046.5, ctx.currentTime + 0.18);
      }
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch {}
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3800);
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    triggerToast(`Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  // Fetch Status from server
  const fetchStatus = async () => {
    try {
      const res = await fetch("/api/v1/online-banking/status");
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setAppStatus(data);
        }
      }
    } catch {
      // offline fallback
    } finally {
      setIsLoadingStatus(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  // 1. AUTOMATICALLY SEARCH AND CONNECT TO ONLINE BANKING TRANSFER API
  const handleAutoSearchAndConnect = async () => {
    setIsSearchingApi(true);
    setSearchStep(1);

    setTimeout(() => setSearchStep(2), 500);
    setTimeout(() => setSearchStep(3), 1100);
    setTimeout(() => setSearchStep(4), 1700);

    try {
      const res = await fetch("/api/v1/online-banking/search-and-connect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const data = await res.json();

      setTimeout(() => {
        setIsSearchingApi(false);
        if (data.success) {
          playAudioCue(true);
          triggerToast("Discovered & connected to Online Banking Transfer APIs! Linked to Dollar Wallet.");
          fetchStatus();
        } else {
          playAudioCue(false);
          triggerToast("Search finished with warnings.");
        }
      }, 2200);
    } catch {
      setIsSearchingApi(false);
      triggerToast("Failed to connect online banking API.");
    }
  };

  // Handle Preset Changes for Bank
  const handleSelectBankPreset = (preset: "opay" | "firstbank" | "chase" | "custom") => {
    setSelectedBankPreset(preset);
    if (preset === "opay") {
      setBankName("OPAY");
      setAccountNumber("8134762646");
      setAccountName("George Felix Egwu");
      setRoutingNumber("999992");
      setDestinationCurrency("NGN");
    } else if (preset === "firstbank") {
      setBankName("First Bank of Nigeria PLC");
      setAccountNumber("3124446187");
      setAccountName("George Felix Egwu");
      setRoutingNumber("011151003");
      setDestinationCurrency("NGN");
    } else if (preset === "chase") {
      setBankName("JPMorgan Chase Bank N.A.");
      setAccountNumber("0928371948");
      setAccountName("George Felix Egwu");
      setRoutingNumber("021000021");
      setDestinationCurrency("USD");
    }
  };

  // Handle Preset Changes for Crypto
  const handleSelectCryptoPreset = (preset: "btc" | "usdt_trc20" | "usdc_erc20" | "sol" | "custom") => {
    setSelectedCryptoPreset(preset);
    if (preset === "btc") {
      setCryptoToken("BTC");
      setCryptoNetwork("BITCOIN");
      setCryptoAddress("34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW");
      setCryptoMemo("Primary Sovereign Bitcoin Vault (P2SH SegWit)");
    } else if (preset === "usdt_trc20") {
      setCryptoToken("USDT");
      setCryptoNetwork("TRC20");
      setCryptoAddress("TYDny55a3Ksmk4V2dJ4K5VwU9qE2o3W6Vz");
      setCryptoMemo("Cold Storage TRON Reserve (TRC-20)");
    } else if (preset === "usdc_erc20") {
      setCryptoToken("USDC");
      setCryptoNetwork("ERC20");
      setCryptoAddress("0x742d35Cc6634C0532925a3b844Bc454e4438f44e");
      setCryptoMemo("Ethereum Multi-Sig Vault (ERC-20)");
    } else if (preset === "sol") {
      setCryptoToken("USDC");
      setCryptoNetwork("SOL");
      setCryptoAddress("7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU");
      setCryptoMemo("Solana DeFi Treasury (SPL Token)");
    }
  };

  // 2. MAKE TRANSFER FROM DOLLAR WALLET THROUGH ONLINE BANKING TRANSFER APP
  const handleExecuteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmt = parseFloat(transferAmount);
    if (isNaN(numAmt) || numAmt <= 0) {
      setTransferError("Please enter a valid positive transfer amount.");
      return;
    }

    if (numAmt > wallet.availableBalance) {
      setTransferError(
        `Transfer amount ($${numAmt.toLocaleString()} USD) exceeds available Dollar Wallet balance ($${wallet.availableBalance.toLocaleString()} USD).`
      );
      return;
    }

    setTransferError(null);
    setIsTransferring(true);
    setExecutionStep(1);

    setTimeout(() => setExecutionStep(2), 500);
    setTimeout(() => setExecutionStep(3), 1100);

    try {
      const payload: any = {
        destinationType,
        amount: numAmt,
      };

      if (destinationType === "BANK") {
        payload.bankName = bankName;
        payload.accountNumber = accountNumber;
        payload.accountName = accountName;
        payload.routingNumber = routingNumber;
        payload.destinationCurrency = destinationCurrency;
        payload.memo = "Online Banking Transfer from Dollar Wallet";
      } else {
        payload.cryptoToken = cryptoToken;
        payload.cryptoNetwork = cryptoNetwork;
        payload.cryptoAddress = cryptoAddress;
        payload.cryptoMemo = cryptoMemo;
      }

      const res = await fetch("/api/v1/online-banking/transfer", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Traffic-Priority": "CRITICAL_FINANCIAL",
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      setTimeout(() => {
        setIsTransferring(false);
        if (data.success && data.receipt) {
          playAudioCue(true);
          setExecutionStep(4);
          setTransferResult(data.receipt);
          setIsReceiptModalOpen(true);
          triggerToast(`Transfer of $${numAmt.toLocaleString()} cleared instantly from Dollar Wallet!`);

          // Update local wallet state
          if (onUpdateWallet) {
            onUpdateWallet({
              ...wallet,
              totalBalance: Number((wallet.totalBalance - numAmt).toFixed(2)),
              availableBalance: Number((wallet.availableBalance - numAmt).toFixed(2)),
            });
          }

          if (onTransferSuccess) {
            onTransferSuccess();
          }

          fetchStatus();
        } else {
          playAudioCue(false);
          setTransferError(data.message || data.error || "Transfer failed.");
        }
      }, 1800);
    } catch (err: any) {
      setIsTransferring(false);
      playAudioCue(false);
      setTransferError(err?.message || "Failed to reach online banking transfer server.");
    }
  };

  // Helper to download PDF receipt
  const handleDownloadPdf = () => {
    if (!transferResult) return;
    const isBank = transferResult.destinationType === "BANK";
    const receiptData: PaystackReceiptData = {
      reference: transferResult.referenceId,
      receiptNumber: `REC-${Date.now().toString(36).toUpperCase()}`,
      amountUsd: transferResult.amountUsd,
      amountNgn: transferResult.destinationType === "BANK" && transferResult.currencyLocal === "NGN" ? transferResult.amountLocal : undefined,
      currency: "USD",
      senderOrPayer: "HEOFLIX Dollar Wallet",
      recipient: isBank ? accountName : "Crypto Beneficiary",
      bankOrChannel: isBank ? bankName : `${cryptoToken} (${cryptoNetwork})`,
      accountNumber: isBank ? accountNumber : cryptoAddress,
      clearingRail: transferResult.networkRail,
      status: "CLEARED",
      timestamp: transferResult.timestamp,
      memo: isBank ? "Online Banking Direct Push Transfer" : cryptoMemo,
    };
    downloadPaystackReceiptPdf(receiptData);
  };

  const numAmt = parseFloat(transferAmount) || 0;
  const fxNgn = numAmt * 1550;
  const estBtc = numAmt > 0 ? (numAmt / 65000).toFixed(6) : "0.000000";

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 p-3.5 rounded-2xl bg-emerald-950/95 border border-emerald-500/60 text-emerald-200 text-xs font-mono font-bold shadow-2xl flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* =========================================================================
          HERO BANNER: ONLINE BANKING TRANSFER APP [INSTALLED & LINKED]
      ========================================================================= */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/40 rounded-3xl p-6 sm:p-7 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2.5">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                ONLINE BANKING TRANSFER APP: INSTALLED
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-sky-500/20 text-sky-300 border border-sky-500/40 flex items-center gap-1.5">
                <Link2 className="w-3.5 h-3.5 text-sky-400" />
                LINKED TO DOLLAR WALLET
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
                MULTI-RAIL SUITE v5.2
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
              <span>Online Banking Transfer App</span>
              <Zap className="w-5 h-5 text-amber-400 fill-current animate-pulse" />
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              Autonomous online banking transfer client installed on HEOFLIX. Directly linked to your Dollar Wallet for real-time interbank clearance (OPAY, First Bank, Chase, Barclays, SEPA) and cryptocurrency disbursements (Bitcoin, TRC20, ERC20, Solana).
            </p>
          </div>

          {/* Action: Search and Connect to Online Banking Transfer API */}
          <div className="flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end gap-2.5 shrink-0">
            <button
              onClick={handleAutoSearchAndConnect}
              disabled={isSearchingApi}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-sky-500 via-indigo-500 to-emerald-500 hover:from-sky-400 hover:to-emerald-400 text-slate-950 font-black text-xs shadow-lg shadow-indigo-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-95"
            >
              <Search className={`w-4 h-4 ${isSearchingApi ? "animate-spin" : ""}`} />
              <span>{isSearchingApi ? "Searching & Connecting APIs..." : "⚡ Search & Connect Banking APIs"}</span>
            </button>
            <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5 justify-center sm:justify-start lg:justify-end">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>mTLS 1.3 / ISO 20022 Handshake Verified</span>
            </div>
          </div>
        </div>

        {/* Live Dollar Wallet Link Cards Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800/80">
          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-0.5">
              <span className="text-[10px] font-mono uppercase font-bold">Dollar Wallet Available</span>
              <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-lg sm:text-xl font-black text-white font-mono">
              ${wallet.availableBalance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-emerald-400 font-mono">🔗 Linked &amp; Ready to Transfer</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-0.5">
              <span className="text-[10px] font-mono uppercase font-bold">Total Dollar Vault</span>
              <Layers className="w-3.5 h-3.5 text-sky-400" />
            </div>
            <div className="text-lg sm:text-xl font-black text-sky-400 font-mono">
              ${wallet.totalBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Permanent Retention</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-0.5">
              <span className="text-[10px] font-mono uppercase font-bold">Connected Banking APIs</span>
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
            </div>
            <div className="text-lg sm:text-xl font-black text-indigo-300 font-mono">
              {appStatus?.connection?.connectedApisCount || 6} Rails
            </div>
            <span className="text-[10px] text-emerald-400 font-mono">Paystack, FedNow, SEPA, Crypto</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800">
            <div className="flex items-center justify-between text-slate-400 mb-0.5">
              <span className="text-[10px] font-mono uppercase font-bold">Transfer Clearance</span>
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-lg sm:text-xl font-black text-emerald-400 font-mono">
              &lt; 1.5s
            </div>
            <span className="text-[10px] text-emerald-400/80 font-mono">Direct Push Finality</span>
          </div>
        </div>

        {/* Search API Execution Progress */}
        {isSearchingApi && (
          <div className="mt-4 p-4 rounded-2xl bg-slate-950 border border-sky-500/50 space-y-2 animate-in fade-in">
            <div className="flex items-center justify-between text-xs font-mono font-bold text-sky-300">
              <span className="flex items-center gap-2">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-sky-400" />
                <span>Scanning Network for Online Banking Transfer APIs...</span>
              </span>
              <span>Step {searchStep} of 4</span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-sky-400 to-emerald-400 h-full transition-all duration-400"
                style={{ width: `${(searchStep / 4) * 100}%` }}
              />
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              {searchStep === 1 && "1/4: Scanning local & cloud ports for online banking transfer endpoints..."}
              {searchStep === 2 && "2/4: Probing Paystack NIP switch, FedNow RTP, and SEPA Instant gateways..."}
              {searchStep === 3 && "3/4: Negotiating mTLS 1.3 cryptographic handshake & latency benchmarks..."}
              {searchStep === 4 && "4/4: Successfully linked Online Banking Transfer App directly to Dollar Wallet!"}
            </div>
          </div>
        )}
      </div>

      {/* =========================================================================
          MAIN WORKSPACE: TRANSFER FROM DOLLAR WALLET TO BANK OR CRYPTO
      ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Transfer Setup (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                  <Send className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Make Transfer from Dollar Wallet
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono">
                    Debits directly from Dollar Wallet balance with instant delivery
                  </p>
                </div>
              </div>

              {/* Destination Mode Switcher */}
              <div className="flex items-center p-1 rounded-2xl bg-slate-950 border border-slate-800">
                <button
                  type="button"
                  onClick={() => setDestinationType("BANK")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    destinationType === "BANK"
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/40"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <Building className="w-3.5 h-3.5" />
                  <span>To Bank Account</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDestinationType("CRYPTO")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    destinationType === "CRYPTO"
                      ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/40"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>To Crypto Wallet</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleExecuteTransfer} className="space-y-4">
              {/* BANK DESTINATION CONFIGURATION */}
              {destinationType === "BANK" && (
                <div className="space-y-4 animate-in fade-in">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1.5 flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-sky-400" />
                      <span>Select Bank Destination Account or Custom</span>
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleSelectBankPreset("opay")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedBankPreset === "opay"
                            ? "bg-emerald-950/60 border-emerald-500/60 text-white shadow-sm"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-400">OPAY (8134762646)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">PRIMARY</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">George Felix Egwu</div>
                        <div className="text-[10px] text-slate-400">Paystack NIP Instant Push (&lt; 1.5s)</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectBankPreset("firstbank")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedBankPreset === "firstbank"
                            ? "bg-sky-950/60 border-sky-500/60 text-white shadow-sm"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-sky-400">First Bank of Nigeria</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono">COMMERCIAL</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">3124446187 • George Felix Egwu</div>
                        <div className="text-[10px] text-slate-400">Firstmonie NIP Direct Push</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectBankPreset("chase")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedBankPreset === "chase"
                            ? "bg-indigo-950/60 border-indigo-500/60 text-white shadow-sm"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-indigo-400">JPMorgan Chase (US)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">FEDNOW RTP</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">•••• 8192 • George Felix Egwu</div>
                        <div className="text-[10px] text-slate-400">US Dollar RTP Direct Clearing</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectBankPreset("custom")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedBankPreset === "custom"
                            ? "bg-purple-950/60 border-purple-500/60 text-white shadow-sm"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-purple-400">Custom Bank Globally</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">SWIFT/IBAN</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">Enter any bank account below</div>
                        <div className="text-[10px] text-slate-400">SEPA, Faster Payments, or SWIFT</div>
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Bank Name / Network</label>
                      <input
                        type="text"
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        placeholder="e.g. OPAY, First Bank, Chase, Barclays"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Account Number / IBAN</label>
                      <input
                        type="text"
                        value={accountNumber}
                        onChange={(e) => setAccountNumber(e.target.value)}
                        placeholder="e.g. 8134762646"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Account Holder Name</label>
                      <input
                        type="text"
                        value={accountName}
                        onChange={(e) => setAccountName(e.target.value)}
                        placeholder="e.g. George Felix Egwu"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Target Currency</label>
                      <select
                        value={destinationCurrency}
                        onChange={(e) => setDestinationCurrency(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                      >
                        <option value="USD">USD - US Dollar (FedNow RTP / Same-Day ACH)</option>
                        <option value="NGN">NGN - Nigerian Naira (1550 NGN/USD - OPAY/NIP Instant)</option>
                        <option value="EUR">EUR - Euro (SEPA Instant)</option>
                        <option value="GBP">GBP - British Pound (Faster Payments)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* CRYPTO DESTINATION CONFIGURATION */}
              {destinationType === "CRYPTO" && (
                <div className="space-y-4 animate-in fade-in">
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1.5 flex items-center gap-1.5">
                      <Coins className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Select Crypto Wallet Destination</span>
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleSelectCryptoPreset("btc")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedCryptoPreset === "btc"
                            ? "bg-amber-950/60 border-amber-500/60 text-white shadow-sm"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-amber-400">Bitcoin Vault (BTC)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">P2SH SEGWIT</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1 truncate">34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW</div>
                        <div className="text-[10px] text-slate-400">Linked Sovereign Vault • Mempool Confirmed</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectCryptoPreset("usdt_trc20")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedCryptoPreset === "usdt_trc20"
                            ? "bg-emerald-950/60 border-emerald-500/60 text-white shadow-sm"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-400">TRON Cold Storage (USDT)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">TRC-20</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1 truncate">TYDny55a3Ksmk4V2dJ4K5VwU9qE2o3W6Vz</div>
                        <div className="text-[10px] text-slate-400">Zero Fee • Instant 30s Finality</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectCryptoPreset("usdc_erc20")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedCryptoPreset === "usdc_erc20"
                            ? "bg-indigo-950/60 border-indigo-500/60 text-white shadow-sm"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-indigo-400">Ethereum Vault (USDC)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">ERC-20</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1 truncate">0x742d35Cc6634C0532925a3b844Bc454e4438f44e</div>
                        <div className="text-[10px] text-slate-400">Multi-Sig Institutional Protection</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectCryptoPreset("custom")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedCryptoPreset === "custom"
                            ? "bg-purple-950/60 border-purple-500/60 text-white shadow-sm"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-purple-400">Custom Crypto Address</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">ALL CHAINS</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">Enter any public blockchain address</div>
                        <div className="text-[10px] text-slate-400">Trust Wallet, Binance, Coinbase</div>
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Asset Token &amp; Network</label>
                      <select
                        value={`${cryptoToken}_${cryptoNetwork}`}
                        onChange={(e) => {
                          const [t, n] = e.target.value.split("_");
                          setCryptoToken(t);
                          setCryptoNetwork(n);
                        }}
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                      >
                        <option value="BTC_BITCOIN">BTC - Bitcoin (Native SegWit / P2SH)</option>
                        <option value="USDT_TRC20">USDT - TRON TRC-20 (30-sec instant)</option>
                        <option value="USDC_ERC20">USDC - Ethereum ERC-20 (Mainnet)</option>
                        <option value="USDC_SOL">USDC - Solana SPL Token (1.2-sec finality)</option>
                        <option value="USDT_POLYGON">USDT - Polygon PoS</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Recipient Public Address</label>
                      <input
                        type="text"
                        value={cryptoAddress}
                        onChange={(e) => setCryptoAddress(e.target.value)}
                        placeholder="e.g. 34m9vs... or TYDny55a... or 0x742d..."
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                        required
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* AMOUNT FIELD WITH DOLLAR WALLET BOUNDS */}
              <div className="pt-2 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-bold text-white flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Transfer Amount from Dollar Wallet ($ USD)</span>
                  </label>
                  <span className="text-[11px] font-mono text-slate-400">
                    Dollar Wallet: <strong className="text-emerald-400">${wallet.availableBalance.toLocaleString()}</strong>
                  </span>
                </div>

                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <span className="text-slate-400 font-bold">$</span>
                  </div>
                  <input
                    type="number"
                    min="1"
                    max={wallet.availableBalance}
                    step="any"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(e.target.value)}
                    className="w-full pl-8 pr-28 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-lg font-black font-mono text-white focus:outline-none focus:border-indigo-500 shadow-inner"
                    placeholder="Enter amount"
                    required
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center gap-1.5 pointer-events-none">
                    <span className="text-xs font-bold font-mono px-2 py-1 rounded bg-slate-800 text-slate-300">
                      USD
                    </span>
                  </div>
                </div>

                {/* Quick Amount Buttons */}
                <div className="flex items-center gap-2 flex-wrap pt-1">
                  <button
                    type="button"
                    onClick={() => setTransferAmount("500")}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-semibold transition cursor-pointer"
                  >
                    $500
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransferAmount("2500")}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-semibold transition cursor-pointer"
                  >
                    $2,500
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransferAmount("10000")}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-semibold transition cursor-pointer"
                  >
                    $10,000
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransferAmount("50000")}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-semibold transition cursor-pointer"
                  >
                    $50,000
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransferAmount(String(Math.floor(wallet.availableBalance)))}
                    className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30 text-xs font-mono font-bold transition cursor-pointer"
                  >
                    ALL DOLLAR WALLET (${Math.floor(wallet.availableBalance).toLocaleString()})
                  </button>
                </div>

                {/* Live Real-Time FX and Network Fee Banner */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs font-mono">
                  <div className="text-slate-300">
                    {destinationType === "BANK" ? (
                      destinationCurrency === "NGN" ? (
                        <span>Settlement Equivalent: <strong className="text-emerald-400">₦{fxNgn.toLocaleString()} NGN</strong> (@ 1,550 FX)</span>
                      ) : (
                        <span>Settlement Equivalent: <strong className="text-emerald-400">${numAmt.toLocaleString()} USD</strong></span>
                      )
                    ) : cryptoToken === "BTC" ? (
                      <span>Settlement Equivalent: <strong className="text-amber-400">₿ {estBtc} BTC</strong> (@ $65,000)</span>
                    ) : (
                      <span>Settlement Equivalent: <strong className="text-emerald-400">{numAmt.toLocaleString()} {cryptoToken}</strong></span>
                    )}
                  </div>
                  <div className="text-emerald-400 font-bold">
                    Network Fee: $0.00 (Sovereign Sponsored)
                  </div>
                </div>
              </div>

              {/* Error Alert */}
              {transferError && (
                <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs font-mono flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{transferError}</span>
                </div>
              )}

              {/* Execution Progress Visualizer */}
              {isTransferring && (
                <div className="p-4 rounded-2xl bg-slate-950 border border-indigo-500/40 space-y-2 animate-in fade-in">
                  <div className="flex items-center justify-between text-xs font-mono font-bold text-slate-300">
                    <span className="flex items-center gap-2 text-indigo-400">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Transmitting via Online Banking Transfer App...</span>
                    </span>
                    <span>Step {executionStep} of 4</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-indigo-500 via-sky-400 to-emerald-400 h-full transition-all duration-400"
                      style={{ width: `${(executionStep / 4) * 100}%` }}
                    />
                  </div>
                  <div className="text-[11px] font-mono text-slate-400">
                    {executionStep === 1 && "1/4: Debiting Dollar Wallet available balance..."}
                    {executionStep === 2 && "2/4: Signing ISO 20022 message with ED25519 cryptographic key..."}
                    {executionStep === 3 && `3/4: Transmitting to ${destinationType === "BANK" ? `${bankName} Interbank Push Switch` : `${cryptoNetwork} Blockchain Mempool`}...`}
                    {executionStep === 4 && "4/4: Transfer settled and cleared!"}
                  </div>
                </div>
              )}

              {/* Execute Transfer Submit Button */}
              <button
                type="submit"
                disabled={isTransferring || numAmt <= 0}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-indigo-600 via-sky-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-black text-sm tracking-wide shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-98"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>
                  {isTransferring
                    ? "Transacting from Dollar Wallet..."
                    : `🚀 Transfer $${numAmt > 0 ? numAmt.toLocaleString() : "0"} USD from Dollar Wallet to ${destinationType === "BANK" ? bankName : cryptoToken}`}
                </span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Connected Banking Transfer APIs & Recent Transfers (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Active Connected Banking APIs Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-sky-400" />
                <h4 className="text-xs font-black text-white uppercase tracking-wider">
                  Connected Banking Transfer APIs
                </h4>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30">
                ACTIVE • ALL RAILS
              </span>
            </div>

            <div className="space-y-2.5 max-h-64 overflow-y-auto scrollbar-thin">
              {(appStatus?.discoveredApis || []).map((api: any) => (
                <div
                  key={api.id}
                  className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs font-mono"
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-white flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      <span>{api.name}</span>
                    </div>
                    <div className="text-[10px] text-slate-400">{api.region}</div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-emerald-400 font-bold block">{api.latencyMs}ms</span>
                    <span className="text-[9px] text-slate-400">{api.clearingSpeed}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Audit History of Transfers */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-black text-white uppercase tracking-wider">
                  Transfers from Dollar Wallet
                </h4>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                {appStatus?.recentTransfers?.length || 3} recorded
              </span>
            </div>

            <div className="space-y-2 max-h-72 overflow-y-auto scrollbar-thin">
              {(appStatus?.recentTransfers || []).map((tx: any) => (
                <div
                  key={tx.id}
                  className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-white flex items-center gap-1.5">
                      {tx.destinationType === "BANK" ? (
                        <Building className="w-3.5 h-3.5 text-sky-400" />
                      ) : (
                        <Coins className="w-3.5 h-3.5 text-amber-400" />
                      )}
                      <span className="truncate max-w-[170px]">{tx.destinationSummary}</span>
                    </div>
                    <div className="text-[10px] font-mono text-slate-400">
                      {new Date(tx.timestamp).toLocaleTimeString()} • {tx.networkRail}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="font-mono font-black text-rose-400">
                      -${tx.amountUsd.toLocaleString()}
                    </div>
                    <span className="inline-block px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                      CLEARED
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          VERIFIABLE OFFICIAL TRANSFER RECEIPT MODAL
      ========================================================================= */}
      {isReceiptModalOpen && transferResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
          <div className="bg-slate-900 border border-emerald-500/50 rounded-3xl p-6 sm:p-7 max-w-lg w-full shadow-2xl space-y-4 relative">
            <button
              onClick={() => setIsReceiptModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-1.5 pb-2 border-b border-slate-800">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-black text-white uppercase tracking-tight">
                Online Banking Transfer Cleared
              </h3>
              <p className="text-xs text-emerald-400 font-mono">
                Debited Directly from Linked Dollar Wallet
              </p>
            </div>

            <div className="space-y-2 text-xs font-mono bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="flex justify-between">
                <span className="text-slate-400">Reference / UETR:</span>
                <span className="text-white font-bold truncate max-w-[220px]" title={transferResult.referenceId}>
                  {transferResult.referenceId}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Dollar Wallet Debited:</span>
                <span className="text-rose-400 font-black">
                  -${transferResult.amountUsd.toLocaleString()} USD
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Destination Credited:</span>
                <span className="text-emerald-400 font-black">
                  {transferResult.destinationType === "BANK"
                    ? `${transferResult.currencyLocal} ${transferResult.amountLocal.toLocaleString()}`
                    : `${transferResult.amountLocal} ${transferResult.currencyLocal}`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Beneficiary:</span>
                <span className="text-slate-200 truncate max-w-[220px]">
                  {transferResult.destinationSummary}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Clearing Network:</span>
                <span className="text-sky-300 font-bold">{transferResult.networkRail}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">New Dollar Balance:</span>
                <span className="text-white font-bold">
                  ${transferResult.remainingDollarBalance.toLocaleString()} USD
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Digital Signature:</span>
                <span className="text-slate-400 text-[10px] truncate max-w-[200px]">{transferResult.digitalSignature}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleDownloadPdf}
                className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-md shadow-emerald-600/30"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download PDF Receipt</span>
              </button>
              <button
                onClick={() => handleCopy(transferResult.referenceId, "Reference ID")}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy ID</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
