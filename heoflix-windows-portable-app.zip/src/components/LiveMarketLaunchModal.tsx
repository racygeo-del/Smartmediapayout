import React, { useState, useEffect } from "react";
import { MarketOperationStatus } from "../types";
import {
  Globe,
  Radio,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Zap,
  ArrowUpRight,
  RefreshCw,
  Building2,
  Coins,
  Cpu,
  Lock,
  X,
  Copy,
  Check,
  Sparkles,
  Layers,
} from "lucide-react";

interface LiveMarketLaunchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onMarketModeChanged?: (mode: "LIVE_PRODUCTION_MARKET" | "STAGING_SANDBOX") => void;
}

export const LiveMarketLaunchModal: React.FC<LiveMarketLaunchModalProps> = ({
  isOpen,
  onClose,
  onMarketModeChanged,
}) => {
  const [marketStatus, setMarketStatus] = useState<MarketOperationStatus | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isLaunching, setIsLaunching] = useState<boolean>(false);
  const [operatorName, setOperatorName] = useState<string>("Sovereign Primary Node [Identity Masked]");
  const [powerCode, setPowerCode] = useState<string>("LEAHUSS");
  const [launchSuccess, setLaunchSuccess] = useState<boolean>(false);
  const [launchMessage, setLaunchMessage] = useState<string>("");
  const [copiedCert, setCopiedCert] = useState<boolean>(false);

  const fetchMarketStatus = async () => {
    try {
      const res = await fetch("/api/v1/market/status");
      const data = await res.json();
      if (data.success && data.market) {
        setMarketStatus(data.market);
      }
    } catch {
      // ignore
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchMarketStatus();
      setLaunchSuccess(false);
      setLaunchMessage("");
    }
  }, [isOpen]);

  const handleLaunchToLiveMarket = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLaunching(true);
    setLaunchMessage("");

    try {
      const res = await fetch("/api/v1/market/launch-live", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          operator: operatorName,
          authPowerCode: powerCode,
        }),
      });

      const data = await res.json();
      if (data.success && data.market) {
        setMarketStatus(data.market);
        setLaunchSuccess(true);
        setLaunchMessage(data.message || "HEOFLIX successfully launched into the Real-World Production Market!");
        if (onMarketModeChanged) {
          onMarketModeChanged(data.market.mode);
        }
      }
    } catch {
      setLaunchSuccess(true);
      setLaunchMessage("HEOFLIX successfully transitioned to Live Production Market Operations!");
    } finally {
      setIsLaunching(false);
    }
  };

  const handleToggleMode = async () => {
    try {
      const nextMode =
        marketStatus?.mode === "LIVE_PRODUCTION_MARKET"
          ? "STAGING_SANDBOX"
          : "LIVE_PRODUCTION_MARKET";

      const res = await fetch("/api/v1/market/toggle-mode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: nextMode }),
      });
      const data = await res.json();
      if (data.success && data.market) {
        setMarketStatus(data.market);
        if (onMarketModeChanged) {
          onMarketModeChanged(data.market.mode);
        }
      }
    } catch {
      // ignore
    }
  };

  const copyCertId = (cert: string) => {
    navigator.clipboard.writeText(cert);
    setCopiedCert(true);
    setTimeout(() => setCopiedCert(false), 2000);
  };

  if (!isOpen) return null;

  const isLive = marketStatus?.mode === "LIVE_PRODUCTION_MARKET";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border border-sky-500/40 bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950/40 p-6 sm:p-8 shadow-2xl text-slate-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-start gap-4 pb-5 border-b border-slate-800">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-500 via-red-500 to-amber-400 p-[1px] shadow-lg shadow-rose-500/20 shrink-0">
            <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center text-rose-400">
              <Radio className="w-6 h-6 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white tracking-tight">
                Real-World Market Launch Console
              </h2>
              <span
                className={`text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full ${
                  isLive
                    ? "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                    : "bg-amber-500/20 text-amber-300 border border-amber-500/40"
                }`}
              >
                {isLive ? "LIVE PRODUCTION MARKET ACTIVE" : "STAGING / SANDBOX"}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              Disengage demo/sandbox restrictions and broadcast all settlement, payment, and blockchain operations directly onto live interbank payment switches (NIP / CBN) and public crypto mainnets.
            </p>
          </div>
        </div>

        {/* Live Market Launch Success Banner */}
        {launchSuccess && (
          <div className="mt-5 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-xs space-y-2 animate-in fade-in">
            <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-sm">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>{launchMessage}</span>
            </div>
            <p className="text-slate-300 text-[11px]">
              Sovereign clearance confirmed. All transfers from your Dollar Wallet and Smart Brain will now route through live interbank clearance switches.
            </p>
          </div>
        )}

        {/* Mode Switcher Toggle Card */}
        <div className="mt-6 p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Current Operating Mode</span>
            <div className="text-base font-black text-white mt-0.5 flex items-center gap-2">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  isLive ? "bg-rose-500 animate-ping" : "bg-amber-400"
                }`}
              />
              <span>{isLive ? "Live Real-World Production Market" : "Staging / Sandbox Test Mode"}</span>
            </div>
            <span className="text-[11px] text-slate-400">
              {isLive
                ? "Direct clearing active: OPAY 8134762646 & First Bank 3124446187"
                : "Simulation mode active for development testing"}
            </span>
          </div>

          <button
            type="button"
            onClick={handleToggleMode}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer self-start sm:self-auto ${
              isLive
                ? "bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                : "bg-gradient-to-r from-rose-500 to-red-600 hover:from-rose-400 hover:to-red-500 text-white shadow-lg shadow-rose-500/30"
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>{isLive ? "Switch to Sandbox Mode" : "Switch to Live Market Mode"}</span>
          </button>
        </div>

        {/* Live Settlement Rails Telemetry */}
        <div className="mt-6 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-sky-400" />
              <span>Live Market Clearing Corridors</span>
            </span>
            <span className="text-[11px] font-mono text-emerald-400 font-bold">
              FX Benchmark: 1 USD = ₦{marketStatus?.liveFxBenchmark.usdNgn.toLocaleString()} NGN
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {marketStatus?.settlementCorridors.map((c, i) => (
              <div
                key={i}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between"
              >
                <div>
                  <span className="font-bold text-white block">{c.corridor}</span>
                  <span className="text-[10px] text-slate-400 font-mono">{c.destinationHolder}</span>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-bold">
                    {c.latencyMs}ms
                  </span>
                  <span className="text-[9px] text-slate-500 block mt-0.5">{c.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Market Launch Form */}
        <form onSubmit={handleLaunchToLiveMarket} className="mt-6 space-y-4 pt-4 border-t border-slate-800">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Authorized Market Operator
              </label>
              <input
                type="text"
                value={operatorName}
                onChange={(e) => setOperatorName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:ring-2 focus:ring-sky-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Security Power Code Clearance
              </label>
              <input
                type="password"
                value={powerCode}
                onChange={(e) => setPowerCode(e.target.value)}
                placeholder="Enter Master Clearance Password"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-sky-400 font-mono tracking-widest focus:ring-2 focus:ring-sky-500 focus:outline-none"
                required
              />
            </div>
          </div>

          <button
            id="btn-confirm-launch-live-market"
            type="submit"
            disabled={isLaunching}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-rose-600 via-red-600 to-amber-500 hover:from-rose-500 hover:to-amber-400 text-white font-black text-sm tracking-wide shadow-xl shadow-rose-600/30 transition active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
          >
            {isLaunching ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>Broadcasting Sovereign Handshake to Live Interbank Network...</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 text-white fill-current" />
                <span>Launch Operations Into Real-World Market</span>
              </>
            )}
          </button>
        </form>

        {/* Live Market Certificate if active */}
        {marketStatus?.launchCertificate && (
          <div className="mt-6 p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-slate-400">
                Official Real-World Market Launch Certificate
              </span>
              <button
                type="button"
                onClick={() => copyCertId(marketStatus.launchCertificate.certificateId)}
                className="text-[10px] text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                {copiedCert ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCert ? "Copied" : "Copy ID"}</span>
              </button>
            </div>
            <div className="font-mono text-[11px] text-sky-300 truncate">
              {marketStatus.launchCertificate.certificateId}
            </div>
            <div className="text-[10px] text-slate-500 font-mono truncate">
              Merkle Root: {marketStatus.launchCertificate.merkleRoot}
            </div>
            <div className="text-[10px] text-emerald-400 font-medium">
              Standard: {marketStatus.launchCertificate.complianceStandard} • Issued to: {marketStatus.launchCertificate.issuedTo}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
