import React, { useState, useEffect, useRef } from "react";
import {
  Download,
  Printer,
  Copy,
  CheckCircle2,
  ShieldCheck,
  X,
  Share2,
  FileText,
  ExternalLink,
  QrCode as QrIcon,
  Sparkles,
  ArrowUpRight,
  ArrowDownLeft,
  Check,
  Clock,
  Building,
  CreditCard,
  Hash,
} from "lucide-react";
import QRCode from "qrcode";
import {
  PaystackReceiptData,
  downloadPaystackReceiptPdf,
  generateVerificationHash,
} from "../utils/paystackReceiptPdf";

interface PaystackReceiptModalProps {
  isOpen: boolean;
  onClose: () => void;
  receipt: PaystackReceiptData | null;
}

export const PaystackReceiptModal: React.FC<PaystackReceiptModalProps> = ({
  isOpen,
  onClose,
  receipt,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [isGeneratingPng, setIsGeneratingPng] = useState<boolean>(false);
  const receiptCardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!receipt || !isOpen) return;

    const vHash = receipt.verificationHash || generateVerificationHash({
      reference: receipt.reference,
      amountUsd: receipt.amountUsd,
      timestamp: receipt.timestamp,
    });

    const qrPayload = JSON.stringify({
      provider: "Paystack",
      ref: receipt.reference,
      rcp: receipt.receiptNumber,
      amountUsd: receipt.amountUsd,
      amountNgn: receipt.amountNgn || Math.round((receipt.amountUsd || 0) * 1550),
      recipient: receipt.recipient,
      time: receipt.timestamp,
      hash: vHash.slice(0, 16),
      status: receipt.status || "CLEARED",
      portal: "https://paystack.com",
    });

    QRCode.toDataURL(qrPayload, {
      margin: 1,
      width: 180,
      color: {
        dark: "#0a2540",
        light: "#ffffff",
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error("Error generating receipt QR:", err));
  }, [receipt, isOpen]);

  if (!isOpen || !receipt) return null;

  const isOutgoing = receipt.type === "TRANSFER_SEND";
  const amountUsd = Number(receipt.amountUsd || 0);
  const amountNgn = receipt.amountNgn || Math.round(amountUsd * 1550);
  const formattedUsd = `$${amountUsd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const formattedNgn = `₦${amountNgn.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const rateStr = receipt.exchangeRate || "1 USD = ₦1,550.00 NGN";
  const verificationHash = receipt.verificationHash || generateVerificationHash({
    reference: receipt.reference,
    amountUsd,
    timestamp: receipt.timestamp,
  });

  const formattedDate = new Date(receipt.timestamp).toLocaleString("en-US", {
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

  const handleCopyText = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2500);
  };

  const handleCopyProofSummary = () => {
    const summary = `=== OFFICIAL PAYSTACK PAYMENT RECEIPT ===
Receipt No: ${receipt.receiptNumber}
Reference: ${receipt.reference}
Amount: ${formattedUsd} (${formattedNgn})
Type: ${isOutgoing ? "Interbank Transfer Payout" : "Payment Inflow / Deposit"}
Status: ${receipt.status || "CLEARED & SETTLED"}
Recipient: ${receipt.recipient}
Bank/Channel: ${receipt.bankOrChannel}
Sender: ${receipt.senderOrPayer}
Date: ${formattedDate}
Clearing Rail: ${receipt.clearingRail || "Paystack Instant NIP Switch (< 1.5s)"}
SHA-256 Digest: ${verificationHash}
Verified via Paystack Interbank Gateway`;
    handleCopyText(summary, "summary");
  };

  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      await downloadPaystackReceiptPdf({
        ...receipt,
        verificationHash,
      });
    } catch (err) {
      console.error("Failed to generate PDF:", err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleDownloadPng = async () => {
    setIsGeneratingPng(true);
    try {
      // Draw receipt directly on an off-screen HTML5 Canvas for pristine PNG output
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      const scale = 2; // High-DPI 2x
      canvas.width = 680 * scale;
      canvas.height = 960 * scale;
      ctx.scale(scale, scale);

      // Background
      ctx.fillStyle = "#0f172a"; // Slate-900
      ctx.fillRect(0, 0, 680, 960);

      // Top Banner
      ctx.fillStyle = "#0ba4db"; // Paystack Cyan
      ctx.fillRect(0, 0, 680, 75);

      // Brand Logo text
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 24px Helvetica, Arial, sans-serif";
      ctx.fillText("paystack", 36, 46);

      ctx.font = "12px Helvetica, Arial, sans-serif";
      ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
      ctx.fillText("OFFICIAL PAYMENT RECEIPT & PROOF OF PAYMENT", 200, 46);

      // Receipt Card Container
      ctx.fillStyle = "#1e293b"; // Slate-800
      ctx.strokeStyle = "#334155";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(32, 95, 616, 825, 16);
      ctx.fill();
      ctx.stroke();

      // Status Badge
      ctx.fillStyle = "#064e3b";
      ctx.beginPath();
      ctx.roundRect(56, 120, 568, 38, 8);
      ctx.fill();
      ctx.fillStyle = "#34d399";
      ctx.font = "bold 13px Helvetica, Arial, sans-serif";
      ctx.fillText("✓ CLEARED & SETTLED - OFFICIAL PAYSTACK PAYMENT PROOF", 76, 144);

      // Large Amount
      ctx.fillStyle = "#ffffff";
      ctx.font = "bold 32px Helvetica, Arial, sans-serif";
      ctx.fillText(formattedUsd, 56, 205);

      ctx.fillStyle = "#38bdf8"; // Sky-400
      ctx.font = "bold 16px Helvetica, Arial, sans-serif";
      ctx.fillText(`${formattedNgn} (${rateStr})`, 56, 235);

      // Divider
      ctx.strokeStyle = "#334155";
      ctx.beginPath();
      ctx.moveTo(56, 260);
      ctx.lineTo(624, 260);
      ctx.stroke();

      // Details lines
      const details = [
        ["Receipt Number", receipt.receiptNumber],
        ["Transaction Reference", receipt.reference],
        ["Date & Time", formattedDate],
        ["Type / Category", isOutgoing ? "Direct Interbank Payout" : "Payment Receive / Deposit"],
        ["Sender / Payer", receipt.senderOrPayer],
        ["Beneficiary / Recipient", receipt.recipient],
        ["Bank / Institution", receipt.bankOrChannel],
        ["Clearing Rail", receipt.clearingRail || "Paystack Instant NIP (< 1.5s)"],
        ["Authorization Code", receipt.authCode || `AUTH-PSTK-${receipt.reference.slice(-8).toUpperCase()}`],
        ["Transfer Memo", receipt.memo || "Paystack Instant Settlement"],
      ];

      ctx.font = "12px Helvetica, Arial, sans-serif";
      details.forEach(([lbl, val], idx) => {
        const y = 290 + idx * 32;
        ctx.fillStyle = "#94a3b8"; // Slate-400
        ctx.fillText(lbl, 56, y);

        ctx.fillStyle = "#f8fafc"; // White
        ctx.font = "bold 12px Helvetica, Arial, sans-serif";
        const truncated = val.length > 40 ? val.slice(0, 37) + "..." : val;
        ctx.fillText(truncated, 260, y);
        ctx.font = "12px Helvetica, Arial, sans-serif";
      });

      // QR Code image if available
      if (qrDataUrl) {
        const img = new Image();
        img.onload = () => {
          ctx.drawImage(img, 56, 630, 110, 110);
          finishPng();
        };
        img.src = qrDataUrl;
      } else {
        finishPng();
      }

      function finishPng() {
        if (!ctx) return;
        // Hash section beside QR
        ctx.fillStyle = "#0f172a";
        ctx.beginPath();
        ctx.roundRect(185, 630, 439, 110, 8);
        ctx.fill();

        ctx.fillStyle = "#38bdf8";
        ctx.font = "bold 11px Helvetica, Arial, sans-serif";
        ctx.fillText("CRYPTOGRAPHIC SHA-256 AUDIT DIGEST:", 200, 655);

        ctx.fillStyle = "#94a3b8";
        ctx.font = "9px monospace";
        ctx.fillText(verificationHash.slice(0, 32), 200, 680);
        ctx.fillText(verificationHash.slice(32, 64), 200, 700);

        ctx.fillStyle = "#34d399";
        ctx.font = "bold 10px Helvetica, Arial, sans-serif";
        ctx.fillText("✓ 100% Tamper-Evident Digital Proof of Settlement", 200, 725);

        // Footer disclaimer
        ctx.fillStyle = "#64748b";
        ctx.font = "10px Helvetica, Arial, sans-serif";
        ctx.fillText("Paystack is licensed by the Central Bank of Nigeria (CBN). PCI-DSS Level 1 Certified.", 56, 785);
        ctx.fillText(`Official electronic payment certificate generated on ${new Date().toUTCString()}`, 56, 802);

        // Download PNG
        const pngUrl = canvas.toDataURL("image/png");
        const a = document.createElement("a");
        a.href = pngUrl;
        a.download = `Paystack_Receipt_${receipt?.reference.replace(/[^a-zA-Z0-9_-]/g, "_") || "tx"}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setIsGeneratingPng(false);
      }
    } catch (err) {
      console.error("Failed to generate PNG receipt:", err);
      setIsGeneratingPng(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleShare = async () => {
    const shareText = `Official Paystack Payment Receipt: ${receipt.receiptNumber} - ${formattedUsd} (${formattedNgn}) settled to ${receipt.recipient}`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Paystack Payment Receipt",
          text: shareText,
          url: window.location.href,
        });
      } catch (e) {
        // Fallback to clipboard
        handleCopyProofSummary();
      }
    } else {
      handleCopyProofSummary();
    }
  };

  return (
    <div
      id="modal-paystack-receipt"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-5 overflow-y-auto animate-in fade-in"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-2xl rounded-3xl bg-slate-950 border border-emerald-500/40 shadow-2xl overflow-hidden my-auto max-h-[94vh] flex flex-col">
        {/* Top Action Bar */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-3.5 border-b border-slate-800 bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400 font-black text-xs">
              PS
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <span>Paystack Proof of Payment</span>
                <span className="rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-bold">
                  VERIFIED
                </span>
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">
                {receipt.receiptNumber}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              title="Close modal"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Receipt Preview Area */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 bg-gradient-to-b from-slate-950 to-slate-900">
          {/* THE RECEIPT CARD (Styled like an authentic financial settlement advice) */}
          <div
            ref={receiptCardRef}
            id="printable-paystack-receipt"
            className="rounded-2xl bg-slate-900 border border-slate-800 p-5 sm:p-6 shadow-xl relative overflow-hidden space-y-5 text-slate-100"
          >
            {/* Holographic Watermark / Ambient glow */}
            <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-sky-500/10 blur-3xl pointer-events-none" />
            <div className="absolute -bottom-16 -left-16 w-48 h-48 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />

            {/* Receipt Header Banner */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-800/80">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xl font-black tracking-tight text-white">
                    pay<span className="text-sky-400">stack</span>
                  </span>
                  <span className="text-[10px] bg-sky-950 text-sky-400 px-2 py-0.5 rounded font-mono font-bold border border-sky-800/60">
                    INTERBANK SWITCH
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Official Electronic Settlement Advice &bull; CBN / NDPR Compliant
                </p>
              </div>

              <div className="text-right">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                  Receipt No.
                </span>
                <span className="text-xs sm:text-sm font-mono font-bold text-sky-300">
                  {receipt.receiptNumber}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  {new Date(receipt.timestamp).toLocaleDateString()}
                </span>
              </div>
            </div>

            {/* Status Alert Badge */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-extrabold uppercase tracking-wide">
                  {receipt.status || "CLEARED & SETTLED"} &bull; Instant Finality
                </span>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 hidden sm:inline">
                NIP Direct Switch
              </span>
            </div>

            {/* Primary Amount Card */}
            <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-800/90 text-center space-y-1.5 relative">
              <div className="flex items-center justify-center gap-1.5 text-xs font-semibold">
                {isOutgoing ? (
                  <span className="text-rose-400 flex items-center gap-1">
                    <ArrowUpRight className="w-3.5 h-3.5" /> Outgoing Transfer Payout
                  </span>
                ) : (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <ArrowDownLeft className="w-3.5 h-3.5" /> Incoming Dollar Deposit
                  </span>
                )}
              </div>

              <div className="text-3xl sm:text-4xl font-black font-mono tracking-tight text-white">
                {formattedUsd}
              </div>

              <div className="text-xs sm:text-sm font-bold text-sky-400 font-mono">
                {formattedNgn}
              </div>

              <div className="text-[10px] text-slate-400 font-mono pt-1">
                Exchange Benchmark: <span className="text-slate-300">{rateStr}</span>
              </div>
            </div>

            {/* Structured Specifications Grid */}
            <div className="space-y-2 text-xs font-mono">
              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider pb-1">
                Transaction Specifications
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 uppercase">Sender / Source</span>
                  <span className="text-white font-bold truncate mt-0.5">{receipt.senderOrPayer}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 uppercase">Beneficiary / Recipient</span>
                  <span className="text-emerald-400 font-bold truncate mt-0.5">{receipt.recipient}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 uppercase">Bank / Destination Channel</span>
                  <span className="text-white font-semibold truncate mt-0.5">{receipt.bankOrChannel}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 uppercase">Clearing Rail</span>
                  <span className="text-sky-300 truncate mt-0.5">{receipt.clearingRail || "Paystack Instant NIP Switch (< 1.5s)"}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between sm:col-span-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 uppercase">Transaction Reference</span>
                    <button
                      onClick={() => handleCopyText(receipt.reference, "ref")}
                      className="text-[10px] text-sky-400 hover:text-sky-300 flex items-center gap-1 cursor-pointer"
                    >
                      {copiedField === "ref" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === "ref" ? "Copied" : "Copy Ref"}</span>
                    </button>
                  </div>
                  <span className="text-white font-mono text-xs break-all mt-0.5">{receipt.reference}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between sm:col-span-2">
                  <span className="text-[10px] text-slate-400 uppercase">Memo / Purpose</span>
                  <span className="text-slate-200 mt-0.5">{receipt.memo || "Paystack Dollar Settlement"}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 uppercase">Timestamp</span>
                  <span className="text-slate-300 mt-0.5">{formattedDate}</span>
                </div>

                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-400 uppercase">Auth Code</span>
                  <span className="text-emerald-400 font-mono mt-0.5">
                    {receipt.authCode || `AUTH-PSTK-${receipt.reference.slice(-8).toUpperCase()}`}
                  </span>
                </div>
              </div>
            </div>

            {/* QR Code & Tamper-Proof Cryptographic Verification */}
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center gap-4">
              {qrDataUrl ? (
                <div className="p-1.5 bg-white rounded-xl shadow-md shrink-0">
                  <img src={qrDataUrl} alt="Receipt QR Code" className="w-20 h-20 sm:w-22 sm:h-22" />
                </div>
              ) : (
                <div className="w-20 h-20 bg-slate-800 rounded-xl flex items-center justify-center shrink-0">
                  <QrIcon className="w-6 h-6 text-slate-500" />
                </div>
              )}

              <div className="space-y-1 text-center sm:text-left min-w-0 flex-1">
                <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs font-bold text-sky-400">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Tamper-Evident Cryptographic Proof</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-tight">
                  Scan QR code with your smartphone to verify non-repudiable proof of settlement.
                </p>
                <div className="pt-1">
                  <span className="text-[9px] text-slate-400 block font-mono">SHA-256 Digest:</span>
                  <span className="text-[10px] font-mono text-emerald-300 break-all select-all block">
                    {verificationHash}
                  </span>
                </div>
              </div>
            </div>

            {/* Footer Legal & Security Note */}
            <div className="text-[10px] text-slate-400 text-center pt-2 border-t border-slate-800 space-y-1">
              <p>
                Paystack is a licensed payment switch regulated by the Central Bank of Nigeria (CBN). PCI-DSS Level 1.
              </p>
              <p className="font-mono text-slate-400">
                Generated via HEOFLIX Paystack Gateway &bull; Reference: {receipt.reference}
              </p>
            </div>
          </div>

          {/* ACTION BUTTONS TOOLBAR (Download PDF, PNG, Print, Copy, Share) */}
          <div className="space-y-3 pt-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* PRIMARY: Download PDF Button */}
              <button
                id="btn-download-receipt-pdf"
                onClick={handleDownloadPdf}
                disabled={isGeneratingPdf}
                className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-sky-500 to-emerald-500 hover:from-sky-400 hover:to-emerald-400 text-slate-950 font-black text-xs sm:text-sm shadow-xl shadow-sky-500/20 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Download className="w-4 h-4" />
                <span>
                  {isGeneratingPdf ? "Building Vector PDF..." : "Download Official PDF Receipt"}
                </span>
              </button>

              {/* SECONDARY: Download PNG Image */}
              <button
                id="btn-download-receipt-png"
                onClick={handleDownloadPng}
                disabled={isGeneratingPng}
                className="w-full py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs sm:text-sm border border-slate-700 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <FileText className="w-4 h-4 text-sky-400" />
                <span>{isGeneratingPng ? "Exporting Image..." : "Download Image (PNG)"}</span>
              </button>
            </div>

            {/* Quick Actions Row */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                id="btn-print-receipt"
                onClick={handlePrint}
                className="flex-1 min-w-[120px] py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-semibold transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-slate-400" />
                <span>Print Receipt</span>
              </button>

              <button
                id="btn-copy-receipt-proof"
                onClick={handleCopyProofSummary}
                className="flex-1 min-w-[120px] py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-semibold transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {copiedField === "summary" ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                )}
                <span>{copiedField === "summary" ? "Proof Copied!" : "Copy Proof Summary"}</span>
              </button>

              <button
                id="btn-share-receipt"
                onClick={handleShare}
                className="flex-1 min-w-[100px] py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 text-xs font-semibold transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5 text-slate-400" />
                <span>Share Proof</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
