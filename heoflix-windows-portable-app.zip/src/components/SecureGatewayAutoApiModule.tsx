import React, { useState, useEffect } from "react";
import {
  ShieldCheck,
  Key,
  Lock,
  Zap,
  Copy,
  Check,
  RefreshCw,
  Plus,
  Trash2,
  Code2,
  Terminal,
  Send,
  Coins,
  ArrowRight,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  Activity,
  Layers,
  Sparkles,
  Server,
  DollarSign,
  Radio,
  FileCheck,
  Globe,
  Sliders,
} from "lucide-react";
import { WalletState, SecureGatewayApiKey, CryptoPayoutOrder } from "../types";

interface SecureGatewayAutoApiModuleProps {
  wallet?: WalletState;
  onUpdateWallet?: (newWallet: WalletState) => void;
  onRefreshAllData?: () => void;
}

export const SecureGatewayAutoApiModule: React.FC<SecureGatewayAutoApiModuleProps> = ({
  wallet,
  onUpdateWallet,
  onRefreshAllData,
}) => {
  const [activeMainTab, setActiveMainTab] = useState<"secure_gateway" | "crypto_payout">("secure_gateway");
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // SECURE GATEWAY STATE
  const [gatewayStatus, setGatewayStatus] = useState<any>(null);
  const [gatewayKeys, setGatewayKeys] = useState<SecureGatewayApiKey[]>([]);
  const [gatewayCharges, setGatewayCharges] = useState<any[]>([]);
  const [gatewayDocs, setGatewayDocs] = useState<any>(null);
  const [selectedLanguage, setSelectedLanguage] = useState<"curl" | "node" | "python" | "php" | "go">("curl");

  // Charge Simulator Form State
  const [simChargeAmount, setSimChargeAmount] = useState<string>("150");
  const [simPaymentMethod, setSimPaymentMethod] = useState<string>("CARD");
  const [simCustomerEmail, setSimCustomerEmail] = useState<string>("finance.corp@sovereign.com");
  const [simCustomerName, setSimCustomerName] = useState<string>("George Felix Egwu Enterprise");
  const [isProcessingCharge, setIsProcessingCharge] = useState<boolean>(false);
  const [chargeResult, setChargeResult] = useState<any>(null);

  // Key Generator Modal / Form
  const [newKeyType, setNewKeyType] = useState<"LIVE" | "TEST">("LIVE");
  const [newKeyLabel, setNewKeyLabel] = useState<string>("Primary E-Commerce Integration Key");
  const [isGeneratingKey, setIsGeneratingKey] = useState<boolean>(false);

  // CRYPTO PAYOUT STATE
  const [cryptoStatus, setCryptoStatus] = useState<any>(null);
  const [cryptoKeys, setCryptoKeys] = useState<any[]>([]);
  const [cryptoOrders, setCryptoOrders] = useState<CryptoPayoutOrder[]>([]);
  const [cryptoRates, setCryptoRates] = useState<any>(null);
  const [cryptoDocs, setCryptoDocs] = useState<any>(null);

  // Crypto Payout Form State
  const [payoutToken, setPayoutToken] = useState<string>("USDT");
  const [payoutNetwork, setPayoutNetwork] = useState<string>("TRC20");
  const [payoutAddress, setPayoutAddress] = useState<string>("TYDny55a3Ksmk4V2dJ4K5VwU9qE2o3W6Vz");
  const [payoutAmount, setPayoutAmount] = useState<string>("250");
  const [isBroadcastingPayout, setIsBroadcastingPayout] = useState<boolean>(false);
  const [payoutResult, setPayoutResult] = useState<any>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    showToast(`Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedText(null), 2500);
  };

  // Fetch Gateway Data
  const fetchGatewayData = async () => {
    try {
      const [statusRes, keysRes, txsRes, docsRes] = await Promise.all([
        fetch("/api/v1/secure-gateway/status").then((r) => r.json()).catch(() => null),
        fetch("/api/v1/secure-gateway/keys").then((r) => r.json()).catch(() => null),
        fetch("/api/v1/secure-gateway/transactions").then((r) => r.json()).catch(() => null),
        fetch("/api/v1/secure-gateway/api-docs").then((r) => r.json()).catch(() => null),
      ]);

      if (statusRes?.success) setGatewayStatus(statusRes.gateway);
      if (keysRes?.success) setGatewayKeys(keysRes.keys);
      if (txsRes?.success) setGatewayCharges(txsRes.transactions);
      if (docsRes?.success) setGatewayDocs(docsRes);
    } catch (e) {
      console.error("Error fetching secure gateway data:", e);
    }
  };

  // Fetch Crypto Payout Data
  const fetchCryptoData = async () => {
    try {
      const [statusRes, keysRes, txsRes, ratesRes, docsRes] = await Promise.all([
        fetch("/api/v1/crypto-payout/status").then((r) => r.json()).catch(() => null),
        fetch("/api/v1/crypto-payout/keys").then((r) => r.json()).catch(() => null),
        fetch("/api/v1/crypto-payout/transactions").then((r) => r.json()).catch(() => null),
        fetch("/api/v1/crypto-payout/rates").then((r) => r.json()).catch(() => null),
        fetch("/api/v1/crypto-payout/api-docs").then((r) => r.json()).catch(() => null),
      ]);

      if (statusRes?.success) setCryptoStatus(statusRes.infrastructure);
      if (keysRes?.success) setCryptoKeys(keysRes.keys);
      if (txsRes?.success) setCryptoOrders(txsRes.transactions);
      if (ratesRes?.success) setCryptoRates(ratesRes);
      if (docsRes?.success) setCryptoDocs(docsRes);
    } catch (e) {
      console.error("Error fetching crypto payout data:", e);
    }
  };

  useEffect(() => {
    fetchGatewayData();
    fetchCryptoData();
  }, []);

  // 1. GENERATE SECURE GATEWAY API KEY
  const handleGenerateGatewayKey = async () => {
    setIsGeneratingKey(true);
    try {
      const res = await fetch("/api/v1/secure-gateway/keys/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: newKeyType,
          label: newKeyLabel,
          permissions: ["payments:charge", "payments:refund", "transfers:payout", "webhooks:read"],
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showToast(data.message || "API Key generated successfully!");
        fetchGatewayData();
      } else {
        showToast(data.error || "Failed to generate key.");
      }
    } catch (e: any) {
      showToast(e.message || "Network error generating key.");
    } finally {
      setIsGeneratingKey(false);
    }
  };

  // 2. REVOKE GATEWAY API KEY
  const handleRevokeGatewayKey = async (keyId: string) => {
    try {
      const res = await fetch(`/api/v1/secure-gateway/keys/${keyId}`, { method: "DELETE" });
      const data = await res.json();
      if (res.ok && data.success) {
        showToast("API Key successfully revoked.");
        fetchGatewayData();
      }
    } catch (e: any) {
      showToast(e.message || "Error revoking key.");
    }
  };

  // 3. EXECUTE SIMULATED CHARGE
  const handleExecuteCharge = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(simChargeAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast("Please enter a valid amount.");
      return;
    }

    setIsProcessingCharge(true);
    setChargeResult(null);
    try {
      const res = await fetch("/api/v1/secure-gateway/charge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: amt,
          currency: "USD",
          paymentMethod: simPaymentMethod,
          customerEmail: simCustomerEmail,
          customerName: simCustomerName,
          memo: "Commercial Multi-Rail Inflow via Secure Payment Gateway",
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setChargeResult(data);
        showToast(`Charged $${amt.toFixed(2)} USD successfully!`);
        fetchGatewayData();
        if (onRefreshAllData) onRefreshAllData();
      } else {
        showToast(data.error || "Failed to process charge.");
      }
    } catch (err: any) {
      showToast(err.message || "Error processing charge.");
    } finally {
      setIsProcessingCharge(false);
    }
  };

  // 4. GENERATE CRYPTO PAYOUT API KEY
  const handleGenerateCryptoKey = async () => {
    setIsGeneratingKey(true);
    try {
      const res = await fetch("/api/v1/crypto-payout/keys/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "LIVE",
          label: "Automated Treasury Payout Key",
          dailyLimitUsd: 250000,
          multiSigRequired: true,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        showToast(data.message || "Crypto Payout API Key generated!");
        fetchCryptoData();
      } else {
        showToast(data.error || "Failed to generate crypto key.");
      }
    } catch (e: any) {
      showToast(e.message || "Network error generating crypto key.");
    } finally {
      setIsGeneratingKey(false);
    }
  };

  // 5. EXECUTE CRYPTO PAYOUT
  const handleExecuteCryptoPayout = async (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(payoutAmount);
    if (!payoutAddress.trim() || isNaN(amt) || amt <= 0) {
      showToast("Please provide a valid address and amount.");
      return;
    }

    setIsBroadcastingPayout(true);
    setPayoutResult(null);
    try {
      const res = await fetch("/api/v1/crypto-payout/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: payoutToken,
          network: payoutNetwork,
          recipientAddress: payoutAddress,
          recipientName: "George Felix Egwu Vault",
          amount: amt,
          memo: "Disbursement via Automated Crypto Payout Infrastructure",
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setPayoutResult(data);
        showToast(`Crypto payout broadcasted! TXID: ${data.payout?.txid?.slice(0, 12)}...`);
        fetchCryptoData();
        if (onRefreshAllData) onRefreshAllData();
      } else {
        showToast(data.error || "Failed to broadcast payout.");
      }
    } catch (err: any) {
      showToast(err.message || "Error broadcasting crypto payout.");
    } finally {
      setIsBroadcastingPayout(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 rounded-2xl bg-slate-900 border border-emerald-500/50 p-4 text-xs font-bold text-white shadow-2xl flex items-center gap-2 animate-in fade-in">
          <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* DUAL HEADER NAVIGATION */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-4 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-500/20 via-indigo-500/20 to-emerald-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
              <span>Secure Payment Gateway &amp; Crypto Payout Suite</span>
              <span className="rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 text-[10px] font-bold">
                AUTO-GENERATED REST API
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              End-to-end encrypted multi-rail processing &bull; Programmatic API key generation &bull; Real-time blockchain broadcast
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-950 border border-slate-800">
          <button
            id="tab-sub-secure-gateway"
            onClick={() => setActiveMainTab("secure_gateway")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeMainTab === "secure_gateway"
                ? "bg-gradient-to-r from-sky-600 to-indigo-600 text-white shadow-md shadow-sky-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-sky-400" />
            <span>Secure Payment Gateway</span>
          </button>

          <button
            id="tab-sub-crypto-payout"
            onClick={() => setActiveMainTab("crypto_payout")}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeMainTab === "crypto_payout"
                ? "bg-gradient-to-r from-amber-600 to-emerald-600 text-white shadow-md shadow-amber-600/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Coins className="w-4 h-4 text-amber-400" />
            <span>Crypto Payout Infrastructure</span>
          </button>
        </div>
      </div>

      {/* =========================================================================
          VIEW 1: SECURE PAYMENT GATEWAY & AUTOMATICALLY GENERATED API
      ========================================================================= */}
      {activeMainTab === "secure_gateway" && (
        <div className="space-y-6">
          {/* Top Status & Security Badges */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase">Gateway Standard</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono font-bold">
                  PCI-DSS LVL 1
                </span>
              </div>
              <div className="text-base font-extrabold text-white">Bank-Grade Multi-Rail Processing</div>
              <p className="text-[11px] text-slate-400">
                AES-256-GCM tokenization &bull; TLS 1.3 &bull; 3D-Secure 2.2 challenge automation
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase">Active Generated Keys</span>
                <span className="text-[10px] bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded font-mono font-bold">
                  AUTONOMOUS API
                </span>
              </div>
              <div className="text-2xl font-black text-sky-400 font-mono">
                {gatewayKeys.filter((k) => k.status === "ACTIVE").length} Active Keys
              </div>
              <p className="text-[11px] text-slate-400">
                Programmable keys with scoped authorizations and custom rate limits
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-400 uppercase">Settled Volume (Today)</span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono font-bold">
                  CLEARED
                </span>
              </div>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                ${gatewayCharges.reduce((acc, c) => acc + (c.amountUsd || 0), 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
              </div>
              <p className="text-[11px] text-slate-400">
                {gatewayCharges.length} cleared charges synchronized directly to Dollar Wallet
              </p>
            </div>
          </div>

          {/* SECTION A: AUTOMATICALLY GENERATED API KEYS MANAGER */}
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-800">
              <div className="space-y-1">
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <Key className="w-4 h-4 text-sky-400" />
                  <span>Automatically Generated API Keys</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Authenticate programmatic payment requests via <code className="text-sky-300 font-mono">X-Gateway-Api-Key</code> header
                </p>
              </div>

              {/* Quick Generate Key Button */}
              <button
                id="btn-auto-generate-gateway-key"
                onClick={handleGenerateGatewayKey}
                disabled={isGeneratingKey}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-black text-xs shadow-lg transition cursor-pointer disabled:opacity-50"
              >
                <Plus className="w-4 h-4" />
                <span>{isGeneratingKey ? "Generating..." : "Generate New API Key"}</span>
              </button>
            </div>

            {/* Keys Table / Cards */}
            <div className="space-y-3">
              {gatewayKeys.map((k) => (
                <div
                  key={k.keyId}
                  className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{k.label}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          k.type === "LIVE"
                            ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                            : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                        }`}
                      >
                        {k.type}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          k.status === "ACTIVE" ? "bg-sky-500/10 text-sky-300" : "bg-rose-500/10 text-rose-400"
                        }`}
                      >
                        {k.status}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 font-mono text-slate-300 text-[11px]">
                      <span className="text-slate-400">API Key:</span>
                      <span className="bg-slate-900 px-2 py-1 rounded-lg border border-slate-800 truncate max-w-xs sm:max-w-md">
                        {k.apiKey}
                      </span>
                      <button
                        onClick={() => copyToClipboard(k.apiKey, `API Key (${k.label})`)}
                        className="text-sky-400 hover:text-sky-300 p-1 rounded hover:bg-slate-800 transition"
                        title="Copy Key"
                      >
                        {copiedText === `API Key (${k.label})` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    <div className="text-[11px] text-slate-400 flex flex-wrap gap-2 pt-0.5">
                      <span>Permissions: <strong className="text-slate-300">{k.permissions.join(", ")}</strong></span>
                      <span>&bull;</span>
                      <span>Daily Limit: <strong className="text-emerald-400">${k.dailyLimitUsd.toLocaleString()} USD</strong></span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {k.status === "ACTIVE" && (
                      <button
                        onClick={() => handleRevokeGatewayKey(k.keyId)}
                        className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-slate-800 hover:border-rose-500/30 transition text-xs font-semibold"
                      >
                        Revoke Key
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* SECTION B: CHARGE SIMULATOR & INTERACTIVE CODE SNIPPETS */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Charge Execution Lab (Left Column) */}
            <div className="lg:col-span-6 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-white">Live Charge Execution Lab</h3>
                  <p className="text-xs text-slate-400">Test immediate encrypted payment settlement</p>
                </div>
              </div>

              <form onSubmit={handleExecuteCharge} className="space-y-3.5 text-xs">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Charge Amount (USD)</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-2.5 text-xs text-slate-400 font-bold">$</span>
                    <input
                      type="number"
                      required
                      min="1"
                      value={simChargeAmount}
                      onChange={(e) => setSimChargeAmount(e.target.value)}
                      className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono font-bold text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Payment Rail</label>
                    <select
                      value={simPaymentMethod}
                      onChange={(e) => setSimPaymentMethod(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    >
                      <option value="CARD">Visa / Mastercard 3DS</option>
                      <option value="FEDNOW">FedNow Real-Time ACH</option>
                      <option value="PAYSTACK">Paystack NIP Switch</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Customer Email</label>
                    <input
                      type="email"
                      required
                      value={simCustomerEmail}
                      onChange={(e) => setSimCustomerEmail(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Customer / Entity Name</label>
                  <input
                    type="text"
                    required
                    value={simCustomerName}
                    onChange={(e) => setSimCustomerName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <button
                  id="btn-submit-simulated-charge"
                  type="submit"
                  disabled={isProcessingCharge}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Zap className="w-4 h-4 fill-current" />
                  <span>{isProcessingCharge ? "Encrypting & Charging..." : `Execute Secure Charge ($${simChargeAmount} USD)`}</span>
                </button>

                {/* Charge Execution Result Card */}
                {chargeResult && (
                  <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-2 font-mono text-[11px] animate-in fade-in">
                    <div className="flex items-center justify-between text-emerald-400 font-bold">
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Charge Succeeded &amp; Dollar Wallet Credited!</span>
                      </div>
                      <span>{chargeResult.charge?.status}</span>
                    </div>

                    <div className="flex justify-between text-slate-300">
                      <span className="text-slate-400">Charge ID:</span>
                      <span className="text-white font-bold">{chargeResult.charge?.id}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span className="text-slate-400">Auth Code:</span>
                      <span className="text-sky-300">{chargeResult.charge?.authCode}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span className="text-slate-400">HMAC Signature:</span>
                      <span className="text-emerald-300 truncate max-w-[200px]">{chargeResult.charge?.hmacSignature}</span>
                    </div>
                  </div>
                )}
              </form>
            </div>

            {/* Automatically Generated Interactive Code Snippets (Right Column) */}
            <div className="lg:col-span-6 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 border border-sky-500/40 flex items-center justify-center">
                    <Code2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm sm:text-base font-extrabold text-white">Automated API Integration Code</h3>
                    <p className="text-xs text-slate-400">Ready-to-use production SDK snippets</p>
                  </div>
                </div>

                {/* Language Switcher */}
                <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-bold">
                  {(["curl", "node", "python", "php", "go"] as const).map((lang) => (
                    <button
                      key={lang}
                      onClick={() => setSelectedLanguage(lang)}
                      className={`px-2.5 py-1 rounded-lg uppercase transition ${
                        selectedLanguage === lang ? "bg-sky-600 text-white" : "text-slate-400 hover:text-white"
                      }`}
                    >
                      {lang}
                    </button>
                  ))}
                </div>
              </div>

              {/* Code Snippet Box */}
              <div className="relative">
                <button
                  onClick={() => {
                    const snippet =
                      selectedLanguage === "curl"
                        ? gatewayDocs?.endpoints?.[0]?.curlSnippet
                        : selectedLanguage === "node"
                        ? gatewayDocs?.endpoints?.[0]?.nodeSnippet
                        : selectedLanguage === "python"
                        ? gatewayDocs?.endpoints?.[0]?.pythonSnippet
                        : selectedLanguage === "php"
                        ? gatewayDocs?.endpoints?.[0]?.phpSnippet
                        : gatewayDocs?.endpoints?.[0]?.goSnippet;
                    if (snippet) copyToClipboard(snippet, `${selectedLanguage.toUpperCase()} Code Snippet`);
                  }}
                  className="absolute right-3 top-3 p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs flex items-center gap-1 transition cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Code</span>
                </button>

                <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-sky-300 font-mono text-xs overflow-x-auto leading-relaxed max-h-80 select-all">
                  {selectedLanguage === "curl" && (gatewayDocs?.endpoints?.[0]?.curlSnippet || "# Loading cURL snippet...")}
                  {selectedLanguage === "node" && (gatewayDocs?.endpoints?.[0]?.nodeSnippet || "// Loading Node.js snippet...")}
                  {selectedLanguage === "python" && (gatewayDocs?.endpoints?.[0]?.pythonSnippet || "# Loading Python snippet...")}
                  {selectedLanguage === "php" && (gatewayDocs?.endpoints?.[0]?.phpSnippet || "// Loading PHP snippet...")}
                  {selectedLanguage === "go" && (gatewayDocs?.endpoints?.[0]?.goSnippet || "// Loading Go snippet...")}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          VIEW 2: CRYPTO PAYOUT INFRASTRUCTURE & AUTOMATICALLY GENERATED API
      ========================================================================= */}
      {activeMainTab === "crypto_payout" && (
        <div className="space-y-6">
          {/* Top Network Capabilities */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Supported Blockchains</span>
              <div className="text-lg font-black text-white">BTC, TRON, ETH, SOL</div>
              <span className="text-[10px] text-emerald-400">Native SegWit &amp; L2 Ready</span>
            </div>

            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Bitcoin Exchange Rate</span>
              <div className="text-lg font-black text-amber-400 font-mono">$65,000.00 USD</div>
              <span className="text-[10px] text-slate-400">Direct Mempool Broadcast</span>
            </div>

            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase">USDT TRON Gas Fee</span>
              <div className="text-lg font-black text-sky-400 font-mono">$1.00 Fixed Energy</div>
              <span className="text-[10px] text-slate-400">Sub-30s Finality</span>
            </div>

            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Total Payouts Broadcasted</span>
              <div className="text-lg font-black text-emerald-400 font-mono">{cryptoOrders.length} Completed</div>
              <span className="text-[10px] text-slate-400">100% Chain Finality</span>
            </div>
          </div>

          {/* SECTION A: GENERATED CRYPTO API KEYS */}
          <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-800">
              <div className="space-y-1">
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <Coins className="w-4 h-4 text-amber-400" />
                  <span>Programmatic Crypto Payout API Keys</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Authenticate programmatic blockchain payouts via <code className="text-amber-300 font-mono">X-Crypto-Payout-Key</code>
                </p>
              </div>

              <button
                id="btn-generate-crypto-payout-key"
                onClick={handleGenerateCryptoKey}
                disabled={isGeneratingKey}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-emerald-600 hover:from-amber-400 hover:to-emerald-500 text-white font-black text-xs shadow-lg transition cursor-pointer disabled:opacity-50"
              >
                <Plus className="w-4 h-4" />
                <span>{isGeneratingKey ? "Generating..." : "Generate Crypto API Key"}</span>
              </button>
            </div>

            <div className="space-y-3">
              {cryptoKeys.map((k) => (
                <div
                  key={k.keyId}
                  className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <strong className="text-white text-sm">{k.label}</strong>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">
                        {k.type}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 font-mono text-slate-300 text-[11px]">
                      <span className="text-slate-400">API Key:</span>
                      <span className="bg-slate-900 px-2 py-1 rounded-lg border border-slate-800 truncate max-w-xs sm:max-w-md">
                        {k.apiKey}
                      </span>
                      <button
                        onClick={() => copyToClipboard(k.apiKey, `Crypto Key (${k.label})`)}
                        className="text-amber-400 hover:text-amber-300 p-1 rounded hover:bg-slate-800 transition"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-[11px] text-slate-400 flex flex-wrap gap-2">
                      <span>Max Daily: <strong className="text-emerald-400">${k.dailyLimitUsd.toLocaleString()} USD</strong></span>
                      <span>&bull;</span>
                      <span>Multi-Sig: <strong className="text-sky-300">{k.multiSigRequired ? "Enforced" : "Standard"}</strong></span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* SECTION B: DISBURSE CRYPTO PAYOUT LAB */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Form */}
            <div className="lg:col-span-6 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center">
                  <Send className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-extrabold text-white">Execute Crypto Payout</h3>
                  <p className="text-xs text-slate-400">Broadcast immediate on-chain cryptocurrency transfer</p>
                </div>
              </div>

              <form onSubmit={handleExecuteCryptoPayout} className="space-y-3.5 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Asset Token</label>
                    <select
                      value={payoutToken}
                      onChange={(e) => {
                        setPayoutToken(e.target.value);
                        if (e.target.value === "BTC") {
                          setPayoutNetwork("BITCOIN");
                          setPayoutAddress("34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW");
                        } else if (e.target.value === "USDT") {
                          setPayoutNetwork("TRC20");
                          setPayoutAddress("TYDny55a3Ksmk4V2dJ4K5VwU9qE2o3W6Vz");
                        } else if (e.target.value === "USDC") {
                          setPayoutNetwork("SOL");
                          setPayoutAddress("7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU");
                        }
                      }}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      <option value="USDT">USDT (Tether)</option>
                      <option value="BTC">Bitcoin (BTC)</option>
                      <option value="USDC">USDC (USD Coin)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-300 font-semibold block mb-1">Target Network</label>
                    <select
                      value={payoutNetwork}
                      onChange={(e) => setPayoutNetwork(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-bold text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                    >
                      {payoutToken === "BTC" && <option value="BITCOIN">Bitcoin Mainnet (SegWit)</option>}
                      {payoutToken === "USDT" && (
                        <>
                          <option value="TRC20">TRON TRC-20 ($1 Gas)</option>
                          <option value="ERC20">Ethereum ERC-20</option>
                          <option value="POLYGON">Polygon PoS</option>
                        </>
                      )}
                      {payoutToken === "USDC" && (
                        <>
                          <option value="SOL">Solana SPL Token (&lt; 2s)</option>
                          <option value="ERC20">Ethereum ERC-20</option>
                        </>
                      )}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Recipient Public Address</label>
                  <input
                    type="text"
                    required
                    value={payoutAddress}
                    onChange={(e) => setPayoutAddress(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Payout Amount ({payoutToken})</label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={payoutAmount}
                    onChange={(e) => setPayoutAmount(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono font-bold text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>

                <button
                  id="btn-broadcast-crypto-payout"
                  type="submit"
                  disabled={isBroadcastingPayout}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-emerald-600 hover:from-amber-400 hover:to-emerald-500 text-white font-black text-xs shadow-lg transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{isBroadcastingPayout ? "Broadcasting to Blockchain..." : `Broadcast ${payoutAmount} ${payoutToken} Payout`}</span>
                </button>

                {payoutResult && (
                  <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-2 font-mono text-[11px] animate-in fade-in">
                    <div className="flex items-center justify-between text-emerald-400 font-bold">
                      <div className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Transaction Broadcasted &amp; Confirmed!</span>
                      </div>
                      <span>{payoutResult.payout?.status}</span>
                    </div>

                    <div className="flex justify-between text-slate-300">
                      <span className="text-slate-400">TXID:</span>
                      <a
                        href={payoutResult.payout?.explorerUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sky-400 hover:underline flex items-center gap-1 truncate max-w-[200px]"
                      >
                        <span>{payoutResult.payout?.txid?.slice(0, 16)}...</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                )}
              </form>
            </div>

            {/* Payouts Ledger (Right Column) */}
            <div className="lg:col-span-6 p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-sm sm:text-base font-extrabold text-white">Recent Blockchain Payouts</h3>
                </div>
                <span className="text-xs font-mono text-slate-400">{cryptoOrders.length} Records</span>
              </div>

              <div className="space-y-2.5 max-h-80 overflow-y-auto">
                {cryptoOrders.map((ord) => (
                  <div
                    key={ord.id}
                    className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-white font-bold">
                        {ord.amount} {ord.token} ({ord.network})
                      </span>
                      <span className="text-emerald-400 font-bold">${ord.amountUsd.toFixed(2)} USD</span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span className="truncate max-w-[180px]">{ord.recipientAddress}</span>
                      <a
                        href={ord.explorerUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sky-400 hover:underline flex items-center gap-1"
                      >
                        <span>View Explorer</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
