import React, { useState, useEffect } from "react";
import {
  WalletState,
  NativeBlockchainBlock,
  GeneratedSecretKeyData,
} from "../types";
import {
  Key,
  Layers,
  Cpu,
  ShieldCheck,
  ShieldAlert,
  Copy,
  Check,
  RefreshCw,
  Eye,
  EyeOff,
  Zap,
  Lock,
  Unlock,
  Sparkles,
  Download,
  Terminal,
  Activity,
  CheckCircle2,
  AlertCircle,
  FileText,
  Search,
  ArrowRight,
  Send,
  Boxes,
  Compass,
  Globe,
  Network,
  Radio,
  FileCode,
  ExternalLink,
  Database,
} from "lucide-react";

interface BlockchainStudioProps {
  wallet: WalletState;
  onUpdateWallet?: (updated: WalletState) => void;
  onNavigateToWallet?: () => void;
}

export const BlockchainStudio: React.FC<BlockchainStudioProps> = ({
  wallet,
  onUpdateWallet,
  onNavigateToWallet,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<
    "key_studio" | "explorer" | "blockcypher" | "bitcore_lib" | "node_rpc" | "miner" | "signer"
  >("key_studio");

  // Blockchain state
  const [blocks, setBlocks] = useState<NativeBlockchainBlock[]>([]);
  const [isLoadingBlocks, setIsLoadingBlocks] = useState<boolean>(true);
  const [chainIntegrity, setChainIntegrity] = useState<{
    verified: boolean;
    isValid: boolean;
    reason: string;
    brokenIndex: number | null;
  }>({
    verified: true,
    isValid: true,
    reason: "Cryptographically verified & intact",
    brokenIndex: null,
  });

  // Key Studio State
  const [customPassphrase, setCustomPassphrase] = useState<string>(
    "Sovereign Master Vault 2026 [Identity Masked]"
  );
  const [selectedAlgorithm, setSelectedAlgorithm] = useState<
    "secp256k1" | "ed25519" | "bip39" | "aes256"
  >("secp256k1");
  const [generatedKey, setGeneratedKey] = useState<GeneratedSecretKeyData | null>(null);
  const [isGeneratingKey, setIsGeneratingKey] = useState<boolean>(false);
  const [showSecretKey, setShowSecretKey] = useState<boolean>(false);
  const [activeBoundAddress, setActiveBoundAddress] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [bindSuccessMsg, setBindSuccessMsg] = useState<string>("");

  // Miner State
  const [minerName, setMinerName] = useState<string>("Sovereign Node #1 [Identity Masked]");
  const [miningMemo, setMiningMemo] = useState<string>("Verified Settlement to OPAY 8134762646");
  const [miningDifficulty, setMiningDifficulty] = useState<number>(2);
  const [isMining, setIsMining] = useState<boolean>(false);
  const [lastMinedStats, setLastMinedStats] = useState<any>(null);

  // Signer Sandbox State
  const [signMessageText, setSignMessageText] = useState<string>(
    "Transfer $10,000 USD from Sovereign Dollar Vault to OPAY 8134762646"
  );
  const [signatureResult, setSignatureResult] = useState<string>("");
  const [verifyStatus, setVerifyStatus] = useState<{
    tested: boolean;
    isValid: boolean;
  }>({ tested: false, isValid: false });

  // Search in Explorer
  const [searchQuery, setSearchQuery] = useState<string>("");

  // BlockCypher State & Handlers
  const [blockcypherData, setBlockcypherData] = useState<any>(null);
  const [isLoadingBlockcypher, setIsLoadingBlockcypher] = useState<boolean>(false);
  const [addressQuery, setAddressQuery] = useState<string>("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa");
  const [addressResult, setAddressResult] = useState<any>(null);
  const [isQueryingAddress, setIsQueryingAddress] = useState<boolean>(false);
  const [txQuery, setTxQuery] = useState<string>("");
  const [txResult, setTxResult] = useState<any>(null);
  const [isQueryingTx, setIsQueryingTx] = useState<boolean>(false);
  const [rawTxToBroadcast, setRawTxToBroadcast] = useState<string>("");
  const [broadcastResult, setBroadcastResult] = useState<any>(null);
  const [isBroadcasting, setIsBroadcasting] = useState<boolean>(false);

  // Bitcore-lib State & Handlers
  const [bitcoreNet, setBitcoreNet] = useState<"mainnet" | "testnet">("mainnet");
  const [bitcorePassphrase, setBitcorePassphrase] = useState<string>("George Felix Egwu Master Sovereign Enclave");
  const [bitcoreGeneratedKey, setBitcoreGeneratedKey] = useState<any>(null);
  const [isGeneratingBitcoreKey, setIsGeneratingBitcoreKey] = useState<boolean>(false);
  const [inspectAddressInput, setInspectAddressInput] = useState<string>("1BmRd2CEPiEpTrLuz4KErLuUJP1h9E7Cgs");
  const [inspectAddressResult, setInspectAddressResult] = useState<any>(null);
  const [isInspectingAddress, setIsInspectingAddress] = useState<boolean>(false);
  const [txToAddress, setTxToAddress] = useState<string>("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa");
  const [txAmountSat, setTxAmountSat] = useState<number>(100000);
  const [txFeeSat, setTxFeeSat] = useState<number>(2500);
  const [txMemo, setTxMemo] = useState<string>("HEOFLIX Bitcore-lib Settlement");
  const [builtTxResult, setBuiltTxResult] = useState<any>(null);
  const [isBuildingTx, setIsBuildingTx] = useState<boolean>(false);
  const [scriptInputHex, setScriptInputHex] = useState<string>("76a91476181cde74d51f70bcf1727902d5526cbc1b177788ac");
  const [scriptInputAsm, setScriptInputAsm] = useState<string>("");
  const [scriptToolResult, setScriptToolResult] = useState<any>(null);
  const [isAnalyzingScript, setIsAnalyzingScript] = useState<boolean>(false);

  // Axios HTTP Request to Blockchain Node/API State
  const [httpTargetUrl, setHttpTargetUrl] = useState<string>("https://api.blockcypher.com/v1/btc/main");
  const [httpMethod, setHttpMethod] = useState<"GET" | "POST" | "PUT">("GET");
  const [httpHeadersJson, setHttpHeadersJson] = useState<string>("{\n  \"Accept\": \"application/json\"\n}");
  const [httpBodyJson, setHttpBodyJson] = useState<string>("");
  const [httpAuthUser, setHttpAuthUser] = useState<string>("");
  const [httpAuthPass, setHttpAuthPass] = useState<string>("");
  const [httpResponseData, setHttpResponseData] = useState<any>(null);
  const [isDispatchingHttp, setIsDispatchingHttp] = useState<boolean>(false);
  const [httpError, setHttpError] = useState<string | null>(null);

  // Underground Workers State
  const [undergroundStatus, setUndergroundStatus] = useState<any>(null);
  const [isLoadingUnderground, setIsLoadingUnderground] = useState<boolean>(false);

  const fetchBlockcypherInfo = async () => {
    setIsLoadingBlockcypher(true);
    try {
      const res = await fetch("/api/v1/blockchain/blockcypher/info");
      const data = await res.json();
      if (data.success && data.chain) {
        setBlockcypherData(data);
      }
    } catch {
      // ignore
    } finally {
      setIsLoadingBlockcypher(false);
    }
  };

  const handleQueryAddress = async (addrToQuery?: string) => {
    const target = (addrToQuery || addressQuery || "").trim();
    if (!target) return;
    setIsQueryingAddress(true);
    try {
      const res = await fetch(`/api/v1/blockchain/blockcypher/address/${encodeURIComponent(target)}`);
      const data = await res.json();
      if (data.success) {
        setAddressResult(data);
      }
    } catch {
      // ignore
    } finally {
      setIsQueryingAddress(false);
    }
  };

  const handleQueryTx = async (txToQuery?: string) => {
    const target = (txToQuery || txQuery || "").trim();
    if (!target) return;
    setIsQueryingTx(true);
    try {
      const res = await fetch(`/api/v1/blockchain/blockcypher/tx/${encodeURIComponent(target)}`);
      const data = await res.json();
      if (data.success) {
        setTxResult(data);
      }
    } catch {
      // ignore
    } finally {
      setIsQueryingTx(false);
    }
  };

  const handleBroadcastRawTx = async () => {
    if (!rawTxToBroadcast.trim()) return;
    setIsBroadcasting(true);
    try {
      const res = await fetch("/api/v1/blockchain/blockcypher/push-tx", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ txHex: rawTxToBroadcast.trim() }),
      });
      const data = await res.json();
      setBroadcastResult(data);
    } catch (e: any) {
      setBroadcastResult({ success: false, error: e.message });
    } finally {
      setIsBroadcasting(false);
    }
  };

  const handleGenerateBitcoreKey = async () => {
    setIsGeneratingBitcoreKey(true);
    try {
      const res = await fetch("/api/v1/blockchain/bitcore/generate-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ network: bitcoreNet, passphrase: bitcorePassphrase }),
      });
      const data = await res.json();
      if (data.success) {
        setBitcoreGeneratedKey(data);
      }
    } catch {
      // ignore
    } finally {
      setIsGeneratingBitcoreKey(false);
    }
  };

  const handleInspectBitcoreAddress = async () => {
    if (!inspectAddressInput.trim()) return;
    setIsInspectingAddress(true);
    try {
      const res = await fetch("/api/v1/blockchain/bitcore/inspect-address", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ address: inspectAddressInput.trim() }),
      });
      const data = await res.json();
      setInspectAddressResult(data);
    } catch {
      // ignore
    } finally {
      setIsInspectingAddress(false);
    }
  };

  const handleBuildBitcoreTx = async () => {
    if (!txToAddress.trim()) return;
    setIsBuildingTx(true);
    try {
      const res = await fetch("/api/v1/blockchain/bitcore/create-tx", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          toAddress: txToAddress.trim(),
          amountSatoshis: txAmountSat,
          feeSatoshis: txFeeSat,
          customMemo: txMemo,
          privateKeyWif: bitcoreGeneratedKey?.privateKeyWif || "",
          fromAddress: bitcoreGeneratedKey?.address || "",
        }),
      });
      const data = await res.json();
      if (data.success) {
        setBuiltTxResult(data);
        if (data.rawTxHex) {
          setRawTxToBroadcast(data.rawTxHex);
        }
      }
    } catch {
      // ignore
    } finally {
      setIsBuildingTx(false);
    }
  };

  const handleAnalyzeBitcoreScript = async () => {
    setIsAnalyzingScript(true);
    try {
      const res = await fetch("/api/v1/blockchain/bitcore/script-tool", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          hex: scriptInputHex.trim() || undefined,
          asm: scriptInputAsm.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setScriptToolResult(data);
      }
    } catch {
      // ignore
    } finally {
      setIsAnalyzingScript(false);
    }
  };

  const handleDispatchAxiosRequest = async () => {
    if (!httpTargetUrl.trim()) return;
    setIsDispatchingHttp(true);
    setHttpError(null);
    setHttpResponseData(null);
    try {
      let parsedHeaders = {};
      try {
        if (httpHeadersJson.trim()) parsedHeaders = JSON.parse(httpHeadersJson);
      } catch {}

      let parsedBody = undefined;
      try {
        if (httpBodyJson.trim()) parsedBody = JSON.parse(httpBodyJson);
      } catch {
        parsedBody = httpBodyJson;
      }

      const res = await fetch("/api/v1/blockchain/http-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: httpTargetUrl.trim(),
          method: httpMethod,
          headers: parsedHeaders,
          data: parsedBody,
          auth:
            httpAuthUser.trim() && httpAuthPass.trim()
              ? { username: httpAuthUser.trim(), password: httpAuthPass.trim() }
              : null,
        }),
      });
      const data = await res.json();
      setHttpResponseData(data);
    } catch (e: any) {
      setHttpError(e.message || "Failed to dispatch HTTP request via Axios");
    } finally {
      setIsDispatchingHttp(false);
    }
  };

  const fetchUndergroundStatus = async () => {
    setIsLoadingUnderground(true);
    try {
      const res = await fetch("/api/v1/node/underground-status");
      const data = await res.json();
      if (data.success) {
        setUndergroundStatus(data);
      }
    } catch {
      // ignore
    } finally {
      setIsLoadingUnderground(false);
    }
  };

  useEffect(() => {
    if (activeSubTab === "blockcypher") {
      fetchBlockcypherInfo();
    } else if (activeSubTab === "bitcore_lib" && !bitcoreGeneratedKey) {
      handleGenerateBitcoreKey();
      handleAnalyzeBitcoreScript();
    } else if (activeSubTab === "node_rpc") {
      fetchUndergroundStatus();
    }
  }, [activeSubTab]);

  // Fetch initial blocks & auto-derive default key
  const loadBlocks = async () => {
    try {
      const res = await fetch("/api/v1/blockchain/blocks");
      const data = await res.json();
      if (data.success && Array.isArray(data.blocks)) {
        setBlocks(data.blocks);
        if (data.activeSigningKeyAddress) {
          setActiveBoundAddress(data.activeSigningKeyAddress);
        }
      }
    } catch {
      // ignore
    } finally {
      setIsLoadingBlocks(false);
    }
  };

  useEffect(() => {
    loadBlocks();
    handleDeriveSecretKey();
  }, []);

  // Derive Secret Key
  const handleDeriveSecretKey = async (pass?: string) => {
    setIsGeneratingKey(true);
    setBindSuccessMsg("");
    try {
      const phraseToUse = pass !== undefined ? pass : customPassphrase;
      const res = await fetch("/api/v1/blockchain/derive-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          algorithm: selectedAlgorithm,
          customPassphrase: phraseToUse,
        }),
      });
      const data = await res.json();
      if (data.success && data.keyData) {
        setGeneratedKey(data.keyData);
      }
    } catch {
      // ignore
    } finally {
      setIsGeneratingKey(false);
    }
  };

  // Bind active signing key to session
  const handleBindActiveKey = async () => {
    if (!generatedKey) return;
    try {
      const res = await fetch("/api/v1/blockchain/bind-active-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ keyData: generatedKey }),
      });
      const data = await res.json();
      if (data.success) {
        setActiveBoundAddress(generatedKey.address);
        setBindSuccessMsg(
          `Secret key bound as active master signing key (${generatedKey.address.slice(0, 10)}...)`
        );
        setTimeout(() => setBindSuccessMsg(""), 4000);
      }
    } catch {
      // ignore
    }
  };

  // Mine Block
  const handleMineBlock = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsMining(true);
    setLastMinedStats(null);
    try {
      const res = await fetch("/api/v1/blockchain/mine", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          miner: minerName,
          memo: miningMemo,
          difficulty: miningDifficulty,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setLastMinedStats(data.miningStats);
        await loadBlocks();
      }
    } catch {
      // ignore
    } finally {
      setIsMining(false);
    }
  };

  // Verify chain integrity
  const handleVerifyChain = async () => {
    try {
      const res = await fetch("/api/v1/blockchain/verify-chain", {
        method: "POST",
      });
      const data = await res.json();
      if (data.success) {
        setChainIntegrity({
          verified: true,
          isValid: data.isValid,
          reason: data.reason,
          brokenIndex: data.brokenBlockIndex,
        });
      }
    } catch {
      // ignore
    }
  };

  // Auto-heal chain
  const handleHealChain = async () => {
    try {
      const res = await fetch("/api/v1/blockchain/heal-chain", {
        method: "POST",
      });
      const data = await res.json();
      if (data.success) {
        await loadBlocks();
        handleVerifyChain();
      }
    } catch {
      // ignore
    }
  };

  // Sign Message Sandbox
  const handleSignMessage = async () => {
    if (!generatedKey) return;
    try {
      const res = await fetch("/api/v1/blockchain/sign-message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: signMessageText,
          secretKey: generatedKey.secretKey,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setSignatureResult(data.signature);
        setVerifyStatus({ tested: false, isValid: false });
      }
    } catch {
      // ignore
    }
  };

  // Verify Signature Sandbox
  const handleVerifySignature = async () => {
    if (!generatedKey || !signatureResult) return;
    try {
      const res = await fetch("/api/v1/blockchain/verify-signature", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: signMessageText,
          signature: signatureResult,
          secretKey: generatedKey.secretKey,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setVerifyStatus({ tested: true, isValid: data.isValid });
      }
    } catch {
      // ignore
    }
  };

  const copyToClipboard = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const downloadPaperKey = () => {
    if (!generatedKey) return;
    const blob = new Blob([JSON.stringify(generatedKey, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `heoflix-secret-key-${generatedKey.address.slice(0, 8)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredBlocks = blocks.filter((b) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      b.index.toString() === q ||
      b.hash.toLowerCase().includes(q) ||
      b.miner.toLowerCase().includes(q) ||
      JSON.stringify(b.transactions).toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Hero Blockchain Status Header */}
      <div className="relative overflow-hidden rounded-3xl border border-sky-500/30 bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-950 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-xs font-bold uppercase tracking-wider text-sky-400">
                HEOFLIX Sovereign Ledger & Cryptographic Engine
              </span>
              <span className="rounded-md bg-sky-500/10 px-2 py-0.5 text-[10px] font-extrabold text-sky-400 border border-sky-500/20 font-mono">
                PoW Mainnet-1
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight flex items-baseline gap-2">
              <span>Native Blockchain & Secret Key Studio</span>
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-2xl leading-relaxed">
              Create your own custom 256-bit cryptographic secret keys, inspect the immutable SHA-256 block ledger, and mine blocks on your sovereign node network.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 px-4 py-3 text-right">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Chain Height</span>
              <div className="text-lg font-black text-white font-mono">#{blocks.length} Blocks</div>
            </div>

            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 px-4 py-3 text-right">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Consensus State</span>
              <div className="text-sm font-black text-emerald-400 flex items-center gap-1.5 justify-end">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Synchronized</span>
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900/80 border border-slate-800 px-4 py-3 text-right">
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Active Signing Key</span>
              <div className="text-xs font-black text-sky-300 font-mono">
                {activeBoundAddress
                  ? `${activeBoundAddress.slice(0, 6)}...${activeBoundAddress.slice(-4)}`
                  : "Key Configured"}
              </div>
            </div>
          </div>
        </div>

        {/* 4-Tab Navigation Selector */}
        <div className="flex flex-wrap items-center gap-2 mt-8 pt-6 border-t border-slate-800">
          <button
            id="tab-btn-key-studio"
            type="button"
            onClick={() => setActiveSubTab("key_studio")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSubTab === "key_studio"
                ? "bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-lg shadow-sky-500/25"
                : "bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800"
            }`}
          >
            <Key className="w-3.5 h-3.5" />
            <span>Create Secret Key & Vault</span>
          </button>

          <button
            id="tab-btn-explorer"
            type="button"
            onClick={() => setActiveSubTab("explorer")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSubTab === "explorer"
                ? "bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-lg shadow-sky-500/25"
                : "bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800"
            }`}
          >
            <Boxes className="w-3.5 h-3.5" />
            <span>Blockchain Explorer & Ledger</span>
          </button>

          <button
            id="tab-btn-blockcypher"
            type="button"
            onClick={() => setActiveSubTab("blockcypher")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSubTab === "blockcypher"
                ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-black shadow-lg shadow-emerald-500/25"
                : "bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800"
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span>BlockCypher Live Network</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono">
              BTC Mainnet
            </span>
          </button>

          <button
            id="tab-btn-bitcore-lib"
            type="button"
            onClick={() => setActiveSubTab("bitcore_lib")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSubTab === "bitcore_lib"
                ? "bg-gradient-to-r from-sky-500 to-cyan-600 text-slate-950 font-black shadow-lg shadow-sky-500/25"
                : "bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800"
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-sky-400" />
            <span>Bitcore-lib Engine</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-sky-500/20 text-sky-300 font-mono">
              v10.10.7
            </span>
          </button>

          <button
            id="tab-btn-node-rpc"
            type="button"
            onClick={() => setActiveSubTab("node_rpc")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSubTab === "node_rpc"
                ? "bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950 font-black shadow-lg shadow-amber-500/25"
                : "bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800"
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-amber-400" />
            <span>Axios Node HTTP Dispatcher</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-mono">
              RPC / REST
            </span>
          </button>

          <button
            id="tab-btn-miner"
            type="button"
            onClick={() => setActiveSubTab("miner")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSubTab === "miner"
                ? "bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-lg shadow-sky-500/25"
                : "bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800"
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>PoW Block Miner</span>
          </button>

          <button
            id="tab-btn-signer"
            type="button"
            onClick={() => setActiveSubTab("signer")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSubTab === "signer"
                ? "bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-lg shadow-sky-500/25"
                : "bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800"
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Sign & Verify Sandbox</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. SECRET KEY CREATION ENVIRONMENT & VAULT                                */}
      {/* ========================================================================= */}
      {activeSubTab === "key_studio" && (
        <div className="space-y-6 animate-in fade-in">
          {/* Key Generator Form */}
          <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-8 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-black text-white">
                    Secret Key Creator & Cryptographic Derivation
                  </h2>
                  <p className="text-xs text-slate-400">
                    Enter your custom secret phrase or generate a cryptographically random private key
                  </p>
                </div>
              </div>

              <span className="text-[10px] font-mono px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold self-start sm:self-auto">
                256-Bit SHA-256 PBKDF2 Entropy
              </span>
            </div>

            {bindSuccessMsg && (
              <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{bindSuccessMsg}</span>
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Algorithm Selector */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Cryptographic Curve / Algorithm
                </label>
                <div className="space-y-2">
                  {[
                    {
                      id: "secp256k1",
                      name: "secp256k1 (EVM / Bitcoin)",
                      desc: "Ethereum & Bitcoin compatible elliptic curve",
                    },
                    {
                      id: "bip39",
                      name: "BIP-39 Mnemonic Seed",
                      desc: "12-word human readable deterministic recovery",
                    },
                    {
                      id: "aes256",
                      name: "AES-256-GCM Hardware Vault",
                      desc: "Symmetric master encryption key",
                    },
                  ].map((alg) => (
                    <button
                      key={alg.id}
                      type="button"
                      onClick={() => {
                        setSelectedAlgorithm(alg.id as any);
                        handleDeriveSecretKey();
                      }}
                      className={`w-full p-3 rounded-2xl border text-left transition cursor-pointer ${
                        selectedAlgorithm === alg.id
                          ? "bg-sky-950/40 border-sky-500 shadow-md shadow-sky-500/20"
                          : "bg-slate-950 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      <div className="text-xs font-bold text-white">{alg.name}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{alg.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Passphrase Input & Generator controls */}
              <div className="lg:col-span-2 space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-semibold text-slate-300">
                      Your Custom Secret Passphrase / Master Words
                    </label>
                    <span className="text-[10px] text-slate-400">
                      {customPassphrase.length} characters (PBKDF2 120,000 rounds)
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      id="input-custom-passphrase"
                      type="text"
                      value={customPassphrase}
                      onChange={(e) => setCustomPassphrase(e.target.value)}
                      placeholder="Type your own custom secret key words or passphrase..."
                      className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-white font-mono text-sm focus:ring-2 focus:ring-sky-500 focus:outline-none"
                    />
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1.5">
                    Type any phrase you want (e.g. your name + private code) to create a deterministic mathematical keypair, or generate random entropy.
                  </p>
                </div>

                <div className="flex flex-wrap gap-3 pt-1">
                  <button
                    id="btn-derive-custom-key"
                    type="button"
                    onClick={() => handleDeriveSecretKey()}
                    disabled={isGeneratingKey}
                    className="px-5 py-3 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-black shadow-lg shadow-sky-500/20 transition active:scale-[0.98] flex items-center gap-2 cursor-pointer"
                  >
                    {isGeneratingKey ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Zap className="w-4 h-4 text-white fill-current" />
                    )}
                    <span>Derive My Secret Key</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const randPhrase = `Sovereign-${Math.random().toString(36).substring(2, 10)}-${Date.now().toString(36)}`;
                      setCustomPassphrase(randPhrase);
                      handleDeriveSecretKey(randPhrase);
                    }}
                    className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition flex items-center gap-2 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-sky-400" />
                    <span>Generate Random Passphrase</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Generated Keypair Inspection Card */}
          {generatedKey && (
            <div className="rounded-3xl border border-sky-500/40 bg-gradient-to-br from-slate-900 via-slate-950 to-indigo-950/20 p-6 sm:p-8 shadow-2xl space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <span>Generated Cryptographic Keypair</span>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400">
                      {generatedKey.strength}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Fingerprint: <code className="text-sky-300 font-mono">{generatedKey.fingerprint}</code>
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleBindActiveKey}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-lg shadow-emerald-600/25 cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Bind as Active Signing Key</span>
                  </button>

                  <button
                    type="button"
                    onClick={downloadPaperKey}
                    className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                    title="Export Keystore JSON Backup"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Secret Key Display */}
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-500/30 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-rose-400" />
                      <span>Secret Key (Private Key)</span>
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setShowSecretKey(!showSecretKey)}
                        className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                      >
                        {showSecretKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        <span>{showSecretKey ? "Hide" : "Show"}</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(generatedKey.secretKey, "secretKey")}
                        className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] flex items-center gap-1 cursor-pointer"
                      >
                        {copiedField === "secretKey" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedField === "secretKey" ? "Copied" : "Copy"}</span>
                      </button>
                    </div>
                  </div>

                  <div className="font-mono text-xs p-3 rounded-xl bg-slate-950 border border-slate-800 text-rose-200 break-all select-all">
                    {showSecretKey
                      ? generatedKey.secretKey
                      : "••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••"}
                  </div>
                  <span className="text-[10px] text-slate-400 block">
                    Security Warning: Never share your Secret Key with anyone. Keep it in private custody.
                  </span>
                </div>

                {/* Public Address */}
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300">
                      Public Blockchain Address (Destination / Identity)
                    </span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(generatedKey.address, "address")}
                      className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] flex items-center gap-1 cursor-pointer"
                    >
                      {copiedField === "address" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedField === "address" ? "Copied" : "Copy"}</span>
                    </button>
                  </div>
                  <div className="font-mono text-xs sm:text-sm p-3 rounded-xl bg-slate-900 border border-slate-800 text-sky-300 break-all select-all">
                    {generatedKey.address}
                  </div>
                </div>

                {/* BIP-39 12-Word Recovery Mnemonic */}
                {generatedKey.mnemonic && (
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-300">
                        12-Word BIP-39 Recovery Mnemonic
                      </span>
                      <button
                        type="button"
                        onClick={() => copyToClipboard(generatedKey.mnemonic!, "mnemonic")}
                        className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] flex items-center gap-1 cursor-pointer"
                      >
                        {copiedField === "mnemonic" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedField === "mnemonic" ? "Copied" : "Copy Mnemonic"}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                      {generatedKey.mnemonic.split(" ").map((word, idx) => (
                        <div
                          key={idx}
                          className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-center font-mono text-xs text-indigo-300"
                        >
                          <span className="text-[10px] text-slate-500 mr-1.5">{idx + 1}.</span>
                          <span className="font-bold">{word}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. BLOCKCHAIN EXPLORER & LEDGER                                           */}
      {/* ========================================================================= */}
      {activeSubTab === "explorer" && (
        <div className="space-y-6 animate-in fade-in">
          {/* Integrity status bar & Search */}
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                  chainIntegrity.isValid
                    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"
                    : "bg-rose-500/20 text-rose-400 border border-rose-500/40"
                }`}
              >
                {chainIntegrity.isValid ? (
                  <CheckCircle2 className="w-5 h-5" />
                ) : (
                  <AlertCircle className="w-5 h-5" />
                )}
              </div>
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  <span>Cryptographic Blockchain State:</span>
                  <span
                    className={`font-mono text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                      chainIntegrity.isValid
                        ? "bg-emerald-500/20 text-emerald-400"
                        : "bg-rose-500/20 text-rose-400"
                    }`}
                  >
                    {chainIntegrity.isValid ? "CHAIN VALID & SYNCHRONIZED" : "TAMPERING DETECTED"}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">{chainIntegrity.reason}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleVerifyChain}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition cursor-pointer"
              >
                Verify Entire Chain
              </button>

              <button
                type="button"
                onClick={handleHealChain}
                className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition cursor-pointer"
              >
                Re-sync Consensus
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search blocks by index (#0, #1), block hash, transaction, or miner..."
              className="w-full pl-11 pr-4 py-3 rounded-2xl bg-slate-900 border border-slate-800 text-white text-xs font-mono focus:ring-2 focus:ring-sky-500 focus:outline-none"
            />
          </div>

          {/* Blocks List */}
          <div className="space-y-4">
            {filteredBlocks.map((b) => (
              <div
                key={b.index}
                className="rounded-3xl border border-slate-800 bg-slate-900/90 p-5 sm:p-6 shadow-xl space-y-4 transition hover:border-slate-700"
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <span className="w-8 h-8 rounded-xl bg-sky-500/20 border border-sky-500/40 text-sky-400 font-mono font-bold text-xs flex items-center justify-center">
                      #{b.index}
                    </span>
                    <div>
                      <div className="text-xs font-bold text-white">
                        Block Height #{b.index} {b.index === 0 && <span className="text-[10px] text-amber-400 font-mono">(Genesis)</span>}
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono">{b.timestamp}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 font-mono text-[10px]">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      Nonce: {b.nonce}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      Diff: {b.difficulty}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                      {b.transactions.length} Txs
                    </span>
                  </div>
                </div>

                {/* Hashes */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] uppercase text-slate-500 block">Previous Block Hash</span>
                    <div className="text-[11px] text-slate-400 truncate mt-0.5">{b.previousHash}</div>
                  </div>

                  <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] uppercase text-sky-500 block">Current Block Hash (SHA-256)</span>
                    <div className="text-[11px] text-sky-300 font-bold truncate mt-0.5">{b.hash}</div>
                  </div>
                </div>

                {/* Transactions in Block */}
                <div className="space-y-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">
                    Transactions in Block #{b.index}
                  </span>
                  <div className="space-y-2">
                    {b.transactions.map((tx: any, tIdx: number) => (
                      <div
                        key={tIdx}
                        className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2"
                      >
                        <div className="truncate">
                          <span className="font-bold text-white">{tx.memo || "Transaction"}</span>
                          <div className="text-[10px] text-slate-400 font-mono truncate">
                            {tx.from} → {tx.to}
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="font-mono font-black text-emerald-400">
                            {tx.amount > 0 ? `+${tx.amount.toLocaleString()} ${tx.currency || "USD"}` : `${tx.amount} ${tx.currency}`}
                          </span>
                          <span className="text-[10px] text-slate-500 block">
                            {tx.status || "CONFIRMED"}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. PROOF-OF-WORK BLOCK MINER                                              */}
      {/* ========================================================================= */}
      {activeSubTab === "miner" && (
        <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-8 shadow-xl space-y-6 animate-in fade-in">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white">
                Sovereign Proof-of-Work Block Miner
              </h2>
              <p className="text-xs text-slate-400">
                Mine candidate blocks using SHA-256 Proof-of-Work with difficulty targeting
              </p>
            </div>
          </div>

          {lastMinedStats && (
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-xs space-y-2 animate-in fade-in">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>Block Successfully Mined & Broadcasted to Sovereign Chain!</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 font-mono text-[11px] text-slate-300">
                <div>Nonce Solved: <strong>{lastMinedStats.nonce}</strong></div>
                <div>Duration: <strong>{lastMinedStats.durationMs}ms</strong></div>
                <div>Hashrate: <strong>{lastMinedStats.hashrate} H/s</strong></div>
                <div>Difficulty: <strong>{lastMinedStats.difficulty} zeros</strong></div>
              </div>
            </div>
          )}

          <form onSubmit={handleMineBlock} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Miner Node Identity
                </label>
                <input
                  type="text"
                  value={minerName}
                  onChange={(e) => setMinerName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:ring-2 focus:ring-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Mining Difficulty Target
                </label>
                <select
                  value={miningDifficulty}
                  onChange={(e) => setMiningDifficulty(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white font-mono focus:ring-2 focus:ring-sky-500 focus:outline-none"
                >
                  <option value={1}>Difficulty 1 (Prefix: "0..." - Instant)</option>
                  <option value={2}>Difficulty 2 (Prefix: "00..." - Balanced)</option>
                  <option value={3}>Difficulty 3 (Prefix: "000..." - High Security)</option>
                  <option value={4}>Difficulty 4 (Prefix: "0000..." - Heavy Hashrate)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Block Transaction Batch Memo
              </label>
              <input
                type="text"
                value={miningMemo}
                onChange={(e) => setMiningMemo(e.target.value)}
                placeholder="Memo or smart contract transaction details..."
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-sky-300 focus:ring-2 focus:ring-sky-500 focus:outline-none"
              />
            </div>

            <button
              id="btn-execute-mine-block"
              type="submit"
              disabled={isMining}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-sky-600 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-white font-black text-sm tracking-wide shadow-xl shadow-sky-500/20 transition active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isMining ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>Computing Nonce & Proof-of-Work Hashes...</span>
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 text-white fill-current" />
                  <span>Mine Next Block (#{blocks.length}) on Sovereign Chain</span>
                </>
              )}
            </button>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. CRYPTOGRAPHIC SIGN & VERIFY SANDBOX                                    */}
      {/* ========================================================================= */}
      {activeSubTab === "signer" && (
        <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-8 shadow-xl space-y-6 animate-in fade-in">
          <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white">
                Cryptographic Signature Sandbox
              </h2>
              <p className="text-xs text-slate-400">
                Sign transaction messages with your private key and verify authenticity against your public address
              </p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Transaction / Message to Sign
              </label>
              <textarea
                rows={3}
                value={signMessageText}
                onChange={(e) => setSignMessageText(e.target.value)}
                className="w-full p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-white font-mono focus:ring-2 focus:ring-purple-500 focus:outline-none"
              />
            </div>

            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleSignMessage}
                className="px-5 py-3 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-lg shadow-purple-600/20"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Sign Message with My Secret Key</span>
              </button>

              {signatureResult && (
                <button
                  type="button"
                  onClick={handleVerifySignature}
                  className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Verify Signature on Blockchain</span>
                </button>
              )}
            </div>

            {signatureResult && (
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 animate-in fade-in">
                <span className="text-xs font-bold text-slate-300 block">
                  Generated Cryptographic Signature:
                </span>
                <div className="p-3 rounded-xl bg-slate-900 font-mono text-xs text-purple-300 break-all select-all border border-slate-800">
                  {signatureResult}
                </div>
              </div>
            )}

            {verifyStatus.tested && (
              <div
                className={`p-4 rounded-2xl border text-xs flex items-center gap-2 animate-in fade-in ${
                  verifyStatus.isValid
                    ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                    : "bg-rose-500/10 border-rose-500/30 text-rose-300"
                }`}
              >
                {verifyStatus.isValid ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <span>
                      Signature Mathematically Verified! This transaction was unequivocally signed by Secret Key owner ({generatedKey?.address}).
                    </span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    <span>Signature Verification Failed. The signature does not match this key.</span>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. BLOCKCYPHER LIVE BLOCKCHAIN NETWORK CONSOLE                            */}
      {/* ========================================================================= */}
      {activeSubTab === "blockcypher" && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Top Live Network Banner */}
          <div className="rounded-3xl bg-slate-900/90 border border-emerald-500/30 p-6 shadow-2xl relative overflow-hidden">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                    BlockCypher Bitcoin Mainnet Interlink
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-bold">
                    {blockcypherData?.connection || "LIVE_CONNECTED"}
                  </span>
                </div>
                <h2 className="text-xl font-black text-white">Live Bitcoin Mainnet State &amp; Explorer</h2>
                <p className="text-xs text-slate-300 mt-1 max-w-xl">
                  Real-time blockchain metrics queried directly from BlockCypher via Node.js underground Axios client.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={fetchBlockcypherInfo}
                  disabled={isLoadingBlockcypher}
                  className="px-4 py-2.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 hover:text-white text-xs font-bold transition flex items-center gap-2 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingBlockcypher ? "animate-spin" : ""}`} />
                  <span>Refresh Chain Tip</span>
                </button>
              </div>
            </div>

            {/* Live Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Block Height</span>
                <div className="text-xl font-black text-emerald-400 font-mono mt-1">
                  #{blockcypherData?.chain?.height ? Number(blockcypherData.chain.height).toLocaleString() : "970,462"}
                </div>
                <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                  Tip Confirmed
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Connected Peers</span>
                <div className="text-xl font-black text-sky-400 font-mono mt-1">
                  {blockcypherData?.chain?.peer_count || 324} Peers
                </div>
                <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                  Global P2P Gossip
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Mempool Unconfirmed</span>
                <div className="text-xl font-black text-amber-400 font-mono mt-1">
                  {blockcypherData?.chain?.unconfirmed_count
                    ? Number(blockcypherData.chain.unconfirmed_count).toLocaleString()
                    : "5,719"}{" "}
                  txs
                </div>
                <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                  Pending Blocks
                </span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">API Query Latency</span>
                <div className="text-xl font-black text-purple-400 font-mono mt-1">
                  {blockcypherData?.chain?.queryLatencyMs || 120} ms
                </div>
                <span className="text-[10px] text-slate-500 font-mono block mt-0.5">
                  Axios HTTP Handshake
                </span>
              </div>
            </div>

            {/* Tip Hash Detail */}
            {blockcypherData?.chain && (
              <div className="mt-4 p-3.5 rounded-2xl bg-slate-950/90 border border-slate-800/80 text-xs font-mono space-y-1.5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px]">
                  <span className="text-slate-400 font-sans font-bold">Latest Block Hash:</span>
                  <div className="flex items-center gap-2 text-emerald-300 break-all">
                    <span>{blockcypherData.chain.hash}</span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(blockcypherData.chain.hash, "bcy_hash")}
                      className="p-1 hover:bg-slate-800 rounded transition text-slate-400 hover:text-white"
                    >
                      {copiedField === "bcy_hash" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px] pt-1 border-t border-slate-900">
                  <span className="text-slate-400 font-sans font-bold">Fee Guidance (Sat/KB):</span>
                  <div className="text-slate-300 flex items-center gap-3">
                    <span className="text-emerald-400 font-bold">High: {blockcypherData.chain.high_fee_per_kb}</span>
                    <span className="text-sky-400">Med: {blockcypherData.chain.medium_fee_per_kb}</span>
                    <span className="text-slate-400">Low: {blockcypherData.chain.low_fee_per_kb}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* BlockCypher Interactive Tools Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 1. Address Balance & UTXO Query */}
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Search className="w-4 h-4 text-emerald-400" />
                <span>BlockCypher Address Explorer</span>
              </div>
              <p className="text-xs text-slate-400">
                Inspect real-world on-chain balance, UTXOs, and transaction history using BlockCypher.
              </p>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={addressQuery}
                    onChange={(e) => setAddressQuery(e.target.value)}
                    placeholder="Enter Bitcoin address (e.g. 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa)"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={() => handleQueryAddress()}
                    disabled={isQueryingAddress}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <Search className={`w-3.5 h-3.5 ${isQueryingAddress ? "animate-spin" : ""}`} />
                    <span>Query</span>
                  </button>
                </div>

                <div className="flex items-center gap-2 text-[10px] text-slate-400">
                  <span>Presets:</span>
                  <button
                    type="button"
                    onClick={() => {
                      setAddressQuery("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa");
                      handleQueryAddress("1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa");
                    }}
                    className="text-sky-400 hover:underline font-mono"
                  >
                    Genesis Address
                  </button>
                  {activeBoundAddress && (
                    <>
                      <span>•</span>
                      <button
                        type="button"
                        onClick={() => {
                          setAddressQuery(activeBoundAddress);
                          handleQueryAddress(activeBoundAddress);
                        }}
                        className="text-emerald-400 hover:underline font-mono"
                      >
                        Active Vault Key
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Address Result */}
              {addressResult && (
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-2 animate-in fade-in">
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400 font-sans font-bold">Address:</span>
                    <span className="text-emerald-400 break-all">{addressResult.addressData?.address}</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400 font-sans font-bold">Confirmed Balance:</span>
                    <span className="text-white font-bold">
                      {((addressResult.addressData?.balance || 0) / 100000000).toFixed(8)} BTC
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400 font-sans font-bold">Total Transactions:</span>
                    <span className="text-sky-300">{addressResult.addressData?.n_tx || 0}</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400 font-sans font-bold">Source:</span>
                    <span className="text-purple-300">{addressResult.source}</span>
                  </div>

                  {addressResult.addressData?.txrefs && addressResult.addressData.txrefs.length > 0 && (
                    <div className="pt-2 border-t border-slate-900 space-y-1">
                      <span className="text-[10px] text-slate-500 font-sans uppercase font-bold block">
                        Recent On-Chain Outputs:
                      </span>
                      {addressResult.addressData.txrefs.slice(0, 3).map((ref: any, idx: number) => (
                        <div key={idx} className="p-2 rounded-xl bg-slate-900/80 text-[10px] flex justify-between items-center">
                          <span className="text-slate-400 truncate max-w-[180px]">{ref.tx_hash}</span>
                          <span className="text-emerald-400 font-bold">{(ref.value / 100000000).toFixed(4)} BTC</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* 2. Raw Transaction Broadcast to BlockCypher */}
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Send className="w-4 h-4 text-sky-400" />
                <span>BlockCypher Raw Transaction Broadcaster</span>
              </div>
              <p className="text-xs text-slate-400">
                Broadcast signed raw transaction hex directly to BlockCypher Bitcoin Mainnet nodes.
              </p>

              <div className="space-y-3">
                <textarea
                  value={rawTxToBroadcast}
                  onChange={(e) => setRawTxToBroadcast(e.target.value)}
                  placeholder="Paste signed raw transaction hex (or generate one from Bitcore-lib tab)..."
                  rows={4}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-sky-200 font-mono placeholder:text-slate-600 focus:outline-none focus:border-sky-500"
                />

                <button
                  type="button"
                  onClick={handleBroadcastRawTx}
                  disabled={isBroadcasting || !rawTxToBroadcast.trim()}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 shadow-lg shadow-sky-500/20"
                >
                  <Send className={`w-3.5 h-3.5 ${isBroadcasting ? "animate-spin" : ""}`} />
                  <span>{isBroadcasting ? "Broadcasting to Bitcoin Mainnet..." : "Broadcast via BlockCypher"}</span>
                </button>
              </div>

              {/* Broadcast Result */}
              {broadcastResult && (
                <div
                  className={`p-4 rounded-2xl border text-xs font-mono space-y-1.5 animate-in fade-in ${
                    broadcastResult.success
                      ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-200"
                      : "bg-rose-500/10 border-rose-500/30 text-rose-200"
                  }`}
                >
                  <div className="font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Transaction Broadcast Accepted!</span>
                  </div>
                  <div className="text-[11px] text-slate-300 break-all">
                    TxID: <span className="text-sky-300 font-bold">{broadcastResult.broadcastResult?.txid}</span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Network: {broadcastResult.broadcastNetwork || "BlockCypher Bitcoin Mainnet"} • Latency: {broadcastResult.latencyMs}ms
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. BITCORE-LIB CRYPTOGRAPHIC TOOLKIT                                       */}
      {/* ========================================================================= */}
      {activeSubTab === "bitcore_lib" && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Header Banner */}
          <div className="rounded-3xl bg-slate-900/90 border border-sky-500/30 p-6 shadow-2xl">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="flex h-2.5 w-2.5 rounded-full bg-sky-400 animate-ping" />
                  <span className="text-xs font-bold text-sky-400 uppercase tracking-wider">
                    Bitcore-lib Cryptographic Toolkit (v10.10.7)
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-sky-500/10 text-sky-300 border border-sky-500/30 text-[10px] font-mono font-bold">
                    Node.js Native
                  </span>
                </div>
                <h2 className="text-xl font-black text-white">Cryptographic Keys, Addresses, Raw TX &amp; Script Engine</h2>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                  Construct, serialize, and cryptographically sign Bitcoin transactions using official Bitcore-lib primitives in Node.js.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <select
                  value={bitcoreNet}
                  onChange={(e) => setBitcoreNet(e.target.value as any)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-bold text-sky-300 focus:outline-none"
                >
                  <option value="mainnet">Bitcoin Mainnet (livenet)</option>
                  <option value="testnet">Bitcoin Testnet (testnet)</option>
                </select>

                <button
                  type="button"
                  onClick={handleGenerateBitcoreKey}
                  disabled={isGeneratingBitcoreKey}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-xs transition flex items-center gap-1.5 cursor-pointer shadow-lg shadow-sky-500/20"
                >
                  <Sparkles className={`w-3.5 h-3.5 ${isGeneratingBitcoreKey ? "animate-spin" : ""}`} />
                  <span>Generate Keypair</span>
                </button>
              </div>
            </div>
          </div>

          {/* Key Derivation Details */}
          {bitcoreGeneratedKey && (
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-white text-sm">
                  <Key className="w-4 h-4 text-sky-400" />
                  <span>Bitcore Derived Key &amp; Address</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-300 border border-sky-500/20">
                  {bitcoreGeneratedKey.derivationMethod}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Bitcore Bitcoin Address (P2PKH)</span>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs text-emerald-400 font-bold break-all select-all">
                      {bitcoreGeneratedKey.address}
                    </span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(bitcoreGeneratedKey.address, "bitcore_addr")}
                      className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white"
                    >
                      {copiedField === "bitcore_addr" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase block">Private Key WIF (Wallet Import Format)</span>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-xs text-purple-300 font-bold break-all select-all">
                      {bitcoreGeneratedKey.privateKeyWif}
                    </span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(bitcoreGeneratedKey.privateKeyWif, "bitcore_wif")}
                      className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white"
                    >
                      {copiedField === "bitcore_wif" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* scriptPubKey ASM */}
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800/80 font-mono text-xs space-y-1">
                <span className="text-[10px] font-sans font-bold text-slate-400 block uppercase">
                  ScriptPubKey (ASM Decoded Bytecode):
                </span>
                <span className="text-sky-300 break-all select-all block">{bitcoreGeneratedKey.scriptPubKeyAsm}</span>
              </div>
            </div>
          )}

          {/* Bitcore Transaction Builder & Script Tool Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 1. Transaction Builder */}
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Cpu className="w-4 h-4 text-sky-400" />
                <span>Bitcore Raw Transaction Constructor</span>
              </div>
              <p className="text-xs text-slate-400">
                Build, serialize, and sign a Bitcoin raw transaction with UTXOs, OP_RETURN memo, and fee calculation.
              </p>

              <div className="space-y-3">
                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Destination Address</label>
                  <input
                    type="text"
                    value={txToAddress}
                    onChange={(e) => setTxToAddress(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Amount (Satoshis)</label>
                    <input
                      type="number"
                      value={txAmountSat}
                      onChange={(e) => setTxAmountSat(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-sky-500"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">Fee (Satoshis)</label>
                    <input
                      type="number"
                      value={txFeeSat}
                      onChange={(e) => setTxFeeSat(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-sky-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">OP_RETURN On-Chain Memo</label>
                  <input
                    type="text"
                    value={txMemo}
                    onChange={(e) => setTxMemo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-sky-500"
                  />
                </div>

                <button
                  type="button"
                  onClick={handleBuildBitcoreTx}
                  disabled={isBuildingTx}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-sky-500/20"
                >
                  <Cpu className={`w-3.5 h-3.5 ${isBuildingTx ? "animate-spin" : ""}`} />
                  <span>{isBuildingTx ? "Constructing Transaction..." : "Construct & Sign Raw Transaction"}</span>
                </button>
              </div>

              {/* Built TX Output */}
              {builtTxResult && (
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-2 animate-in fade-in">
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400 font-sans font-bold">TxID:</span>
                    <span className="text-emerald-400 truncate max-w-[220px] font-bold">{builtTxResult.txid}</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400 font-sans font-bold">Virtual Size (vSize):</span>
                    <span className="text-sky-300">{builtTxResult.vsize} vB ({builtTxResult.weightUnits} WU)</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-300">
                    <span className="text-slate-400 font-sans font-bold">Fully Signed:</span>
                    <span className="text-emerald-400 font-bold">{builtTxResult.isFullySigned ? "YES (Valid)" : "NO"}</span>
                  </div>

                  <div className="pt-2 border-t border-slate-900">
                    <span className="text-[10px] text-slate-500 font-sans uppercase font-bold block mb-1">
                      Raw Serialized Hex:
                    </span>
                    <div className="p-2 rounded-xl bg-slate-900 text-[10px] text-slate-400 break-all max-h-24 overflow-y-auto select-all">
                      {builtTxResult.rawTxHex}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setRawTxToBroadcast(builtTxResult.rawTxHex);
                      setActiveSubTab("blockcypher");
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Send to BlockCypher Broadcaster &rarr;</span>
                  </button>
                </div>
              )}
            </div>

            {/* 2. Bitcore Address Inspector & Script Disassembler */}
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <FileCode className="w-4 h-4 text-purple-400" />
                <span>Bitcore Address Inspector &amp; Script Disassembler</span>
              </div>
              <p className="text-xs text-slate-400">
                Validate Bitcoin addresses and inspect script opcodes with Bitcore-lib.
              </p>

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400 block">Address Inspector</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={inspectAddressInput}
                      onChange={(e) => setInspectAddressInput(e.target.value)}
                      placeholder="Enter address to validate"
                      className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-purple-500"
                    />
                    <button
                      type="button"
                      onClick={handleInspectBitcoreAddress}
                      disabled={isInspectingAddress}
                      className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition flex items-center gap-1 cursor-pointer"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Inspect</span>
                    </button>
                  </div>
                </div>

                {inspectAddressResult && (
                  <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-1 animate-in fade-in">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 font-sans font-bold">Checksum Validation:</span>
                      <span className={inspectAddressResult.isValid ? "text-emerald-400 font-bold" : "text-rose-400 font-bold"}>
                        {inspectAddressResult.isValid ? "PASSED (Valid)" : "FAILED (Invalid)"}
                      </span>
                    </div>
                    {inspectAddressResult.isValid && (
                      <>
                        <div className="flex justify-between items-center text-slate-300">
                          <span className="text-slate-400 font-sans font-bold">Network:</span>
                          <span className="text-sky-300">{inspectAddressResult.network}</span>
                        </div>
                        <div className="flex justify-between items-center text-slate-300">
                          <span className="text-slate-400 font-sans font-bold">Type:</span>
                          <span className="text-purple-300 uppercase">{inspectAddressResult.type}</span>
                        </div>
                      </>
                    )}
                  </div>
                )}

                {/* Script Disassembler */}
                <div className="pt-2 border-t border-slate-800 space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400 block">Script Disassembler (Bytecode Hex)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={scriptInputHex}
                      onChange={(e) => setScriptInputHex(e.target.value)}
                      placeholder="Enter script hex"
                      className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-purple-500"
                    />
                    <button
                      type="button"
                      onClick={handleAnalyzeBitcoreScript}
                      disabled={isAnalyzingScript}
                      className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition cursor-pointer"
                    >
                      <span>Decompile</span>
                    </button>
                  </div>
                </div>

                {scriptToolResult && (
                  <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono space-y-1.5 animate-in fade-in">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400 font-sans font-bold">Classification:</span>
                      <span className="text-emerald-400 font-bold">{scriptToolResult.classification}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 font-sans uppercase font-bold block">Disassembled ASM:</span>
                      <span className="text-sky-300 break-all block mt-0.5">{scriptToolResult.asm}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 7. AXIOS HTTP REQUEST DISPATCHER TO BLOCKCHAIN NODE/API                   */}
      {/* ========================================================================= */}
      {activeSubTab === "node_rpc" && (
        <div className="space-y-6 animate-in fade-in duration-300">
          {/* Header Banner */}
          <div className="rounded-3xl bg-slate-900/90 border border-amber-500/30 p-6 shadow-2xl">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="flex h-2.5 w-2.5 rounded-full bg-amber-400 animate-ping" />
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                    Axios HTTP Blockchain Node Client
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[10px] font-mono font-bold">
                    Node.js Express / TSX
                  </span>
                </div>
                <h2 className="text-xl font-black text-white">HTTP Request to Blockchain Node &amp; REST/RPC APIs</h2>
                <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                  Execute live HTTP requests to any blockchain Node or API using Axios, with microsecond latency metrics, custom headers, and payload verification.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={fetchUndergroundStatus}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Activity className="w-3.5 h-3.5 text-amber-400" />
                  <span>Daemon Telemetry</span>
                </button>
              </div>
            </div>

            {/* Quick Presets */}
            <div className="mt-6 pt-4 border-t border-slate-800 flex flex-wrap items-center gap-2">
              <span className="text-[10px] font-bold text-slate-400 uppercase mr-1">Presets:</span>
              <button
                type="button"
                onClick={() => {
                  setHttpTargetUrl("https://api.blockcypher.com/v1/btc/main");
                  setHttpMethod("GET");
                  setHttpHeadersJson('{\n  "Accept": "application/json"\n}');
                  setHttpBodyJson("");
                }}
                className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-[11px] font-mono text-emerald-300 transition"
              >
                BlockCypher Chain Tip
              </button>

              <button
                type="button"
                onClick={() => {
                  setHttpTargetUrl("https://mempool.space/api/v1/fees/recommended");
                  setHttpMethod("GET");
                  setHttpHeadersJson('{\n  "Accept": "application/json"\n}');
                  setHttpBodyJson("");
                }}
                className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-[11px] font-mono text-amber-300 transition"
              >
                Mempool.space Fees
              </button>

              <button
                type="button"
                onClick={() => {
                  setHttpTargetUrl("https://blockstream.info/api/blocks/tip/height");
                  setHttpMethod("GET");
                  setHttpHeadersJson('{\n  "Accept": "text/plain"\n}');
                  setHttpBodyJson("");
                }}
                className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-[11px] font-mono text-sky-300 transition"
              >
                Blockstream Esplora Height
              </button>

              <button
                type="button"
                onClick={() => {
                  setHttpTargetUrl("http://127.0.0.1:8332");
                  setHttpMethod("POST");
                  setHttpHeadersJson('{\n  "Content-Type": "application/json"\n}');
                  setHttpBodyJson('{\n  "jsonrpc": "1.0",\n  "id": "sovereign",\n  "method": "getblockchaininfo",\n  "params": []\n}');
                }}
                className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-[11px] font-mono text-purple-300 transition"
              >
                Bitcoin Core Local JSON-RPC
              </button>
            </div>
          </div>

          {/* Request Form & Result Split */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Form */}
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Terminal className="w-4 h-4 text-amber-400" />
                <span>Axios HTTP Request Builder</span>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <select
                    value={httpMethod}
                    onChange={(e) => setHttpMethod(e.target.value as any)}
                    className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-xs font-bold text-amber-400 focus:outline-none"
                  >
                    <option value="GET">GET</option>
                    <option value="POST">POST</option>
                    <option value="PUT">PUT</option>
                  </select>

                  <input
                    type="text"
                    value={httpTargetUrl}
                    onChange={(e) => setHttpTargetUrl(e.target.value)}
                    placeholder="https://api.blockcypher.com/v1/btc/main or http://node-ip:8332"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white font-mono placeholder:text-slate-600 focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                    HTTP Headers (JSON)
                  </label>
                  <textarea
                    value={httpHeadersJson}
                    onChange={(e) => setHttpHeadersJson(e.target.value)}
                    rows={3}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-emerald-300 font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>

                {httpMethod !== "GET" && (
                  <div>
                    <label className="text-[10px] font-bold uppercase text-slate-400 block mb-1">
                      Request Body / JSON-RPC Payload
                    </label>
                    <textarea
                      value={httpBodyJson}
                      onChange={(e) => setHttpBodyJson(e.target.value)}
                      rows={4}
                      placeholder='{"jsonrpc": "2.0", "method": "getblockchaininfo", "params": []}'
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-sky-200 font-mono focus:outline-none focus:border-amber-500"
                    />
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleDispatchAxiosRequest}
                  disabled={isDispatchingHttp || !httpTargetUrl.trim()}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-black text-xs transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 shadow-lg shadow-amber-500/20"
                >
                  <Send className={`w-3.5 h-3.5 text-slate-950 ${isDispatchingHttp ? "animate-spin" : ""}`} />
                  <span>{isDispatchingHttp ? "Dispatching via Axios..." : "Dispatch HTTP Request via Axios"}</span>
                </button>
              </div>
            </div>

            {/* Response Console */}
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 space-y-4 shadow-xl flex flex-col">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-white font-bold text-sm">
                  <Database className="w-4 h-4 text-emerald-400" />
                  <span>Axios Response Receipt</span>
                </div>
                {httpResponseData && (
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                        httpResponseData.status >= 200 && httpResponseData.status < 300
                          ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                          : "bg-rose-500/20 text-rose-400 border border-rose-500/30"
                      }`}
                    >
                      HTTP {httpResponseData.status} {httpResponseData.statusText}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                      {httpResponseData.latencyMs} ms
                    </span>
                  </div>
                )}
              </div>

              {httpError && (
                <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-200 text-xs font-mono">
                  Error: {httpError}
                </div>
              )}

              {httpResponseData ? (
                <div className="flex-1 space-y-3">
                  <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono">
                    <span className="truncate max-w-[280px]">URL: {httpResponseData.targetUrl}</span>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(JSON.stringify(httpResponseData.data, null, 2), "axios_res")}
                      className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white flex items-center gap-1"
                    >
                      {copiedField === "axios_res" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>Copy JSON</span>
                    </button>
                  </div>

                  <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800 text-[11px] text-emerald-300 font-mono overflow-auto max-h-96 select-all scrollbar-thin">
                    {JSON.stringify(httpResponseData.data, null, 2)}
                  </pre>
                </div>
              ) : (
                <div className="flex-1 min-h-[220px] rounded-2xl bg-slate-950/60 border border-dashed border-slate-800 flex flex-col items-center justify-center p-6 text-center text-slate-500">
                  <Terminal className="w-8 h-8 text-slate-600 mb-2" />
                  <span className="text-xs font-bold text-slate-400">Ready to Dispatch</span>
                  <span className="text-[11px] mt-1 max-w-xs">
                    Choose a preset or enter target blockchain node endpoint and click dispatch.
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Node.js Underground Workers Live Feed */}
          {undergroundStatus && (
            <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 font-bold text-white text-sm">
                  <Activity className="w-4 h-4 text-sky-400" />
                  <span>Node.js Professional Logic Underground Daemon Status</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    PID {undergroundStatus.pid} • Uptime {undergroundStatus.uptimeSeconds}s
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {undergroundStatus.registeredWorkers?.map((w: any) => (
                  <div key={w.id} className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                    <div className="flex justify-between items-center text-xs font-bold text-slate-200">
                      <span className="truncate max-w-[200px]">{w.name}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300">
                        {w.status}
                      </span>
                    </div>
                    <div className="text-[10px] font-mono text-slate-400 flex justify-between">
                      <span>Every {w.frequencySeconds}s</span>
                      <span className="text-sky-300">{w.totalRuns} executions</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Recent Events Log */}
              {undergroundStatus.recentEvents && undergroundStatus.recentEvents.length > 0 && (
                <div className="pt-2 border-t border-slate-800 space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Underground Daemon Event Log
                  </span>
                  <div className="space-y-1 max-h-36 overflow-y-auto font-mono text-[10.5px]">
                    {undergroundStatus.recentEvents.slice(0, 5).map((evt: any) => (
                      <div key={evt.id} className="p-2 rounded-xl bg-slate-950 text-slate-300 flex items-start gap-2">
                        <span className="text-sky-400 font-bold shrink-0">[{evt.action}]</span>
                        <span className="text-slate-300">{evt.details}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
