import React, { useState, useEffect } from "react";
import {
  Globe,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  Coins,
  RefreshCw,
  TrendingUp,
  Award,
  Link,
  QrCode,
  FileCheck,
} from "lucide-react";

export const CryptoMarketLegitimacy: React.FC = () => {
  const [telemetryData, setTelemetryData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [selectedAsset, setSelectedAsset] = useState<any>(null);

  const fetchTelemetry = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/v1/commercial-banking/market-telemetry");
      const data = await res.json();
      if (data.success) {
        setTelemetryData(data);
        if (data.assets && data.assets.length > 0) {
          setSelectedAsset(data.assets[0]);
        }
      }
    } catch {
      // offline fallback
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTelemetry();
  }, []);

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header Banner */}
      <div className="rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 via-slate-900/90 to-amber-950/40 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-400 font-mono text-[10px] font-extrabold uppercase border border-amber-500/30 flex items-center gap-1.5">
                <Coins className="w-3 h-3 text-amber-400" />
                <span>GLOBAL CRYPTOCURRENCY MARKET IDENTIFIERS</span>
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/20">
                FATF TRAVEL RULE (IVMS 101) COMPLIANT
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Legitimate Global Cryptocurrency Market Identification
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Fully identified with the global cryptocurrency market through authoritative CoinGecko IDs,
              Chainlink decentralized price oracle feeds, CAIP-10 multi-chain account identifiers, and FATF Travel Rule compliance.
            </p>
          </div>

          <button
            onClick={fetchTelemetry}
            className="self-start md:self-center flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 border border-slate-700 transition cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
            <span>Refresh Oracle Feeds</span>
          </button>
        </div>

        {/* Global Compliance Badges */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-wrap items-center gap-3 text-xs font-mono">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <span className="text-slate-300">VASP LEI: <strong className="text-white">894500HEOFLIXSOV01</strong></span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-300">InterVASP Messaging: <strong className="text-emerald-400">IVMS 101 Standard</strong></span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
            <Link className="w-4 h-4 text-sky-400" />
            <span className="text-slate-300">Price Oracle: <strong className="text-sky-300">Chainlink Aggregator V3</strong></span>
          </div>
        </div>
      </div>

      {/* Asset Cards & Market Detail Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Assets Selector Column */}
        <div className="space-y-3">
          <span className="text-[10px] font-mono uppercase text-slate-400 tracking-wider block font-semibold">
            Recognized Global Crypto Assets
          </span>

          {telemetryData?.assets?.map((asset: any) => {
            const isSelected = selectedAsset?.token === asset.token;

            return (
              <div
                key={asset.token}
                onClick={() => setSelectedAsset(asset)}
                className={`p-4 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? "border-amber-500 bg-amber-950/20 shadow-lg shadow-amber-950/20"
                    : "border-slate-800 bg-slate-900/80 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center font-bold text-amber-400 text-sm">
                    {asset.token === "BTC" ? "₿" : asset.token === "ETH" ? "Ξ" : "$"}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <strong className="text-white text-sm">{asset.token}</strong>
                      <span className="text-[10px] text-slate-400 font-mono">({asset.name})</span>
                    </div>
                    <span className="text-xs font-mono text-emerald-400 font-bold">
                      ${asset.currentUsdPrice.toLocaleString()} USD
                    </span>
                  </div>
                </div>

                <div className="text-right font-mono text-[11px]">
                  <span className="text-emerald-400 font-bold block">+{asset.change24h}%</span>
                  <span className="text-[10px] text-slate-400">{asset.marketCapUsd} MCAP</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Asset Deep Legitimacy & Verification Sheet */}
        {selectedAsset && (
          <div className="lg:col-span-2 rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-8 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xl font-black text-white">{selectedAsset.name}</span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-mono font-bold">
                    {selectedAsset.legitimateStatus}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Global Trading Pairs: <strong className="text-slate-200">{selectedAsset.globalExchangePair}</strong>
                </p>
              </div>

              <a
                href={selectedAsset.blockExplorerUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold border border-slate-700 transition"
              >
                <span>Mempool / Explorer</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Technical Identification Data Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                  CoinGecko Market ID
                </span>
                <span className="text-white font-bold text-sm">{selectedAsset.coingeckoId}</span>
                <span className="text-[10px] text-slate-500 block">CMC ID: #{selectedAsset.coinmarketcapId}</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                  Chainlink Decentralized Oracle
                </span>
                <span className="text-sky-400 font-bold text-xs truncate block select-all">
                  {selectedAsset.chainlinkOracle}
                </span>
                <span className="text-[10px] text-slate-500 block">Sub-second Aggregator Heartbeat</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1 sm:col-span-2">
                <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                  CAIP-10 Multi-Chain Account Identifier
                </span>
                <span className="text-emerald-400 font-bold text-xs truncate block select-all">
                  {selectedAsset.caip10}
                </span>
                <span className="text-[10px] text-slate-500 block">Standardized Interoperable Chain Namespace</span>
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1 sm:col-span-2">
                <span className="text-[10px] uppercase text-slate-400 block font-semibold">
                  Primary Vault Wallet Address ({selectedAsset.addressFormat})
                </span>
                <span className="text-amber-400 font-bold text-xs select-all break-all">
                  {selectedAsset.primaryAddress}
                </span>
                <span className="text-[10px] text-slate-500 block">Derivation: {selectedAsset.derivationPath}</span>
              </div>
            </div>

            {/* Global Exchanges Recognition */}
            <div className="pt-2">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-2 font-semibold">
                Exchange Liquidity &amp; Recognition Network
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs font-medium">
                {["Binance Global", "Coinbase Prime", "Kraken", "OKX Clearing", "Bybit Web3", "Luno & Quidax"].map((ex) => (
                  <div key={ex} className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="text-slate-200 text-xs">{ex}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
