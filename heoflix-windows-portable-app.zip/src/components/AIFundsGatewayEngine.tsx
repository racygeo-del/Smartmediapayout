import React, { useState, useEffect } from "react";
import {
  Zap,
  Building,
  Coins,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  RefreshCw,
  ArrowRight,
  ExternalLink,
  Sparkles,
  Lock,
  Download,
  Key,
  Globe,
  Radio,
  FileText,
  DollarSign,
  TrendingUp,
  Cpu,
  Layers,
  ArrowUpRight,
  CheckCircle,
  Terminal,
  Send,
  Eye,
  X,
  CreditCard,
} from "lucide-react";
import { WalletState } from "../types";

interface AIFundsGatewayEngineProps {
  wallet?: WalletState;
  onUpdateWallet?: (newWallet: WalletState) => void;
  onRefreshAllData?: () => void;
}

export const AIFundsGatewayEngine: React.FC<AIFundsGatewayEngineProps> = ({
  wallet,
  onUpdateWallet,
  onRefreshAllData,
}) => {
  // Destination Mode: Bank or Crypto
  const [destinationType, setDestinationType] = useState<"BANK" | "CRYPTO">("BANK");

  // Gateway Profile State
  const [gatewayData, setGatewayData] = useState<any>(null);
  const [isLoadingGateway, setIsLoadingGateway] = useState<boolean>(true);
  const [isGeneratingGateway, setIsGeneratingGateway] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Bank Form State
  const [selectedBankPreset, setSelectedBankPreset] = useState<"opay" | "firstbank" | "chase" | "custom">("opay");
  const [bankName, setBankName] = useState<string>("OPAY");
  const [accountNumber, setAccountNumber] = useState<string>("8134762646");
  const [accountName, setAccountName] = useState<string>("George Felix Egwu");
  const [routingCode, setRoutingCode] = useState<string>("999992");
  const [bankCurrency, setBankCurrency] = useState<string>("USD");

  // Crypto Form State
  const [selectedCryptoPreset, setSelectedCryptoPreset] = useState<"btc" | "usdt_trc20" | "usdc_erc20" | "sol" | "custom">("btc");
  const [cryptoToken, setCryptoToken] = useState<string>("BTC");
  const [cryptoNetwork, setCryptoNetwork] = useState<string>("BITCOIN");
  const [cryptoAddress, setCryptoAddress] = useState<string>("34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW");
  const [cryptoMemo, setCryptoMemo] = useState<string>("AI Generated Funds Sovereign Payout");

  // Amount State
  const [transferAmount, setTransferAmount] = useState<string>("10000");

  // Transfer Execution State
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [executionStep, setExecutionStep] = useState<number>(0);
  const [executionReceipt, setExecutionReceipt] = useState<any>(null);
  const [transferError, setTransferError] = useState<string | null>(null);

  // API Docs Snippet Language
  const [docLang, setDocLang] = useState<"curl" | "node" | "python" | "go">("curl");

  // Quick Notification Toast
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Sound cue
  const playChime = (success = true) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(success ? 659.25 : 330, ctx.currentTime);
      if (success) {
        osc.frequency.exponentialRampToValueAtTime(1046.5, ctx.currentTime + 0.18);
      }
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch {}
  };

  // Fetch AI Funds Gateway Status
  const fetchGatewayStatus = async () => {
    try {
      const res = await fetch("/api/v1/gateway/ai-funds-status");
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setGatewayData(data);
        }
      }
    } catch {
    } finally {
      setIsLoadingGateway(false);
    }
  };

  useEffect(() => {
    fetchGatewayStatus();
  }, []);

  // Handle Preset Changes for Bank
  const handleSelectBankPreset = (preset: "opay" | "firstbank" | "chase" | "custom") => {
    setSelectedBankPreset(preset);
    if (preset === "opay") {
      setBankName("OPAY");
      setAccountNumber("8134762646");
      setAccountName("George Felix Egwu");
      setRoutingCode("999992");
      setBankCurrency("NGN");
    } else if (preset === "firstbank") {
      setBankName("First Bank of Nigeria PLC");
      setAccountNumber("3081928401");
      setAccountName("George Felix Egwu");
      setRoutingCode("011151");
      setBankCurrency("NGN");
    } else if (preset === "chase") {
      setBankName("JPMorgan Chase Bank N.A.");
      setAccountNumber("0928371948");
      setAccountName("George Felix Egwu");
      setRoutingCode("021000021");
      setBankCurrency("USD");
    }
  };

  // Handle Preset Changes for Crypto
  const handleSelectCryptoPreset = (preset: "btc" | "usdt_trc20" | "usdc_erc20" | "sol" | "custom") => {
    setSelectedCryptoPreset(preset);
    if (preset === "btc") {
      setCryptoToken("BTC");
      setCryptoNetwork("BITCOIN");
      setCryptoAddress("34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW");
      setCryptoMemo("Primary Sovereign Bitcoin Vault (P2SH SegWit)");
    } else if (preset === "usdt_trc20") {
      setCryptoToken("USDT");
      setCryptoNetwork("TRC20");
      setCryptoAddress("TYDny55a3Ksmk4V2dJ4K5VwU9qE2o3W6Vz");
      setCryptoMemo("Cold Storage TRON Reserve (TRC-20)");
    } else if (preset === "usdc_erc20") {
      setCryptoToken("USDC");
      setCryptoNetwork("ERC20");
      setCryptoAddress("0x742d35Cc6634C0532925a3b844Bc454e4438f44e");
      setCryptoMemo("Ethereum Multi-Sig Vault (ERC-20)");
    } else if (preset === "sol") {
      setCryptoToken("USDC");
      setCryptoNetwork("SOL");
      setCryptoAddress("7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU");
      setCryptoMemo("Solana DeFi Treasury (SPL Token)");
    }
  };

  // Automatically Generate Gateway for AI Funds
  const handleAutoGenerateGateway = async () => {
    setIsGeneratingGateway(true);
    try {
      const res = await fetch("/api/v1/gateway/auto-generate-ai-gateway", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          label: "Autonomous AI Generated Funds Settlement Gateway",
          dailyLimitUsd: 5000000,
        }),
      });
      const data = await res.json();
      if (data.success) {
        playChime(true);
        triggerToast("Gateway automatically generated! Live API keys & endpoints active.");
        fetchGatewayStatus();
      }
    } catch {
      triggerToast("Failed to generate gateway.");
    } finally {
      setIsGeneratingGateway(false);
    }
  };

  // Copy helper
  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    triggerToast(`Copied ${label} to clipboard!`);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  // Execute Transfer of AI Funds
  const handleExecuteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmt = parseFloat(transferAmount);
    if (isNaN(numAmt) || numAmt <= 0) {
      setTransferError("Please enter a valid positive transfer amount.");
      return;
    }

    const availableBal = wallet?.availableBalance ?? (gatewayData?.treasury?.availableBalance || 2489150);
    if (numAmt > availableBal) {
      setTransferError(`Transfer amount ($${numAmt.toLocaleString()}) exceeds available AI funds ($${availableBal.toLocaleString()}).`);
      return;
    }

    setTransferError(null);
    setIsExecuting(true);
    setExecutionStep(1);

    // Simulated multi-step execution pipeline
    setTimeout(() => setExecutionStep(2), 600);
    setTimeout(() => setExecutionStep(3), 1300);

    try {
      const payload: any = {
        destinationType,
        amount: numAmt,
      };

      if (destinationType === "BANK") {
        payload.bankName = bankName;
        payload.accountNumber = accountNumber;
        payload.accountName = accountName;
        payload.routingCode = routingCode;
        payload.destinationCurrency = bankCurrency;
      } else {
        payload.cryptoNetwork = cryptoNetwork;
        payload.cryptoToken = cryptoToken;
        payload.cryptoAddress = cryptoAddress;
        payload.cryptoMemo = cryptoMemo;
      }

      const res = await fetch("/api/v1/gateway/ai-funds-transfer", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Traffic-Priority": "CRITICAL_FINANCIAL",
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      setTimeout(() => {
        if (data.success && data.receipt) {
          playChime(true);
          setExecutionStep(4);
          setExecutionReceipt(data.receipt);
          triggerToast(`Transfer of $${numAmt.toLocaleString()} successfully cleared!`);

          // Update local state if wallet hook provided
          if (wallet && onUpdateWallet) {
            onUpdateWallet({
              ...wallet,
              totalBalance: Number((wallet.totalBalance - numAmt).toFixed(2)),
              availableBalance: Number((wallet.availableBalance - numAmt).toFixed(2)),
            });
          }

          if (onRefreshAllData) {
            onRefreshAllData();
          }

          fetchGatewayStatus();
        } else {
          playChime(false);
          setTransferError(data.message || data.error || "Transfer failed to settle.");
        }
        setIsExecuting(false);
      }, 1900);
    } catch (err: any) {
      playChime(false);
      setIsExecuting(false);
      setTransferError(err?.message || "Connection error during gateway transfer execution.");
    }
  };

  // Available live balance
  const liveAvailableBal = wallet?.availableBalance ?? (gatewayData?.treasury?.availableBalance || 2489150);
  const activeApiKey = gatewayData?.gateway?.apiKey || "gw_live_a89f21b409c8241e73a019485b02f9c4";
  const numTransfer = parseFloat(transferAmount) || 0;
  const fxNgn = numTransfer * 1550;
  const estBtc = numTransfer > 0 ? (numTransfer / 65000).toFixed(6) : "0.000000";

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Toast notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 p-3.5 rounded-2xl bg-emerald-950/95 border border-emerald-500/60 text-emerald-200 text-xs font-mono font-bold shadow-2xl flex items-center gap-2 animate-bounce">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* =========================================================================
          BANNER: AUTONOMOUSLY GENERATED GATEWAY STATUS & AI FUNDS TREASURY
      ========================================================================= */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/40 rounded-3xl p-6 sm:p-7 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2.5">
            <div className="flex items-center gap-2.5 flex-wrap">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                AUTOMATIC GATEWAY GENERATED &amp; ACTIVE
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-sky-500/15 text-sky-300 border border-sky-500/30 flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5" />
                AI FUNDS LIQUIDITY SWITCH
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                DAILY LIMIT: $5,000,000 USD
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                ONLINE BANKING APP: LINKED TO DOLLAR WALLET
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
              <span>Autonomous Gateway for AI Generated Funds</span>
              <Sparkles className="w-5 h-5 text-amber-400 animate-pulse" />
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              Programmatically route and disburse your AI-generated Dollar earnings to <strong>any commercial bank</strong> (OPAY, First Bank, Chase, Barclays, SEPA, SWIFT) or <strong>any cryptocurrency wallet</strong> (Bitcoin, USDT-TRC20, USDC-ERC20, Solana, Polygon) with zero friction and instant finality.
            </p>
          </div>

          {/* Quick Gateway Auto-Regeneration Action */}
          <div className="flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end gap-2.5 shrink-0">
            <button
              onClick={handleAutoGenerateGateway}
              disabled={isGeneratingGateway}
              className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-sky-500 hover:from-emerald-400 hover:to-sky-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-95"
            >
              <RefreshCw className={`w-4 h-4 ${isGeneratingGateway ? "animate-spin" : ""}`} />
              <span>{isGeneratingGateway ? "Generating Gateway..." : "⚡ Regenerate AI Gateway Keys"}</span>
            </button>
            <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5 justify-center sm:justify-start lg:justify-end">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Sovereign FIDO2 Clearance Active</span>
            </div>
          </div>
        </div>

        {/* Live Treasury Balances Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800/80">
          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800">
            <span className="text-[10px] text-slate-400 block font-mono uppercase font-bold">Total AI Vault Balance</span>
            <div className="text-lg sm:text-xl font-black text-white font-mono mt-0.5">
              ${liveAvailableBal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-emerald-400 font-mono">100% Unlocked • Ready to send</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800">
            <span className="text-[10px] text-slate-400 block font-mono uppercase font-bold">Arbitrage Trading Yield</span>
            <div className="text-lg sm:text-xl font-black text-sky-400 font-mono mt-0.5">
              ${(wallet?.adminReserve ?? 487200).toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Autonomous DEX Spreads</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800">
            <span className="text-[10px] text-slate-400 block font-mono uppercase font-bold">Ecosystem &amp; Media Yield</span>
            <div className="text-lg sm:text-xl font-black text-indigo-400 font-mono mt-0.5">
              ${(wallet?.lifetimeEarnings ?? 312900).toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-slate-400 font-mono">Social Engine Monetization</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-800">
            <span className="text-[10px] text-slate-400 block font-mono uppercase font-bold">Daily Accrued Rate</span>
            <div className="text-lg sm:text-xl font-black text-emerald-400 font-mono mt-0.5">
              +${(wallet?.dailyAccruedFund ?? 4159.3).toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-emerald-400/80 font-mono">Streaming 24/7/365</span>
          </div>
        </div>

        {/* Live Generated Credentials Bar */}
        <div className="mt-4 p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span>Gateway API Key:</span>
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-sky-300 font-bold select-all">
              {activeApiKey}
            </span>
            <button
              onClick={() => handleCopy(activeApiKey, "API Key")}
              className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
              title="Copy API Key"
            >
              {copiedKey === "API Key" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="flex items-center gap-3 text-slate-400">
            <span>Webhook: <strong className="text-slate-200">/api/v1/gateway/webhook/ai-funds</strong></span>
            <span>•</span>
            <span className="text-emerald-400 font-bold">Latency: &lt; 0.8s</span>
          </div>
        </div>
      </div>

      {/* =========================================================================
          MAIN INTERACTIVE TRANSFER WORKSPACE: TRANSFER AI FUNDS TO BANK OR CRYPTO
      ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form: Transfer Configuration (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                  <Send className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    Transfer AI Funds to Destination
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono">
                    Instant liquidation from Dollar Vault directly into bank or crypto
                  </p>
                </div>
              </div>

              {/* Destination Type Toggle */}
              <div className="flex items-center p-1 rounded-2xl bg-slate-950 border border-slate-800">
                <button
                  type="button"
                  onClick={() => setDestinationType("BANK")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    destinationType === "BANK"
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/40"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <Building className="w-3.5 h-3.5" />
                  <span>Any Bank</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDestinationType("CRYPTO")}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    destinationType === "CRYPTO"
                      ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/40"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <Coins className="w-3.5 h-3.5" />
                  <span>Any Crypto Wallet</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleExecuteTransfer} className="space-y-4">
              {/* BANK MODE FORM */}
              {destinationType === "BANK" && (
                <div className="space-y-4 animate-in fade-in">
                  {/* Presets */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1.5 flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-sky-400" />
                      <span>Select Verified Bank Destination or Custom</span>
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleSelectBankPreset("opay")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedBankPreset === "opay"
                            ? "bg-emerald-950/50 border-emerald-500/50 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-400">OPAY (NIP Switch)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">PRIMARY</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">8134762646</div>
                        <div className="text-[10px] text-slate-400">George Felix Egwu • Instant NIP Settlement</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectBankPreset("firstbank")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedBankPreset === "firstbank"
                            ? "bg-sky-950/50 border-sky-500/50 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-sky-400">First Bank of Nigeria</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono">DOM/NGN</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">3081928401</div>
                        <div className="text-[10px] text-slate-400">George Felix Egwu • Commercial Account</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectBankPreset("chase")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedBankPreset === "chase"
                            ? "bg-indigo-950/50 border-indigo-500/50 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-indigo-400">JPMorgan Chase (US)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">FEDNOW RTP</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">•••• 8192</div>
                        <div className="text-[10px] text-slate-400">George Felix Egwu • Instant US Dollar Clearing</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectBankPreset("custom")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedBankPreset === "custom"
                            ? "bg-purple-950/50 border-purple-500/50 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-purple-400">Custom Bank (Any Global Bank)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">SWIFT / IBAN</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">Enter custom account details below</div>
                        <div className="text-[10px] text-slate-400">FedNow, SEPA, Faster Payments, or SWIFT</div>
                      </button>
                    </div>
                  </div>

                  {/* Detailed Input Fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Bank Name / Switch</label>
                      <input
                        type="text"
                        value={bankName}
                        onChange={(e) => setBankName(e.target.value)}
                        placeholder="e.g. OPAY, First Bank, Chase, Barclays"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Account Number / IBAN</label>
                      <input
                        type="text"
                        value={accountNumber}
                        onChange={(e) => setAccountNumber(e.target.value)}
                        placeholder="e.g. 8134762646 or GB29NWBK..."
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:border-indigo-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Beneficiary Name</label>
                      <input
                        type="text"
                        value={accountName}
                        onChange={(e) => setAccountName(e.target.value)}
                        placeholder="e.g. George Felix Egwu"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Target Currency</label>
                      <select
                        value={bankCurrency}
                        onChange={(e) => setBankCurrency(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                      >
                        <option value="USD">USD - United States Dollar (FedNow / RTP)</option>
                        <option value="NGN">NGN - Nigerian Naira (1550 NGN/USD - OPAY/NIP Instant)</option>
                        <option value="EUR">EUR - Euro (SEPA Instant)</option>
                        <option value="GBP">GBP - British Pound (Faster Payments)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* CRYPTO MODE FORM */}
              {destinationType === "CRYPTO" && (
                <div className="space-y-4 animate-in fade-in">
                  {/* Crypto Presets */}
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1.5 flex items-center gap-1.5">
                      <Coins className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Select Verified Crypto Wallet or Custom Address</span>
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleSelectCryptoPreset("btc")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedCryptoPreset === "btc"
                            ? "bg-amber-950/50 border-amber-500/50 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-amber-400">Bitcoin Vault (BTC)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">P2SH SEGWIT</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1 truncate">34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW</div>
                        <div className="text-[10px] text-slate-400">Linked Sovereign Vault • Mempool Confirmed</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectCryptoPreset("usdt_trc20")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedCryptoPreset === "usdt_trc20"
                            ? "bg-emerald-950/50 border-emerald-500/50 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-400">TRON Cold Storage (USDT)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">TRC-20</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1 truncate">TYDny55a3Ksmk4V2dJ4K5VwU9qE2o3W6Vz</div>
                        <div className="text-[10px] text-slate-400">Zero Fee • Instant 30s Finality</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectCryptoPreset("usdc_erc20")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedCryptoPreset === "usdc_erc20"
                            ? "bg-indigo-950/50 border-indigo-500/50 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-indigo-400">Ethereum Vault (USDC)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">ERC-20</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1 truncate">0x742d35Cc6634C0532925a3b844Bc454e4438f44e</div>
                        <div className="text-[10px] text-slate-400">Institutional Multi-Sig Protection</div>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSelectCryptoPreset("custom")}
                        className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                          selectedCryptoPreset === "custom"
                            ? "bg-purple-950/50 border-purple-500/50 text-white"
                            : "bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-purple-400">Custom Address (Any Wallet)</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">ALL CHAINS</span>
                        </div>
                        <div className="text-xs font-mono text-slate-200 mt-1">Enter any public blockchain address</div>
                        <div className="text-[10px] text-slate-400">Trust Wallet, Binance, Coinbase, Ledger</div>
                      </button>
                    </div>
                  </div>

                  {/* Detailed Input Fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Asset Token</label>
                      <select
                        value={cryptoToken}
                        onChange={(e) => setCryptoToken(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                      >
                        <option value="BTC">BTC - Bitcoin</option>
                        <option value="USDT">USDT - Tether USD</option>
                        <option value="USDC">USDC - USD Coin</option>
                        <option value="SOL">SOL - Solana</option>
                        <option value="ETH">ETH - Ethereum</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Blockchain Network</label>
                      <select
                        value={cryptoNetwork}
                        onChange={(e) => setCryptoNetwork(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                      >
                        <option value="BITCOIN">Bitcoin Network (Native &amp; P2SH)</option>
                        <option value="TRC20">TRON Network (TRC-20)</option>
                        <option value="ERC20">Ethereum Mainnet (ERC-20)</option>
                        <option value="SOL">Solana Blockchain (SPL)</option>
                        <option value="POLYGON">Polygon PoS</option>
                        <option value="ARBITRUM">Arbitrum One</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-slate-400 block mb-1">Transfer Memo / Tag</label>
                      <input
                        type="text"
                        value={cryptoMemo}
                        onChange={(e) => setCryptoMemo(e.target.value)}
                        placeholder="e.g. AI Funds Payout"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-400 block mb-1">Recipient Public Blockchain Address</label>
                    <input
                      type="text"
                      value={cryptoAddress}
                      onChange={(e) => setCryptoAddress(e.target.value)}
                      placeholder="e.g. 34m9vs... or TYDny55a... or 0x742d..."
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>
                </div>
              )}

              {/* AMOUNT INPUT & QUICK PRESET BUTTONS */}
              <div className="pt-2 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-bold text-white flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Transfer Amount from AI Funds ($ USD)</span>
                  </label>
                  <span className="text-[11px] font-mono text-slate-400">
                    Available: <strong className="text-emerald-400">${liveAvailableBal.toLocaleString()}</strong>
                  </span>
                </div>

                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <span className="text-slate-400 font-bold">$</span>
                  </div>
                  <input
                    type="number"
                    min="1"
                    max={liveAvailableBal}
                    step="any"
                    value={transferAmount}
                    onChange={(e) => setTransferAmount(e.target.value)}
                    className="w-full pl-8 pr-28 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-lg font-black font-mono text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                    placeholder="Enter amount to transfer"
                    required
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center gap-1.5 pointer-events-none">
                    <span className="text-xs font-bold font-mono px-2 py-1 rounded bg-slate-800 text-slate-300">
                      USD
                    </span>
                  </div>
                </div>

                {/* Quick percentage buttons */}
                <div className="flex items-center gap-2 flex-wrap pt-1">
                  <button
                    type="button"
                    onClick={() => setTransferAmount("1000")}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-semibold transition cursor-pointer"
                  >
                    $1,000
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransferAmount("10000")}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-semibold transition cursor-pointer"
                  >
                    $10,000
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransferAmount("50000")}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-semibold transition cursor-pointer"
                  >
                    $50,000
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransferAmount("100000")}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono font-semibold transition cursor-pointer"
                  >
                    $100,000
                  </button>
                  <button
                    type="button"
                    onClick={() => setTransferAmount(String(Math.floor(liveAvailableBal)))}
                    className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30 text-xs font-mono font-bold transition cursor-pointer"
                  >
                    ALL AI FUNDS (${Math.floor(liveAvailableBal).toLocaleString()})
                  </button>
                </div>

                {/* Real-time Conversion & Rail Breakdown */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs font-mono">
                  <div className="text-slate-300">
                    {destinationType === "BANK" ? (
                      bankCurrency === "NGN" ? (
                        <span>Settlement Equivalent: <strong className="text-emerald-400">₦{fxNgn.toLocaleString()} NGN</strong> (@ 1,550 FX)</span>
                      ) : (
                        <span>Settlement Equivalent: <strong className="text-emerald-400">${numTransfer.toLocaleString()} USD</strong></span>
                      )
                    ) : cryptoToken === "BTC" ? (
                      <span>Settlement Equivalent: <strong className="text-amber-400">₿ {estBtc} BTC</strong> (@ $65,000)</span>
                    ) : (
                      <span>Settlement Equivalent: <strong className="text-emerald-400">{numTransfer.toLocaleString()} {cryptoToken}</strong></span>
                    )}
                  </div>
                  <div className="text-emerald-400 font-bold">
                    Network Fee: $0.00 (Sovereign Sponsored)
                  </div>
                </div>
              </div>

              {/* Error Banner */}
              {transferError && (
                <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs font-mono flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{transferError}</span>
                </div>
              )}

              {/* Multi-step Execution Visualizer */}
              {isExecuting && (
                <div className="p-4 rounded-2xl bg-slate-950 border border-indigo-500/40 space-y-2 animate-in fade-in">
                  <div className="flex items-center justify-between text-xs font-mono font-bold text-slate-300">
                    <span className="flex items-center gap-2 text-indigo-400">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Processing Gateway Liquidity Routing...</span>
                    </span>
                    <span>Step {executionStep} of 4</span>
                  </div>
                  <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full transition-all duration-500"
                      style={{ width: `${(executionStep / 4) * 100}%` }}
                    />
                  </div>
                  <div className="text-[11px] font-mono text-slate-400">
                    {executionStep === 1 && "1/4: Authenticating Sovereign API Gateway Token & Nonce..."}
                    {executionStep === 2 && "2/4: Liquidating funds from AI Dollar Vault Treasury..."}
                    {executionStep === 3 && `3/4: Broadcasting to ${destinationType === "BANK" ? "Commercial Interbank Clearing Rail" : `${cryptoNetwork} Blockchain Mempool`}...`}
                    {executionStep === 4 && "4/4: Settlement cleared and cryptographically signed!"}
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isExecuting || numTransfer <= 0}
                className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600 hover:from-emerald-400 hover:to-indigo-500 text-slate-950 hover:text-white font-black text-sm tracking-wide shadow-xl shadow-emerald-500/20 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-98"
              >
                <Zap className="w-4 h-4 fill-current" />
                <span>
                  {isExecuting
                    ? "Transacting via Gateway..."
                    : `🚀 Transfer $${numTransfer > 0 ? numTransfer.toLocaleString() : "0"} AI Funds to ${destinationType === "BANK" ? bankName : cryptoToken}`}
                </span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Panel: Auto-Generated API Docs & Recent Transfers (5 cols) */}
        <div className="lg:col-span-5 space-y-5">
          {/* Recent Transacted Receipt Highlight Card */}
          {executionReceipt && (
            <div className="bg-gradient-to-br from-emerald-950/80 via-slate-900 to-teal-950/80 border border-emerald-500/50 rounded-3xl p-5 shadow-2xl space-y-3 animate-in fade-in">
              <div className="flex items-center justify-between pb-2 border-b border-emerald-500/30">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-black text-emerald-300 font-mono uppercase">
                    Transfer Successfully Cleared
                  </span>
                </div>
                <button
                  onClick={() => setExecutionReceipt(null)}
                  className="text-slate-400 hover:text-white p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-1.5 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Reference / TXID:</span>
                  <span className="text-white font-bold truncate max-w-[200px]" title={executionReceipt.referenceId}>
                    {executionReceipt.referenceId}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Transferred:</span>
                  <span className="text-emerald-400 font-black">
                    ${executionReceipt.amountUsd.toLocaleString()} USD
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Destination:</span>
                  <span className="text-slate-200 truncate max-w-[200px]">
                    {executionReceipt.destinationSummary}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Clearing Rail:</span>
                  <span className="text-sky-300 font-bold">{executionReceipt.settlementRail}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Digital Proof:</span>
                  <span className="text-slate-400 text-[10px] truncate max-w-[180px]">{executionReceipt.signature}</span>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <a
                  href={executionReceipt.trackingUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs text-center flex items-center justify-center gap-1.5 transition"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>View Proof on Explorer</span>
                </a>
                <button
                  onClick={() => handleCopy(JSON.stringify(executionReceipt, null, 2), "Receipt JSON")}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                  title="Copy Receipt Data"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Auto-Generated Code Snippets for Developers */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-sky-400" />
                <h4 className="text-xs font-black text-white uppercase tracking-wider">
                  Auto-Generated API Endpoint &amp; SDK
                </h4>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-mono">
                <button
                  type="button"
                  onClick={() => setDocLang("curl")}
                  className={`px-2 py-0.5 rounded ${docLang === "curl" ? "bg-sky-600 text-white font-bold" : "text-slate-400 hover:text-white"}`}
                >
                  cURL
                </button>
                <button
                  type="button"
                  onClick={() => setDocLang("node")}
                  className={`px-2 py-0.5 rounded ${docLang === "node" ? "bg-sky-600 text-white font-bold" : "text-slate-400 hover:text-white"}`}
                >
                  Node.js
                </button>
                <button
                  type="button"
                  onClick={() => setDocLang("python")}
                  className={`px-2 py-0.5 rounded ${docLang === "python" ? "bg-sky-600 text-white font-bold" : "text-slate-400 hover:text-white"}`}
                >
                  Python
                </button>
                <button
                  type="button"
                  onClick={() => setDocLang("go")}
                  className={`px-2 py-0.5 rounded ${docLang === "go" ? "bg-sky-600 text-white font-bold" : "text-slate-400 hover:text-white"}`}
                >
                  Go
                </button>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              Call your automatically generated API gateway to transfer AI funds from automated bots, external apps, or scheduled cron workflows:
            </p>

            <div className="relative group">
              <pre className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-sky-300 overflow-x-auto max-h-48 scrollbar-thin">
                {docLang === "curl" &&
`curl -X POST https://www.heoflix.com/api/v1/gateway/ai-funds-transfer \\
  -H "Content-Type: application/json" \\
  -H "X-Gateway-Key: ${activeApiKey}" \\
  -d '{
    "destinationType": "${destinationType}",
    "amount": ${numTransfer || 10000},
    ${destinationType === "BANK" ? `"bankName": "${bankName}",
    "accountNumber": "${accountNumber}",
    "accountName": "${accountName}"` : `"cryptoNetwork": "${cryptoNetwork}",
    "cryptoToken": "${cryptoToken}",
    "cryptoAddress": "${cryptoAddress}"`}
  }'`}
                {docLang === "node" &&
`import axios from "axios";

const res = await axios.post("https://www.heoflix.com/api/v1/gateway/ai-funds-transfer", {
  destinationType: "${destinationType}",
  amount: ${numTransfer || 10000},
  ${destinationType === "BANK" ? `bankName: "${bankName}",
  accountNumber: "${accountNumber}",
  accountName: "${accountName}"` : `cryptoNetwork: "${cryptoNetwork}",
  cryptoToken: "${cryptoToken}",
  cryptoAddress: "${cryptoAddress}"`}
}, {
  headers: { "X-Gateway-Key": "${activeApiKey}" }
});
console.log("Transferred Reference:", res.data.receipt.referenceId);`}
                {docLang === "python" &&
`import requests

url = "https://www.heoflix.com/api/v1/gateway/ai-funds-transfer"
headers = {"X-Gateway-Key": "${activeApiKey}", "Content-Type": "application/json"}
payload = {
    "destinationType": "${destinationType}",
    "amount": ${numTransfer || 10000},
    ${destinationType === "BANK" ? `"bankName": "${bankName}",
    "accountNumber": "${accountNumber}"` : `"cryptoNetwork": "${cryptoNetwork}",
    "cryptoAddress": "${cryptoAddress}"`}
}
resp = requests.post(url, json=payload, headers=headers)
print("Receipt Reference:", resp.json()["receipt"]["referenceId"])`}
                {docLang === "go" &&
`package main

import (
  "bytes"
  "fmt"
  "net/http"
)

func main() {
  body := []byte(\`{"destinationType":"${destinationType}","amount":${numTransfer || 10000}}\`)
  req, _ := http.NewRequest("POST", "https://www.heoflix.com/api/v1/gateway/ai-funds-transfer", bytes.NewBuffer(body))
  req.Header.Set("X-Gateway-Key", "${activeApiKey}")
  req.Header.Set("Content-Type", "application/json")
  resp, _ := (&http.Client{}).Do(req)
  fmt.Println("Cleared Status:", resp.Status)
}`}
              </pre>

              <button
                type="button"
                onClick={() => {
                  const code = docLang === "curl"
                    ? `curl -X POST https://www.heoflix.com/api/v1/gateway/ai-funds-transfer -H "Content-Type: application/json" -H "X-Gateway-Key: ${activeApiKey}" -d '{"destinationType": "${destinationType}", "amount": ${numTransfer || 10000}}'`
                    : activeApiKey;
                  handleCopy(code, "API Code");
                }}
                className="absolute top-2.5 right-2.5 p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                title="Copy Snippet"
              >
                {copiedKey === "API Code" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Recent AI Funds Transfers History Table */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-black text-white uppercase tracking-wider">
                  Recent AI Funds Transfers
                </h4>
              </div>
              <span className="text-[11px] font-mono text-slate-400">
                {gatewayData?.recentTransfers?.length || 4} settled
              </span>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto scrollbar-thin">
              {(gatewayData?.recentTransfers || []).slice(0, 5).map((tx: any) => (
                <div
                  key={tx.id}
                  className="p-3 rounded-2xl bg-slate-950 border border-slate-800/80 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-white flex items-center gap-1.5">
                      {tx.destinationType === "BANK" ? (
                        <Building className="w-3.5 h-3.5 text-sky-400" />
                      ) : (
                        <Coins className="w-3.5 h-3.5 text-amber-400" />
                      )}
                      <span className="truncate max-w-[180px]">{tx.destinationSummary}</span>
                    </div>
                    <div className="text-[10px] font-mono text-slate-400">
                      {new Date(tx.timestamp).toLocaleString()} • {tx.settlementRail || tx.rail}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="font-mono font-black text-emerald-400">
                      -${tx.amountUsd.toLocaleString()}
                    </div>
                    <span className="inline-block px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                      SETTLED
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
