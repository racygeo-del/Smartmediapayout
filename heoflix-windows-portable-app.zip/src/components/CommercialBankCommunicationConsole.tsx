import React, { useState, useEffect } from "react";
import { GLOBAL_BANKS_REGISTRY, BankInfo } from "../data/globalBanks";
import {
  Activity,
  Send,
  Building2,
  ShieldCheck,
  CheckCircle2,
  Radio,
  FileCode2,
  Clock,
  RefreshCw,
  Terminal,
  Lock,
  ArrowRight,
  Zap,
} from "lucide-react";

interface CommercialBankCommunicationConsoleProps {
  onTransferSuccess?: () => void;
}

export const CommercialBankCommunicationConsole: React.FC<CommercialBankCommunicationConsoleProps> = ({
  onTransferSuccess,
}) => {
  const [logs, setLogs] = useState<any[]>([]);
  const [activeChannels, setActiveChannels] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isDispatching, setIsDispatching] = useState<boolean>(false);
  const [dispatchResult, setDispatchResult] = useState<any>(null);

  // Form State
  const [selectedBankName, setSelectedBankName] = useState<string>("OPAY (Paycom Digital Services)");
  const [amount, setAmount] = useState<string>("5000");
  const [currency, setCurrency] = useState<string>("USD");
  const [recipientName, setRecipientName] = useState<string>("George Felix Egwu");
  const [recipientAccount, setRecipientAccount] = useState<string>("8134762646");
  const [memo, setMemo] = useState<string>("HEOFLIX Admin Platform Monetization Disbursement");

  // Raw Message Preview State
  const [viewingMessageType, setViewingMessageType] = useState<"ISO20022" | "SWIFT_MT103">("ISO20022");

  const fetchCommunications = async () => {
    try {
      const res = await fetch("/api/v1/commercial-banking/commercial-communications");
      const data = await res.json();
      if (data.success) {
        if (data.logs) setLogs(data.logs);
        if (data.activeChannels) setActiveChannels(data.activeChannels);
      }
    } catch {
      // offline fallback
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchCommunications();
    const interval = setInterval(fetchCommunications, 8000);
    return () => clearInterval(interval);
  }, []);

  const handleExecuteBankDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsDispatching(true);
    setDispatchResult(null);

    const bankObj = GLOBAL_BANKS_REGISTRY.find((b) => b.name === selectedBankName) || GLOBAL_BANKS_REGISTRY[0];

    try {
      const res = await fetch("/api/v1/commercial-banking/commercial-dispatch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: parseFloat(amount),
          currency,
          recipientName,
          recipientAccount,
          bankName: bankObj.name,
          swiftCode: bankObj.swiftCode,
          memo,
          clearingRail: `${bankObj.clearingRails[0] || "SWIFT GPI"} Real-Time Dispatch`,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setDispatchResult(data);
        fetchCommunications();
        if (onTransferSuccess) onTransferSuccess();
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsDispatching(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header */}
      <div className="rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 via-slate-900/90 to-indigo-950/40 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 font-mono text-[10px] font-extrabold uppercase border border-indigo-500/30 flex items-center gap-1.5">
                <Radio className="w-3 h-3 text-indigo-400 animate-pulse" />
                <span>COMMERCIAL GLOBAL BANKS BILATERAL GATEWAY</span>
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/20">
                mTLS 1.3 / ISO 20022 pacs.008 ACTIVE
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Automated Communications with Commercial Global Banks
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Every authorized transfer transaction automatically establishes bilateral communications with the target commercial bank,
              generating compliant ISO 20022 XML messages, SWIFT MT103 telegraphic transmissions, and unique SWIFT UETR tracking.
            </p>
          </div>

          <button
            onClick={fetchCommunications}
            className="self-start md:self-center flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 border border-slate-700 transition cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
            <span>Sync Bank Channels</span>
          </button>
        </div>

        {/* Live Active Commercial Bank Sockets */}
        <div className="mt-6 pt-5 border-t border-slate-800/80">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-2 font-semibold">
            Active Bilateral Bank Communication Channels (Direct TLS 1.3 Sockets)
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            {activeChannels.map((ch, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono mb-1">
                    <span className="text-slate-400">{ch.swift}</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                  </div>
                  <span className="text-[11px] font-extrabold text-white line-clamp-1">{ch.bank}</span>
                </div>
                <div className="mt-2 text-[10px] text-emerald-400 font-mono font-bold flex items-center justify-between">
                  <span>{ch.status}</span>
                  <span className="text-slate-400">{ch.pingMs}ms</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Execution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Dispatch Form */}
        <div className="lg:col-span-1 rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-xl space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
            <Send className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
              Authorize Bank Dispatch &amp; Handshake
            </h3>
          </div>

          <form onSubmit={handleExecuteBankDispatch} className="space-y-4 text-xs">
            <div>
              <label className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">
                Target Commercial Bank
              </label>
              <select
                value={selectedBankName}
                onChange={(e) => setSelectedBankName(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-medium focus:outline-none focus:border-indigo-500"
              >
                {GLOBAL_BANKS_REGISTRY.map((b) => (
                  <option key={b.code + b.swiftCode} value={b.name}>
                    {b.countryFlag} {b.name} ({b.swiftCode})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">
                  Amount
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono font-bold"
                  required
                />
              </div>

              <div>
                <label className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">
                  Currency
                </label>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono font-bold"
                >
                  <option value="USD">USD ($)</option>
                  <option value="NGN">NGN (₦)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="EUR">EUR (€)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">
                Beneficiary Name
              </label>
              <input
                type="text"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-medium"
                required
              />
            </div>

            <div>
              <label className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">
                Account Number / IBAN
              </label>
              <input
                type="text"
                value={recipientAccount}
                onChange={(e) => setRecipientAccount(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                required
              />
            </div>

            <div>
              <label className="text-slate-400 font-semibold uppercase tracking-wider block mb-1">
                Remittance Purpose
              </label>
              <input
                type="text"
                value={memo}
                onChange={(e) => setMemo(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
              />
            </div>

            <button
              type="submit"
              disabled={isDispatching}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-indigo-600 via-sky-600 to-emerald-600 hover:from-indigo-500 hover:to-emerald-500 text-white font-extrabold shadow-lg shadow-indigo-600/30 transition cursor-pointer flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4" />
              <span>{isDispatching ? "Establishing TLS 1.3 Bank Handshake..." : "Authorize & Dispatch to Bank"}</span>
            </button>
          </form>
        </div>

        {/* Live Dispatch Feed & Message Inspector */}
        <div className="lg:col-span-2 space-y-4">
          {dispatchResult && (
            <div className="rounded-3xl border border-emerald-500/40 bg-emerald-950/20 p-6 space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-400 font-black text-sm">
                  <CheckCircle2 className="w-5 h-5" />
                  <span>Commercial Bank Handshake Confirmed &amp; Dispatched!</span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold">
                  {dispatchResult.bankAcknowledgement?.status}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px] font-mono">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">SWIFT UETR</span>
                  <span className="text-emerald-400 font-bold truncate block select-all" title={dispatchResult.uetr}>
                    {dispatchResult.uetr}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Bank Ack Ref</span>
                  <span className="text-sky-300 font-bold truncate block select-all">
                    {dispatchResult.bankAcknowledgement?.reference}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Finality Latency</span>
                  <span className="text-emerald-300 font-bold">
                    {dispatchResult.bankAcknowledgement?.clearingTimeMs} ms
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">Settlement</span>
                  <span className="text-indigo-300 font-bold">INSTANT FINALITY</span>
                </div>
              </div>

              {/* Message Payload Tabs */}
              <div className="pt-2">
                <div className="flex items-center gap-2 mb-2">
                  <button
                    type="button"
                    onClick={() => setViewingMessageType("ISO20022")}
                    className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                      viewingMessageType === "ISO20022"
                        ? "bg-indigo-600 text-white"
                        : "bg-slate-800 text-slate-400 hover:text-white"
                    }`}
                  >
                    ISO 20022 (pacs.008 XML)
                  </button>
                  <button
                    type="button"
                    onClick={() => setViewingMessageType("SWIFT_MT103")}
                    className={`px-3 py-1 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                      viewingMessageType === "SWIFT_MT103"
                        ? "bg-sky-600 text-white"
                        : "bg-slate-800 text-slate-400 hover:text-white"
                    }`}
                  >
                    SWIFT MT103 (Telegraphic)
                  </button>
                </div>

                <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 max-h-48 overflow-y-auto overflow-x-auto select-all">
                  {viewingMessageType === "ISO20022"
                    ? dispatchResult.iso20022Message?.xmlPayload
                    : dispatchResult.swiftMessage?.payload}
                </pre>
              </div>
            </div>
          )}

          {/* Real-time Commercial Bank Communications Log Table */}
          <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-sky-400" />
                <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
                  Live Bank Communications Audit Trail ({logs.length})
                </h3>
              </div>
              <span className="text-[11px] font-mono text-emerald-400 font-bold">
                Bilateral TLS 1.3 Streaming
              </span>
            </div>

            <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/20">
                        {log.targetSwiftCode}
                      </span>
                      <strong className="text-white text-xs">{log.targetBank}</strong>
                      <span className="text-slate-400 text-[11px] font-mono">({log.country})</span>
                    </div>

                    <div className="text-slate-400 text-[11px] font-mono flex flex-wrap items-center gap-x-3 gap-y-0.5">
                      <span>UETR: <span className="text-slate-300">{log.uetr.slice(0, 18)}...</span></span>
                      <span>Disbursed: <strong className="text-emerald-400">${log.amount.toLocaleString()} {log.currency}</strong></span>
                      <span>Protocol: <span className="text-slate-300">{log.protocol}</span></span>
                    </div>
                  </div>

                  <div className="text-right sm:shrink-0 flex sm:flex-col items-center sm:items-end justify-between">
                    <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-[10px] font-bold">
                      {log.status}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono mt-1">
                      {log.latencyMs} ms &bull; {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
