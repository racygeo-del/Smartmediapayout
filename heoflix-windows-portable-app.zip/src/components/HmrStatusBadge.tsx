import React from "react";

interface HmrStatusBadgeProps {
  className?: string;
  showText?: boolean;
}

/**
 * HmrStatusBadge is hidden to keep the UI clean while HMR continues running in the background.
 */
export const HmrStatusBadge: React.FC<HmrStatusBadgeProps> = () => {
  return null;
};

