import React, { useState, useEffect } from "react";
import { VideoContent, WalletState } from "../types";
import { safeParseResponse } from "../utils/api";
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  Eye,
  Clock,
  Heart,
  MessageSquare,
  Share2,
  CheckCircle,
  AlertCircle,
  Sparkles,
  ShieldCheck,
  RefreshCw,
  ArrowUpRight,
  Send,
  Zap,
  Sliders,
  Award,
  Layers,
  HelpCircle,
} from "lucide-react";

interface VideoAnalyticsDashboardProps {
  videos: VideoContent[];
  wallet: WalletState;
  onRefreshData: () => void;
  onNavigateToTransfer: () => void;
  onOpenSecurityModal?: (actionName: string) => void;
  initialVideoId?: string;
}

export const VideoAnalyticsDashboard: React.FC<VideoAnalyticsDashboardProps> = ({
  videos,
  wallet,
  onRefreshData,
  onNavigateToTransfer,
  onOpenSecurityModal,
  initialVideoId,
}) => {
  // Selected video to analyze / track
  const [selectedVideoId, setSelectedVideoId] = useState<string>(
    initialVideoId || (videos.length > 0 ? videos[0].id : "")
  );

  const selectedVideo = videos.find((v) => v.id === selectedVideoId) || videos[0] || null;

  // Real-world metric editing inputs
  const [realViews, setRealViews] = useState<number>(0);
  const [realWatchHours, setRealWatchHours] = useState<number>(0);
  const [realLikes, setRealLikes] = useState<number>(0);
  const [realComments, setRealComments] = useState<number>(0);
  const [realShares, setRealShares] = useState<number>(0);
  const [realRpm, setRealRpm] = useState<number>(3.5);
  const [realSponsorPayout, setRealSponsorPayout] = useState<number>(500);

  // Status feedback
  const [isSaving, setIsSaving] = useState(false);
  const [isLoggingFunds, setIsLoggingFunds] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);

  // Sync inputs when selected video changes
  useEffect(() => {
    if (selectedVideo) {
      setRealViews(selectedVideo.views || 100000);
      setRealWatchHours(selectedVideo.watchTimeHours || Math.round((selectedVideo.views || 100000) * 0.025));
      setRealLikes(selectedVideo.likes || Math.round((selectedVideo.views || 100000) * 0.08));
      setRealComments(selectedVideo.comments || Math.round((selectedVideo.views || 100000) * 0.005));
      setRealShares(selectedVideo.shares || Math.round((selectedVideo.views || 100000) * 0.02));
      setRealRpm(selectedVideo.cpm || 3.5);
      setRealSponsorPayout(selectedVideo.verifiedAdPayout || 500);
    }
  }, [selectedVideoId, selectedVideo]);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Calculated Real-Time Metrics
  const calculatedAdRev = Number(((realViews / 1000) * realRpm).toFixed(2));
  const totalVerifiedEarnings = Number((calculatedAdRev + realSponsorPayout).toFixed(2));
  const engagementRatio = realViews > 0
    ? Number((((realLikes + realComments + realShares) / realViews) * 100).toFixed(2))
    : 0;
  const hoursPerThousand = realViews > 0
    ? Number(((realWatchHours / realViews) * 1000).toFixed(1))
    : 0;

  // Save updated metrics to server
  const handleSaveMetrics = async () => {
    if (!selectedVideo) return;
    setIsSaving(true);
    try {
      const res = await fetch(`/api/v1/social/videos/${selectedVideo.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          views: realViews,
          watchTimeHours: realWatchHours,
          likes: realLikes,
          comments: realComments,
          shares: realShares,
          cpm: realRpm,
          verifiedAdPayout: totalVerifiedEarnings,
        }),
      });

      const parsed = await safeParseResponse(res);
      if (parsed.ok && parsed.data?.success) {
        showToast("Video metrics successfully updated & saved!");
        onRefreshData();
      } else {
        showToast(parsed.error || "Failed to save metrics.", "error");
      }
    } catch (err: any) {
      showToast(err.message || "Network error updating metrics", "error");
    } finally {
      setIsSaving(false);
    }
  };

  // Log verified earnings into Dollar Wallet
  const handleLogEarningsToWallet = async () => {
    if (!selectedVideo) return;

    if (totalVerifiedEarnings <= 0) {
      showToast("Please enter a verified payout amount greater than $0.", "error");
      return;
    }

    setIsLoggingFunds(true);
    try {
      const res = await fetch(`/api/v1/social/videos/${selectedVideo.id}/log-earnings`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: totalVerifiedEarnings,
          sourcePlatform: selectedVideo.platform,
          description: `Verified AdSense/Sponsor Payout: ${selectedVideo.title}`,
        }),
      });

      const parsed = await safeParseResponse(res);
      if (parsed.ok && parsed.data?.success) {
        showToast(parsed.data.message || `Logged $${totalVerifiedEarnings.toFixed(2)} to Dollar Wallet!`);
        onRefreshData();
      } else {
        showToast(parsed.error || "Failed to log earnings to wallet.", "error");
      }
    } catch (err: any) {
      showToast(err.message || "Network error logging earnings", "error");
    } finally {
      setIsLoggingFunds(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300 pb-12">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          className={`fixed top-20 right-6 z-50 rounded-2xl px-5 py-3 shadow-2xl text-xs font-bold flex items-center gap-2 border animate-in slide-in-from-top ${
            toastMessage.type === "success"
              ? "bg-emerald-950/90 text-emerald-200 border-emerald-500/40"
              : "bg-rose-950/90 text-rose-200 border-rose-500/40"
          }`}
        >
          {toastMessage.type === "success" ? (
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-[#161f2e]/85 border border-slate-700/80 backdrop-blur-xl shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 via-sky-500 to-indigo-600 p-0.5 shadow-lg shadow-emerald-500/20">
            <div className="w-full h-full bg-[#131926] rounded-[14px] flex items-center justify-center text-emerald-400">
              <BarChart3 className="w-6 h-6" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black text-white tracking-tight">
                Real-World Video Analytics & Monetization Engine
              </h1>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-extrabold uppercase tracking-wider">
                Audited Yield
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Monitor real-world creator metrics, calculate verified platform RPM, and log earnings directly into your Dollar Wallet
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onNavigateToTransfer}
            className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-amber-500/20 transition cursor-pointer"
            title="Settle video ad revenue directly to linked Bitcoin wallet (34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW)"
          >
            <span className="font-mono font-bold text-sm">₿</span>
            <span>Settle to BTC (34m9vs...)</span>
          </button>

          <button
            onClick={onNavigateToTransfer}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-sky-600 hover:from-emerald-500 hover:to-sky-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/20 transition cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>Disburse to Bank ({wallet.connectedBankAccount.bankName})</span>
          </button>
        </div>
      </div>

      {/* Video Selector Dropdown Strip */}
      <div className="p-4 rounded-2xl bg-[#161f2e] border border-slate-700/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-indigo-400" />
          <span className="text-xs font-bold text-slate-300">Selected Video Target:</span>
        </div>

        <select
          value={selectedVideoId}
          onChange={(e) => setSelectedVideoId(e.target.value)}
          className="w-full sm:w-[480px] px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs font-semibold text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          {videos.map((vid) => (
            <option key={vid.id} value={vid.id}>
              {vid.title} ({vid.platform.toUpperCase()} — {vid.views.toLocaleString()} views)
            </option>
          ))}
        </select>
      </div>

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-2xl bg-[#161f2e]/90 border border-slate-700/80 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Verified Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 tracking-tight">
            ${totalVerifiedEarnings.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-emerald-400 font-bold">AdSense: ${calculatedAdRev.toFixed(0)}</span>
            <span>+ Sponsor: ${realSponsorPayout.toFixed(0)}</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#161f2e]/90 border border-slate-700/80 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Tracked Views</span>
            <Eye className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl font-black text-white tracking-tight">
            {realViews.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Across {selectedVideo?.platform.toUpperCase() || "YouTube"}
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#161f2e]/90 border border-slate-700/80 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Effective RPM / CPM</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 tracking-tight">
            ${realRpm.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Per 1,000 verified impressions
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#161f2e]/90 border border-slate-700/80 shadow-lg">
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span>Engagement Rate</span>
            <Heart className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-rose-400 tracking-tight">
            {engagementRatio}%
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Likes, comments & shares / views
          </div>
        </div>
      </div>

      {/* Main Split: Manual Metric Tracking Input & Revenue Conversion Engine */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Metric Editors */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-5 sm:p-6 rounded-3xl bg-[#161f2e]/90 border border-slate-700/80 shadow-xl space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-indigo-400" />
                <h2 className="text-base font-bold text-white">
                  Manual Real-World Metrics Controller
                </h2>
              </div>
              <span className="text-[11px] text-slate-400">
                Input verified platform data
              </span>
            </div>

            {/* Input Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Real-World Views</span>
                  <Eye className="w-3.5 h-3.5 text-sky-400" />
                </label>
                <input
                  type="number"
                  min="0"
                  step="1000"
                  value={realViews}
                  onChange={(e) => setRealViews(Math.max(0, Number(e.target.value)))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Watch Time (Hours)</span>
                  <Clock className="w-3.5 h-3.5 text-indigo-400" />
                </label>
                <input
                  type="number"
                  min="0"
                  step="100"
                  value={realWatchHours}
                  onChange={(e) => setRealWatchHours(Math.max(0, Number(e.target.value)))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Platform RPM ($ / 1,000 Views)</span>
                  <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                </label>
                <input
                  type="number"
                  min="0"
                  step="0.1"
                  value={realRpm}
                  onChange={(e) => setRealRpm(Math.max(0, Number(e.target.value)))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-amber-400 font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Verified Direct Sponsor Payout ($)</span>
                  <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                </label>
                <input
                  type="number"
                  min="0"
                  step="50"
                  value={realSponsorPayout}
                  onChange={(e) => setRealSponsorPayout(Math.max(0, Number(e.target.value)))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-emerald-400 font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Likes</span>
                  <Heart className="w-3.5 h-3.5 text-rose-400" />
                </label>
                <input
                  type="number"
                  min="0"
                  value={realLikes}
                  onChange={(e) => setRealLikes(Math.max(0, Number(e.target.value)))}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Comments & Shares</span>
                  <MessageSquare className="w-3.5 h-3.5 text-sky-400" />
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    min="0"
                    placeholder="Comments"
                    value={realComments}
                    onChange={(e) => setRealComments(Math.max(0, Number(e.target.value)))}
                    className="w-full px-2.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <input
                    type="number"
                    min="0"
                    placeholder="Shares"
                    value={realShares}
                    onChange={(e) => setRealShares(Math.max(0, Number(e.target.value)))}
                    className="w-full px-2.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-sm font-mono text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>

            {/* Save Buttons */}
            <div className="flex items-center justify-between pt-2">
              <span className="text-[11px] text-slate-400">
                Updates video stats across all software views
              </span>
              <button
                onClick={handleSaveMetrics}
                disabled={isSaving}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 transition disabled:opacity-50 cursor-pointer shadow-lg shadow-indigo-600/30"
              >
                {isSaving ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                <span>Save Tracked Metrics</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Monetization Logger & Payout to Wallet */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-b from-[#182335] to-[#131926] border border-emerald-500/40 shadow-2xl relative overflow-hidden space-y-5">
            <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">
                  Funds Generation & Conversion
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold">
                AUDITED RAIL
              </span>
            </div>

            {/* Revenue Breakdown */}
            <div className="space-y-2.5 bg-slate-900/80 p-4 rounded-2xl border border-slate-800 text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span>Calculated Ad Revenue ({realViews.toLocaleString()} views @ ${realRpm.toFixed(2)} RPM):</span>
                <span className="font-mono font-bold text-white">${calculatedAdRev.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>Verified Direct Brand Sponsorship:</span>
                <span className="font-mono font-bold text-emerald-400">+${realSponsorPayout.toFixed(2)}</span>
              </div>
              <div className="border-t border-slate-800 pt-2 flex justify-between items-center">
                <span className="font-bold text-white">Total Verified Creator Yield:</span>
                <span className="text-lg font-black text-emerald-400 font-mono">
                  ${totalVerifiedEarnings.toFixed(2)} USD
                </span>
              </div>
            </div>

            {/* Explanation box on real-world monetary systems */}
            <div className="p-3.5 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 text-xs text-indigo-200/90 space-y-1.5">
              <div className="font-bold flex items-center gap-1.5 text-indigo-300">
                <ShieldCheck className="w-4 h-4 text-indigo-400" />
                <span>International Reserve Settlement Architecture</span>
              </div>
              <p className="text-[11px] leading-relaxed text-indigo-200/80">
                In legitimate banking and Federal Reserve clearing rails, monetary value is validated against real economic productivity (verified viewer attention, platform ad share, and commercial sponsorship). By logging your tracking metrics, this software deposits verified funds into your Dollar Wallet with cryptographic audit blocks ready for banking push credit.
              </p>
            </div>

            {/* Primary Action Button */}
            <div className="space-y-2">
              <button
                onClick={handleLogEarningsToWallet}
                disabled={isLoggingFunds}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/20 transition hover:scale-[1.02] disabled:opacity-50 cursor-pointer"
              >
                {isLoggingFunds ? (
                  <RefreshCw className="w-5 h-5 animate-spin" />
                ) : (
                  <DollarSign className="w-5 h-5" />
                )}
                <span>
                  Log ${totalVerifiedEarnings.toFixed(2)} into Dollar Wallet
                </span>
              </button>

              <p className="text-[10px] text-center text-slate-400">
                Deposits directly to George Felix Egwu's verified Dollar Wallet ({wallet.connectedBankAccount.bankName}).
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
