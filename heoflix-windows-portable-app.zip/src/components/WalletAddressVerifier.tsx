import React, { useState } from "react";
import {
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  QrCode,
  Award,
  ExternalLink,
  Search,
  FileCheck2,
  Printer,
  Sparkles,
} from "lucide-react";

export const WalletAddressVerifier: React.FC = () => {
  const [inputAddress, setInputAddress] = useState<string>("34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW");
  const [selectedToken, setSelectedToken] = useState<string>("BTC");
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [verificationResult, setVerificationResult] = useState<any>(null);
  const [copiedCert, setCopiedCert] = useState<boolean>(false);

  const handleVerify = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputAddress.trim()) return;

    setIsVerifying(true);
    setVerificationResult(null);

    try {
      const res = await fetch("/api/v1/commercial-banking/verify-address", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          address: inputAddress.trim(),
          token: selectedToken,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setVerificationResult(data);
      }
    } catch {
      // fallback
    } finally {
      setIsVerifying(false);
    }
  };

  const copyCertificateHash = () => {
    if (!verificationResult?.certificate?.merkleDigest) return;
    navigator.clipboard.writeText(verificationResult.certificate.merkleDigest);
    setCopiedCert(true);
    setTimeout(() => setCopiedCert(false), 2500);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header Banner */}
      <div className="rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 via-slate-900/90 to-teal-950/40 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-400 font-mono text-[10px] font-extrabold uppercase border border-teal-500/30 flex items-center gap-1.5">
                <ShieldCheck className="w-3 h-3 text-teal-400" />
                <span>ON-CHAIN CRYPTOGRAPHIC ADDRESS VERIFIER</span>
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/20">
                100% RECOGNIZED ACROSS GLOBAL EXCHANGES
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Cryptographic Wallet Address Verifier &amp; Attestation
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Verify any cryptocurrency wallet address or bank account in real-time.
              Validates cryptographic checksums, Base58Check/Bech32/EIP-55 standards, and generates an official cryptographic certificate.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleVerify()}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-extrabold text-xs transition shadow-lg shadow-teal-600/30 cursor-pointer"
            >
              <FileCheck2 className="w-4 h-4" />
              <span>Verify Sovereign Address</span>
            </button>
          </div>
        </div>

        {/* Verification Input Form */}
        <form onSubmit={handleVerify} className="mt-6 pt-6 border-t border-slate-800/80 space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="sm:w-48">
              <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                Asset Protocol
              </label>
              <select
                value={selectedToken}
                onChange={(e) => setSelectedToken(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-bold focus:outline-none focus:border-teal-500"
              >
                <option value="BTC">Bitcoin (BTC)</option>
                <option value="ETH">Ethereum (ETH / ERC-20)</option>
                <option value="USDC">USD Coin (USDC)</option>
                <option value="USDT">Tether USD (USDT)</option>
                <option value="SOL">Solana (SOL)</option>
              </select>
            </div>

            <div className="flex-1">
              <label className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                Wallet Address / Account Number
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Enter BTC (1..., 3..., bc1...), ETH (0x...), SOL, or bank account..."
                  value={inputAddress}
                  onChange={(e) => setInputAddress(e.target.value)}
                  className="w-full pl-3.5 pr-28 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 font-bold"
                  required
                />
                <button
                  type="submit"
                  disabled={isVerifying}
                  className="absolute right-1.5 top-1.5 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-[11px] font-bold transition cursor-pointer"
                >
                  {isVerifying ? "Verifying..." : "Verify"}
                </button>
              </div>
            </div>
          </div>

          {/* Quick Preset Buttons */}
          <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono text-slate-400">
            <span className="text-slate-500">Preset Addresses:</span>
            <button
              type="button"
              onClick={() => {
                setInputAddress("34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW");
                setSelectedToken("BTC");
              }}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              HEOFLIX Primary BTC (34m9vs...)
            </button>
            <button
              type="button"
              onClick={() => {
                setInputAddress("0x742d35Cc6634C0532925a3b844Bc454e4438f44e");
                setSelectedToken("ETH");
              }}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              HEOFLIX Ethereum Multi-Sig (0x742d...)
            </button>
            <button
              type="button"
              onClick={() => {
                setInputAddress("7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU");
                setSelectedToken("SOL");
              }}
              className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            >
              Solana DeFi Treasury (7xKXtg...)
            </button>
          </div>
        </form>
      </div>

      {/* Verification Result Certificate */}
      {verificationResult && (
        <div className="rounded-3xl border border-teal-500/40 bg-slate-900/90 p-6 sm:p-8 shadow-2xl space-y-6 animate-in fade-in">
          {/* Certificate Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-teal-400 shrink-0">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <span className="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 font-mono text-[10px] font-bold uppercase border border-teal-500/30">
                  OFFICIAL ATTESTATION CERTIFICATE
                </span>
                <h3 className="text-lg font-black text-white mt-1">
                  Cryptographic Address Verification Certificate
                </h3>
                <p className="text-xs text-slate-400">
                  Certificate ID: <code className="text-teal-300">{verificationResult.certificate?.certificateId}</code>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={copyCertificateHash}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold border border-slate-700 transition cursor-pointer"
              >
                {copiedCert ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCert ? "Copied Digest!" : "Copy Merkle Digest"}</span>
              </button>
            </div>
          </div>

          {/* Certificate Detail Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 uppercase block font-semibold">
                Verified Address
              </span>
              <span className="text-teal-300 font-bold text-sm select-all break-all block">
                {verificationResult.address}
              </span>
              <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 mt-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>Format Integrity Check Passed</span>
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 uppercase block font-semibold">
                Detected Architecture &amp; Type
              </span>
              <span className="text-white font-bold text-sm block">
                {verificationResult.addressType}
              </span>
              <span className="text-[10px] text-slate-400 block">{verificationResult.formatDetails}</span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1 md:col-span-2">
              <span className="text-[10px] text-slate-400 uppercase block font-semibold">
                Cryptographic Merkle Root / SHA-256 Digest Proof
              </span>
              <span className="text-amber-400 font-bold text-xs select-all break-all block">
                {verificationResult.certificate?.merkleDigest}
              </span>
              <span className="text-[10px] text-slate-500 block">
                Attested by {verificationResult.certificate?.issuer} on {new Date(verificationResult.certificate?.verifiedAt).toUTCString()}
              </span>
            </div>
          </div>

          {/* Recognized Global Exchanges List */}
          <div className="pt-2">
            <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-2 font-semibold">
              Accepted Across Global Crypto Markets &amp; Exchanges
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              {verificationResult.certificate?.globalExchangeAcceptance?.map((ex: string) => (
                <div key={ex} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="text-slate-200 text-xs font-semibold">{ex}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
