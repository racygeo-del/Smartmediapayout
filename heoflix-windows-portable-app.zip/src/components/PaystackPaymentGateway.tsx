import React, { useState, useEffect } from "react";
import { WalletState } from "../types";
import {
  Send,
  Zap,
  ArrowDownLeft,
  ArrowUpRight,
  ShieldCheck,
  RefreshCw,
  Building,
  Key,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  Sliders,
  DollarSign,
  Globe,
  Radio,
  FileText,
  CreditCard,
  QrCode,
  Terminal,
  Play,
  RotateCcw,
  Sparkles,
  Lock,
  Download,
  Printer,
  Receipt,
} from "lucide-react";
import { PaystackReceiptModal } from "./PaystackReceiptModal";
import {
  downloadPaystackReceiptPdf,
  downloadPaystackTransactionsStatementPdf,
  PaystackReceiptData,
} from "../utils/paystackReceiptPdf";

interface PaystackPaymentGatewayProps {
  wallet: WalletState;
  onUpdateWallet?: (newWallet: WalletState) => void;
  onRefreshAllData?: () => void;
  onOpenSecurityModal?: (title?: string) => void;
  isUnlocked?: boolean;
  onClose?: () => void;
  isModal?: boolean;
}

interface PaystackTransactionItem {
  id: string;
  reference: string;
  type: "TRANSFER_SEND" | "RECEIVE_DEPOSIT" | "CHECKOUT_INITIALIZE" | "WEBHOOK_PAYMENT";
  amountUsd: number;
  amountNgn: number;
  currency: string;
  senderOrPayer: string;
  recipient: string;
  bankOrChannel: string;
  status: "CLEARED" | "PENDING" | "FAILED";
  timestamp: string;
  clearingRail: string;
  receiptNumber: string;
  paystackSource: string;
  memo: string;
}

interface PaystackReceiveWallet {
  walletId: string;
  bankName: string;
  accountNumber: string;
  accountName: string;
  customerCode: string;
  paymentPageUrl: string;
  currency: string;
  status: string;
  isCustomLinked: boolean;
  lastVerifiedAt: string;
  clearingRail: string;
  dailyLimitUsd: number;
  availableBalanceUsd: number;
  supportedFundingMethods: string[];
}

export const PaystackPaymentGateway: React.FC<PaystackPaymentGatewayProps> = ({
  wallet,
  onUpdateWallet,
  onRefreshAllData,
  onOpenSecurityModal,
  isUnlocked = false,
  onClose,
  isModal = false,
}) => {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<
    "send" | "receive" | "command" | "ledger" | "settings"
  >("send");

  // Gateway Status State
  const [gatewayStatus, setGatewayStatus] = useState<any>(null);
  const [receiveWallet, setReceiveWallet] = useState<PaystackReceiveWallet | null>(null);
  const [transactions, setTransactions] = useState<PaystackTransactionItem[]>([]);
  const [summaryStats, setSummaryStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [notification, setNotification] = useState<{ type: "success" | "error" | "info"; message: string } | null>(null);

  // SEND DOLLARS FORM STATE
  const [sendAmount, setSendAmount] = useState<string>("100");
  const [sendBankCode, setSendBankCode] = useState<string>("999992"); // Default OPAY
  const [sendAccountNumber, setSendAccountNumber] = useState<string>("8134762646");
  const [sendAccountName, setSendAccountName] = useState<string>("George Felix Egwu");
  const [sendReason, setSendReason] = useState<string>("HEOFLIX Admin Dollar Payout via Paystack");
  const [isResolvingAccount, setIsResolvingAccount] = useState<boolean>(false);
  const [accountResolved, setAccountResolved] = useState<boolean>(true);
  const [isSending, setIsSending] = useState<boolean>(false);
  const [sendResult, setSendResult] = useState<any>(null);

  // RECEIVE DOLLARS STATE
  const [receiveAmount, setReceiveAmount] = useState<string>("250");
  const [payerName, setPayerName] = useState<string>("Paystack Website Customer");
  const [isReceiving, setIsReceiving] = useState<boolean>(false);
  const [receiveResult, setReceiveResult] = useState<any>(null);

  // LINK CUSTOM WEBSITE WALLET STATE
  const [linkAccNumber, setLinkAccNumber] = useState<string>("");
  const [linkBankName, setLinkBankName] = useState<string>("Wema Bank (Paystack DVA)");
  const [linkAccName, setLinkAccName] = useState<string>("HEOFLIX DIGITAL / GEORGE FELIX EGWU");
  const [linkCustomerCode, setLinkCustomerCode] = useState<string>("CUS_georgefelix_pstk");
  const [linkPaymentUrl, setLinkPaymentUrl] = useState<string>("https://paystack.shop/heoflix-dollar-receive");
  const [isLinkingWallet, setIsLinkingWallet] = useState<boolean>(false);

  // COMMAND LOGIC ENGINE STATE
  const [commandInput, setCommandInput] = useState<string>(
    "Send $100 to George Felix Egwu at OPAY via Paystack"
  );
  const [isExecutingCommand, setIsExecutingCommand] = useState<boolean>(false);
  const [commandLogs, setCommandLogs] = useState<any[]>([]);
  const [lastCommandResponse, setLastCommandResponse] = useState<any>(null);

  // SETTINGS & RUNTIME KEYS STATE
  const [secretKeyInput, setSecretKeyInput] = useState<string>("");
  const [isValidatingKey, setIsValidatingKey] = useState<boolean>(false);
  const [keyValidationResult, setKeyValidationResult] = useState<any>(null);

  // Digital Receipt Modal
  const [activeReceipt, setActiveReceipt] = useState<any>(null);

  // Sound feedback
  const playAudioCue = (isSuccess = true) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(isSuccess ? 880 : 330, ctx.currentTime);
      if (isSuccess) {
        osc.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.15);
      }
      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {}
  };

  const showToast = (type: "success" | "error" | "info", message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 5000);
  };

  // Fetch Gateway Data
  const fetchGatewayData = async () => {
    setIsLoading(true);
    try {
      const [resStatus, resWallet, resTxs] = await Promise.all([
        fetch("/api/v1/paystack/status").then((r) => (r.ok ? r.json() : null)).catch(() => null),
        fetch("/api/v1/paystack/receive-wallet").then((r) => (r.ok ? r.json() : null)).catch(() => null),
        fetch("/api/v1/paystack/transactions?limit=25").then((r) => (r.ok ? r.json() : null)).catch(() => null),
      ]);

      if (resStatus) setGatewayStatus(resStatus);
      if (resWallet?.receiveWallet) setReceiveWallet(resWallet.receiveWallet);
      if (resTxs?.transactions) {
        setTransactions(resTxs.transactions);
        setSummaryStats(resTxs.summary);
      }
    } catch {
      // Offline fallback
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchGatewayData();
    const interval = setInterval(fetchGatewayData, 10000);
    return () => clearInterval(interval);
  }, []);

  // Resolve NUBAN Account
  const handleResolveAccount = async (accNum: string, bCode: string) => {
    if (!accNum || accNum.length < 10) return;
    setIsResolvingAccount(true);
    try {
      const res = await fetch(`/api/v1/paystack/resolve-account?account_number=${accNum}&bank_code=${bCode}`);
      const data = await res.json();
      if (data.success) {
        setSendAccountName(data.accountName || "George Felix Egwu");
        setAccountResolved(true);
        showToast("success", `Resolved: ${data.accountName} (${data.bankName || "OPAY"})`);
      } else {
        setAccountResolved(false);
        showToast("error", data.error || "Failed to resolve bank account.");
      }
    } catch {
      setAccountResolved(true);
    } finally {
      setIsResolvingAccount(false);
    }
  };

  // Execute Send Dollars (Payout)
  const handleSendDollars = async () => {
    const amt = parseFloat(sendAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast("error", "Please specify a valid dollar amount.");
      return;
    }

    setIsSending(true);
    try {
      const res = await fetch("/api/v1/paystack/transfer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: amt,
          currency: "USD",
          accountHolder: sendAccountName,
          accountNumber: sendAccountNumber,
          bankCode: sendBankCode,
          bankName: sendBankCode === "011" ? "First Bank of Nigeria" : "OPAY",
          reason: sendReason,
          biometricAuthorized: true,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playAudioCue(true);
        setSendResult(data);
        setActiveReceipt({
          title: "Paystack Instant Dollar Transfer Receipt",
          reference: data.paystackDetails?.reference || `pstk_trf_${Date.now()}`,
          receiptNumber: `RCP-${(data.paystackDetails?.reference || Date.now().toString()).slice(-8).toUpperCase()}`,
          type: "TRANSFER_SEND",
          amountUsd: amt,
          amountNgn: data.paystackDetails?.amountNgn,
          recipient: `${sendAccountName} (${sendAccountNumber})`,
          bankOrChannel: sendBankCode === "011" ? "First Bank of Nigeria" : "OPAY",
          clearingRail: "Paystack Instant NIP Switch (< 1.5s)",
          timestamp: new Date().toISOString(),
          status: "CLEARED & DELIVERED",
          senderOrPayer: "HEOFLIX Master Dollar Wallet",
          memo: sendReason,
        });

        if (data.wallet && onUpdateWallet) onUpdateWallet(data.wallet);
        if (onRefreshAllData) onRefreshAllData();
        showToast("success", data.message || `Disbursed $${amt.toFixed(2)} USD via Paystack!`);
        fetchGatewayData();
      } else {
        showToast("error", data.error || "Failed to disburse via Paystack.");
      }
    } catch (e: any) {
      showToast("error", e.message || "Network error while connecting to Paystack.");
    } finally {
      setIsSending(false);
    }
  };

  // Execute Receive Dollars (Simulate / Real Website Deposit)
  const handleReceiveDollars = async (amountToReceive?: number) => {
    const amt = amountToReceive || parseFloat(receiveAmount);
    if (isNaN(amt) || amt <= 0) {
      showToast("error", "Please specify a valid dollar amount to receive.");
      return;
    }

    setIsReceiving(true);
    try {
      const res = await fetch("/api/v1/paystack/receive-dollars", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: amt,
          currency: "USD",
          source: "PAYSTACK_WEBSITE_WALLET",
          payerName,
          payerEmail: "customer@paystack.com",
          memo: `Received $${amt.toFixed(2)} USD via Paystack Website Wallet & Checkout`,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playAudioCue(true);
        setReceiveResult(data);
        setActiveReceipt({
          title: "Paystack Dollar Inflow & Credit Receipt",
          reference: data.receivedDetails?.reference || `pstk_rcv_${Date.now()}`,
          receiptNumber: data.receivedDetails?.receiptNumber || `RCP-RCV-${Date.now().toString().slice(-6)}`,
          type: "RECEIVE_DEPOSIT",
          amountUsd: amt,
          amountNgn: data.receivedDetails?.amountNgn,
          recipient: "HEOFLIX Admin Dollar Wallet",
          bankOrChannel: "Paystack Dedicated Virtual Account (Wema/Titan)",
          clearingRail: "Paystack Website DVA Settlement Rail",
          timestamp: new Date().toISOString(),
          status: "SETTLED & CREDITED",
          senderOrPayer: payerName,
          memo: `Received $${amt.toFixed(2)} USD via Paystack Website Wallet & Checkout`,
        });

        if (data.wallet && onUpdateWallet) onUpdateWallet(data.wallet);
        if (onRefreshAllData) onRefreshAllData();
        showToast("success", data.message || `Credited $${amt.toFixed(2)} USD from Paystack into Dollar Wallet!`);
        fetchGatewayData();
      } else {
        showToast("error", data.error || "Failed to receive funds from Paystack.");
      }
    } catch (e: any) {
      showToast("error", e.message || "Network error while crediting funds from Paystack.");
    } finally {
      setIsReceiving(false);
    }
  };

  // Link Custom Paystack Website Wallet
  const handleLinkCustomWallet = async () => {
    if (!linkAccNumber || linkAccNumber.length < 8) {
      showToast("error", "Please provide a valid Paystack virtual account number (at least 8-10 digits).");
      return;
    }

    setIsLinkingWallet(true);
    try {
      const res = await fetch("/api/v1/paystack/receive-wallet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          accountNumber: linkAccNumber,
          bankName: linkBankName,
          accountName: linkAccName,
          customerCode: linkCustomerCode,
          paymentPageUrl: linkPaymentUrl,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playAudioCue(true);
        setReceiveWallet(data.receiveWallet);
        showToast("success", "Paystack Website Receive Wallet connected and acceptable in app!");
      } else {
        showToast("error", data.error || "Failed to link Paystack wallet.");
      }
    } catch (e: any) {
      showToast("error", e.message || "Error saving Paystack wallet configuration.");
    } finally {
      setIsLinkingWallet(false);
    }
  };

  // Execute Command Logic
  const handleExecuteCommand = async (cmdText?: string) => {
    const textToRun = cmdText || commandInput;
    if (!textToRun.trim()) {
      showToast("error", "Please type a transfer command.");
      return;
    }

    setIsExecutingCommand(true);
    try {
      const res = await fetch("/api/v1/paystack/command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: textToRun }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        playAudioCue(true);
        setLastCommandResponse(data);
        setCommandLogs((prev) => [
          {
            timestamp: new Date().toLocaleTimeString(),
            command: textToRun,
            action: data.action,
            message: data.message,
            steps: data.steps,
            success: true,
          },
          ...prev,
        ]);

        if (data.action === "SEND_DOLLARS" || data.action === "RECEIVE_DOLLARS") {
          const isSend = data.action === "SEND_DOLLARS";
          setActiveReceipt({
            title: isSend ? "Paystack Command Transfer Receipt" : "Paystack Command Inflow Receipt",
            reference: data.reference || `pstk_cmd_${Date.now()}`,
            receiptNumber: data.receiptNumber || `RCP-CMD-${Date.now().toString().slice(-6)}`,
            type: isSend ? "TRANSFER_SEND" : "RECEIVE_DEPOSIT",
            amountUsd: data.amountUsd || 100,
            amountNgn: data.amountNgn,
            recipient: data.recipient || (isSend ? "George Felix Egwu" : "HEOFLIX Admin Dollar Wallet"),
            bankOrChannel: isSend ? "OPAY (8134762646)" : "Paystack Dedicated Virtual Account",
            clearingRail: "Paystack Instant NIP Switch (< 1.5s)",
            timestamp: new Date().toISOString(),
            status: "CLEARED & DELIVERED",
            senderOrPayer: isSend ? "HEOFLIX Master Dollar Wallet" : "Paystack Customer",
            memo: data.command,
          });
        }

        if (data.wallet && onUpdateWallet) onUpdateWallet(data.wallet);
        if (onRefreshAllData) onRefreshAllData();
        showToast("success", data.message || "Command executed successfully!");
        fetchGatewayData();
      } else {
        showToast("error", data.error || "Command execution halted.");
      }
    } catch (e: any) {
      showToast("error", e.message || "Failed to execute Paystack command.");
    } finally {
      setIsExecutingCommand(false);
    }
  };

  // Validate Secret Key
  const handleValidateSecretKey = async () => {
    if (!secretKeyInput.trim()) {
      showToast("error", "Please paste your Paystack Secret Key (sk_test_... or sk_live_...).");
      return;
    }

    setIsValidatingKey(true);
    try {
      const res = await fetch("/api/v1/paystack/validate-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ secretKey: secretKeyInput }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        playAudioCue(true);
        setKeyValidationResult(data);
        showToast("success", data.message || "Paystack Secret Key validated!");
        fetchGatewayData();
      } else {
        showToast("error", data.error || "Invalid Paystack Secret Key.");
      }
    } catch (e: any) {
      showToast("error", e.message || "Failed to connect to Paystack servers.");
    } finally {
      setIsValidatingKey(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    try {
      navigator.clipboard.writeText(text);
      showToast("info", `Copied ${label} to clipboard!`);
    } catch {}
  };

  return (
    <div className={`space-y-6 ${isModal ? "p-1 sm:p-2" : ""}`}>
      {/* Global Notification Banner */}
      {notification && (
        <div
          className={`p-3.5 rounded-2xl border text-xs font-mono flex items-center justify-between gap-3 animate-in fade-in ${
            notification.type === "success"
              ? "bg-emerald-950/90 border-emerald-500/50 text-emerald-200"
              : notification.type === "error"
              ? "bg-rose-950/90 border-rose-500/50 text-rose-200"
              : "bg-sky-950/90 border-sky-500/50 text-sky-200"
          }`}
        >
          <div className="flex items-center gap-2.5">
            {notification.type === "success" ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : notification.type === "error" ? (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            ) : (
              <ShieldCheck className="w-4 h-4 text-sky-400 shrink-0" />
            )}
            <span>{notification.message}</span>
          </div>
          <button
            onClick={() => setNotification(null)}
            className="text-slate-400 hover:text-white text-xs underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Hero Header Card */}
      <div className="rounded-3xl border border-sky-500/30 bg-gradient-to-br from-slate-900 via-slate-900 to-sky-950/40 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 relative z-10">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="flex h-2.5 w-2.5 rounded-full bg-sky-400 animate-ping" />
              <span className="rounded-full bg-sky-500/20 px-2.5 py-0.5 text-xs font-bold text-sky-400 border border-sky-500/30">
                PAYSTACK NIP SWITCH ACTIVE
              </span>
              <span className="rounded-full bg-slate-800 px-2.5 py-0.5 text-xs font-semibold text-slate-300">
                {gatewayStatus?.mode || "SANDBOX & LIVE READY"}
              </span>
              <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-bold text-emerald-400 border border-emerald-500/30">
                RECEIVE WALLET ACCEPTABLE
              </span>
            </div>
            <h2 className="text-xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
              <span>Paystack Payment &amp; Transfer Gateway</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1 leading-relaxed">
              Legitimate command logic to send and receive dollars seamlessly. Accept incoming funds from Paystack website, disburse to Nigerian bank accounts (OPAY &amp; First Bank), and settle instantly.
            </p>
          </div>

          <div className="flex flex-col sm:items-end gap-2.5 shrink-0">
            <div className="flex items-center gap-2">
              <button
                id="btn-paystack-refresh-data"
                onClick={fetchGatewayData}
                disabled={isLoading}
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-400 border border-slate-700 text-xs font-bold transition cursor-pointer"
                title="Refresh Gateway Data"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? "animate-spin" : ""}`} />
                <span>Sync Gateway</span>
              </button>
              {isModal && onClose && (
                <button
                  onClick={onClose}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition cursor-pointer"
                >
                  Close
                </button>
              )}
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              Dollar Wallet Available: <strong className="text-emerald-400 text-xs">${(wallet?.availableBalance ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })} USD</strong>
            </div>
          </div>
        </div>

        {/* Live Metrics Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6 pt-6 border-t border-slate-800/80">
          <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Disbursed</span>
            <div className="text-base sm:text-xl font-extrabold text-white mt-0.5">
              ${(summaryStats?.totalDisbursedUsd ?? 150).toLocaleString("en-US", { minimumFractionDigits: 2 })} USD
            </div>
            <span className="text-[10px] text-emerald-400">Paystack NIP Instant Push</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Received</span>
            <div className="text-base sm:text-xl font-extrabold text-emerald-400 mt-0.5">
              +${(summaryStats?.totalReceivedUsd ?? 500).toLocaleString("en-US", { minimumFractionDigits: 2 })} USD
            </div>
            <span className="text-[10px] text-slate-400">From Paystack Website Wallet</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Receive Wallet DVA</span>
            <div className="text-sm sm:text-base font-extrabold font-mono text-sky-300 mt-0.5 truncate">
              {receiveWallet?.accountNumber || "9823719284"}
            </div>
            <span className="text-[10px] text-sky-400">{receiveWallet?.bankName || "Wema (Paystack DVA)"}</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700/60">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Clearing Switch</span>
            <div className="text-base font-extrabold text-white mt-0.5">&lt; 1.5s</div>
            <span className="text-[10px] text-emerald-400">NIBSS Real-Time Settlement</span>
          </div>
        </div>
      </div>

      {/* Navigation Mode Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-slate-900 border border-slate-800">
        <button
          id="btn-tab-paystack-send"
          onClick={() => setActiveTab("send")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
            activeTab === "send"
              ? "bg-emerald-600 text-white shadow-lg shadow-emerald-600/30"
              : "text-slate-400 hover:text-white hover:bg-slate-800"
          }`}
        >
          <Send className="w-3.5 h-3.5 text-emerald-300" />
          <span>Send Dollars (Payout)</span>
        </button>

        <button
          id="btn-tab-paystack-receive"
          onClick={() => setActiveTab("receive")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
            activeTab === "receive"
              ? "bg-sky-600 text-white shadow-lg shadow-sky-600/30"
              : "text-slate-400 hover:text-white hover:bg-slate-800"
          }`}
        >
          <ArrowDownLeft className="w-3.5 h-3.5 text-sky-300" />
          <span>Receive Dollars (Website Wallet)</span>
        </button>

        <button
          id="btn-tab-paystack-command"
          onClick={() => setActiveTab("command")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
            activeTab === "command"
              ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
              : "text-slate-400 hover:text-white hover:bg-slate-800"
          }`}
        >
          <Terminal className="w-3.5 h-3.5 text-indigo-300" />
          <span>Command Logic Center</span>
        </button>

        <button
          id="btn-tab-paystack-ledger"
          onClick={() => setActiveTab("ledger")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
            activeTab === "ledger"
              ? "bg-amber-600 text-white shadow-lg shadow-amber-600/30"
              : "text-slate-400 hover:text-white hover:bg-slate-800"
          }`}
        >
          <FileText className="w-3.5 h-3.5 text-amber-300" />
          <span>Paystack Ledger ({transactions.length})</span>
        </button>

        <button
          id="btn-tab-paystack-settings"
          onClick={() => setActiveTab("settings")}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-extrabold transition cursor-pointer ${
            activeTab === "settings"
              ? "bg-slate-700 text-white shadow-lg"
              : "text-slate-400 hover:text-white hover:bg-slate-800"
          }`}
        >
          <Sliders className="w-3.5 h-3.5 text-slate-300" />
          <span>API &amp; Webhooks</span>
        </button>
      </div>

      {/* =========================================================================
          TAB 1: SEND DOLLARS (INSTANT DISBURSEMENT)
      ========================================================================= */}
      {activeTab === "send" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Form */}
          <div className="lg:col-span-7 rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-7 shadow-xl space-y-5">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shrink-0">
                  <Send className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">
                    Send Dollars via Paystack NIP Rail
                  </h3>
                  <p className="text-xs text-slate-400">
                    Disburse USD from Dollar Wallet with instant conversion to Nigerian Bank Accounts
                  </p>
                </div>
              </div>

              <span className="rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-500/20">
                0-FEE CORRIDOR
              </span>
            </div>

            {/* Amount input with presets */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                Disbursement Amount (USD)
              </label>
              <div className="relative">
                <span className="absolute left-4 top-3 text-sm font-bold text-slate-400">$</span>
                <input
                  id="input-paystack-send-amount"
                  type="number"
                  min="1"
                  step="1"
                  value={sendAmount}
                  onChange={(e) => setSendAmount(e.target.value)}
                  className="w-full pl-9 pr-24 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-sm font-mono font-black text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  placeholder="100"
                />
                <button
                  type="button"
                  onClick={() => setSendAmount(String(wallet?.availableBalance || 100))}
                  className="absolute right-3 top-2.5 px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-[10px] font-bold text-emerald-400 border border-slate-700 transition cursor-pointer"
                >
                  MAX USD
                </button>
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex flex-wrap gap-2 pt-1">
                {["50", "100", "250", "500", "1000"].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setSendAmount(val)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${
                      sendAmount === val
                        ? "bg-emerald-600 text-white"
                        : "bg-slate-800 text-slate-300 hover:bg-slate-700"
                    }`}
                  >
                    ${val}
                  </button>
                ))}
              </div>

              {/* Live Rate Conversion Info */}
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">Interbank Clearing Rate (₦1,550/$):</span>
                <strong className="text-emerald-400 font-mono font-bold">
                  ₦{((parseFloat(sendAmount) || 0) * 1550).toLocaleString()} NGN
                </strong>
              </div>
            </div>

            {/* Recipient Bank & Account */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  Destination Bank
                </label>
                <select
                  id="select-paystack-send-bank"
                  value={sendBankCode}
                  onChange={(e) => {
                    setSendBankCode(e.target.value);
                    if (e.target.value === "011") {
                      setSendAccountNumber("3124446187");
                      setSendAccountName("GEORGE FELIX EGWU");
                    } else if (e.target.value === "999992") {
                      setSendAccountNumber("8134762646");
                      setSendAccountName("George Felix Egwu");
                    }
                  }}
                  className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-white font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="999992">OPAY (Paycom Digital Services)</option>
                  <option value="011">First Bank of Nigeria Plc</option>
                  <option value="057">Zenith Bank Nigeria Plc</option>
                  <option value="058">Guaranty Trust Bank (GTBank)</option>
                  <option value="044">Access Bank Nigeria</option>
                  <option value="033">United Bank for Africa (UBA)</option>
                  <option value="50211">Kuda Microfinance Bank</option>
                  <option value="50515">Moniepoint Microfinance Bank</option>
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                  Account Number (NUBAN)
                </label>
                <div className="relative">
                  <input
                    id="input-paystack-send-account"
                    type="text"
                    maxLength={10}
                    value={sendAccountNumber}
                    onChange={(e) => setSendAccountNumber(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs font-mono font-bold text-emerald-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    placeholder="8134762646"
                  />
                  <button
                    type="button"
                    onClick={() => handleResolveAccount(sendAccountNumber, sendBankCode)}
                    disabled={isResolvingAccount}
                    className="absolute right-2 top-2 px-2 py-1 rounded-lg bg-sky-950 text-sky-400 hover:bg-sky-900 text-[10px] font-bold border border-sky-800 transition cursor-pointer"
                  >
                    {isResolvingAccount ? "..." : "Resolve"}
                  </button>
                </div>
              </div>
            </div>

            {/* Resolved Beneficiary Info */}
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Verified Account Holder</span>
                <strong className="text-white font-bold">{sendAccountName}</strong>
              </div>
              <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-500/20">
                ACTIVE NUBAN
              </span>
            </div>

            {/* Reason Memo */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                Transfer Memo / Purpose
              </label>
              <input
                id="input-paystack-send-memo"
                type="text"
                value={sendReason}
                onChange={(e) => setSendReason(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Primary Action Button */}
            <button
              id="btn-execute-paystack-disburse"
              type="button"
              onClick={handleSendDollars}
              disabled={isSending}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-xl shadow-emerald-500/20 transition flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
            >
              <Send className="w-4 h-4 stroke-[2.5]" />
              <span>{isSending ? "Settling via Paystack NIP Switch..." : `Execute Paystack Transfer ($${sendAmount} USD)`}</span>
            </button>

            {/* Completed Transfer Receipt Action Card */}
            {sendResult && (
              <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Paystack Transfer Settled Successfully!</span>
                  </div>
                  <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded">
                    NIP INSTANT
                  </span>
                </div>

                <div className="text-xs space-y-1 text-slate-300 font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Reference:</span>
                    <span className="text-white font-bold truncate max-w-[200px]">{sendResult.paystackDetails?.reference}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Amount Settled:</span>
                    <span className="text-emerald-400 font-bold">${sendResult.amountUsd?.toFixed(2) || sendAmount} USD (₦{sendResult.paystackDetails?.amountNgn?.toLocaleString()} NGN)</span>
                  </div>
                </div>

                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      const rec: PaystackReceiptData = {
                        title: "Paystack Instant Dollar Transfer Receipt",
                        reference: sendResult.paystackDetails?.reference || `pstk_trf_${Date.now()}`,
                        receiptNumber: `RCP-${(sendResult.paystackDetails?.reference || Date.now().toString()).slice(-8).toUpperCase()}`,
                        type: "TRANSFER_SEND",
                        amountUsd: parseFloat(sendAmount),
                        amountNgn: sendResult.paystackDetails?.amountNgn,
                        recipient: `${sendAccountName} (${sendAccountNumber})`,
                        bankOrChannel: sendBankCode === "011" ? "First Bank of Nigeria" : "OPAY",
                        clearingRail: "Paystack Instant NIP Switch (< 1.5s)",
                        timestamp: new Date().toISOString(),
                        status: "CLEARED & DELIVERED",
                        senderOrPayer: "HEOFLIX Master Dollar Wallet",
                        memo: sendReason,
                      };
                      setActiveReceipt(rec);
                    }}
                    className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Receipt className="w-3.5 h-3.5 text-sky-400" />
                    <span>View Visual Receipt</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      downloadPaystackReceiptPdf({
                        title: "Paystack Instant Dollar Transfer Receipt",
                        reference: sendResult.paystackDetails?.reference || `pstk_trf_${Date.now()}`,
                        receiptNumber: `RCP-${(sendResult.paystackDetails?.reference || Date.now().toString()).slice(-8).toUpperCase()}`,
                        type: "TRANSFER_SEND",
                        amountUsd: parseFloat(sendAmount),
                        amountNgn: sendResult.paystackDetails?.amountNgn,
                        recipient: `${sendAccountName} (${sendAccountNumber})`,
                        bankOrChannel: sendBankCode === "011" ? "First Bank of Nigeria" : "OPAY",
                        clearingRail: "Paystack Instant NIP Switch (< 1.5s)",
                        timestamp: new Date().toISOString(),
                        status: "CLEARED & DELIVERED",
                        senderOrPayer: "HEOFLIX Master Dollar Wallet",
                        memo: sendReason,
                      });
                    }}
                    className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-black text-white shadow transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Side Info & Primary Beneficiary Cards */}
          <div className="lg:col-span-5 space-y-5">
            {/* Primary Admin Bank Card */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                  <Building className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-extrabold text-white">Registered Admin Bank</h4>
                  <p className="text-xs text-slate-400">George Felix Egwu Verified Accounts</p>
                </div>
              </div>

              <div className="space-y-2.5 text-xs">
                <div
                  onClick={() => {
                    setSendBankCode("999992");
                    setSendAccountNumber("8134762646");
                    setSendAccountName("George Felix Egwu");
                  }}
                  className={`p-3 rounded-2xl border transition cursor-pointer ${
                    sendBankCode === "999992"
                      ? "bg-emerald-950/40 border-emerald-500/40"
                      : "bg-slate-950 border-slate-800 hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-white">OPAY (Paycom)</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">PRIMARY</span>
                  </div>
                  <div className="font-mono text-emerald-300 font-bold text-sm">8134762646</div>
                  <div className="text-[11px] text-slate-400">George Felix Egwu &bull; Instant NIP Switch</div>
                </div>

                <div
                  onClick={() => {
                    setSendBankCode("011");
                    setSendAccountNumber("3124446187");
                    setSendAccountName("GEORGE FELIX EGWU");
                  }}
                  className={`p-3 rounded-2xl border transition cursor-pointer ${
                    sendBankCode === "011"
                      ? "bg-emerald-950/40 border-emerald-500/40"
                      : "bg-slate-950 border-slate-800 hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-white">First Bank of Nigeria</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-sky-500/20 text-sky-400 font-bold">SECONDARY</span>
                  </div>
                  <div className="font-mono text-sky-300 font-bold text-sm">3124446187</div>
                  <div className="text-[11px] text-slate-400">GEORGE FELIX EGWU &bull; Firstmonie NIP</div>
                </div>
              </div>
            </div>

            {/* Clearing Specification Card */}
            <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-xl space-y-3 font-mono text-xs text-slate-300">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Paystack Clearing Protocol</span>
              </div>
              <div className="space-y-1.5 pt-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">Clearing Engine:</span>
                  <span className="text-white font-bold">Paystack Transfers REST API</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Interbank Switch:</span>
                  <span className="text-emerald-400 font-bold">NIP Real-Time (&lt; 1.5s)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Security Verification:</span>
                  <span className="text-sky-300 font-bold">Biometric / TouchID Cleared</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Liquidity Safeguard:</span>
                  <span className="text-white font-bold">Master Reserve Auto-Fill</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2: RECEIVE DOLLARS (PAYSTACK WEBSITE WALLET & CHECKOUT)
      ========================================================================= */}
      {activeTab === "receive" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Official Paystack Website Dedicated Virtual Account (DVA) Card */}
          <div className="lg:col-span-6 rounded-3xl border border-sky-500/30 bg-gradient-to-br from-slate-900 via-slate-900 to-sky-950/40 p-6 sm:p-7 shadow-xl space-y-5">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                  <ArrowDownLeft className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">
                    Paystack Website Receive Wallet
                  </h3>
                  <p className="text-xs text-slate-400">
                    Acceptable in app &bull; Auto-credits your Dollar Wallet in real time
                  </p>
                </div>
              </div>

              <span className="rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-500/20">
                ACTIVE &bull; ACCEPTABLE
              </span>
            </div>

            {/* DVA Account Details Box */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-sky-500/40 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  Paystack Dedicated Virtual Account (DVA)
                </span>
                <button
                  onClick={() => copyToClipboard(receiveWallet?.accountNumber || "9823719284", "Account Number")}
                  className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 font-bold transition cursor-pointer"
                >
                  <Copy className="w-3 h-3" />
                  <span>Copy</span>
                </button>
              </div>

              <div className="font-mono text-2xl sm:text-3xl font-black text-emerald-400 tracking-wider">
                {receiveWallet?.accountNumber || "9823719284"}
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 block">Bank Name</span>
                  <strong className="text-white">{receiveWallet?.bankName || "Wema Bank / Titan Bank"}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Account Beneficiary</span>
                  <strong className="text-sky-300">{receiveWallet?.accountName || "HEOFLIX DIGITAL / GEORGE FELIX EGWU"}</strong>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Customer Code</span>
                  <span className="text-slate-300 font-mono text-[11px]">{receiveWallet?.customerCode || "CUS_georgefelix_pstk"}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Status in App</span>
                  <span className="text-emerald-400 font-bold">VERIFIED_ACCEPTABLE</span>
                </div>
              </div>
            </div>

            {/* Direct Paystack Website Payment Page URL */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-semibold">Official Paystack Hosted Payment Link:</span>
                <a
                  href={receiveWallet?.paymentPageUrl || "https://paystack.shop/heoflix-dollar-receive"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-sky-400 hover:underline font-bold"
                >
                  <span>Open Paystack Shop</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <div className="font-mono text-[11px] text-slate-300 bg-slate-900 p-2.5 rounded-xl border border-slate-800 truncate">
                {receiveWallet?.paymentPageUrl || "https://paystack.shop/heoflix-dollar-receive"}
              </div>
            </div>

            {/* Simulate Incoming Dollars Button */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Quick Deposit Test (Receive Dollars into App)
                </label>
                <span className="text-[10px] text-emerald-400 font-mono">+100% Instant Credit</span>
              </div>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <span className="absolute left-3.5 top-2.5 text-xs text-slate-400 font-bold">$</span>
                  <input
                    type="number"
                    value={receiveAmount}
                    onChange={(e) => setReceiveAmount(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono font-bold text-white focus:outline-none focus:ring-2 focus:ring-sky-500"
                    placeholder="250"
                  />
                </div>
                <button
                  id="btn-simulate-paystack-receive"
                  type="button"
                  onClick={() => handleReceiveDollars()}
                  disabled={isReceiving}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-500 hover:from-sky-400 hover:to-indigo-400 text-white text-xs font-black shadow-lg transition flex items-center gap-2 cursor-pointer"
                >
                  <ArrowDownLeft className="w-3.5 h-3.5" />
                  <span>{isReceiving ? "Crediting..." : "Accept Dollars"}</span>
                </button>
              </div>

              {/* Completed Receive Deposit Receipt Action Card */}
              {receiveResult && (
                <div className="mt-3 p-4 rounded-2xl bg-sky-950/40 border border-sky-500/40 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs font-bold text-sky-400">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Payment Received & Credited to Dollar Wallet!</span>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded">
                      WALLET CREDITED
                    </span>
                  </div>

                  <div className="text-xs space-y-1 text-slate-300 font-mono">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Reference:</span>
                      <span className="text-white font-bold truncate max-w-[200px]">{receiveResult.receivedDetails?.reference}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Amount Credited:</span>
                      <span className="text-emerald-400 font-bold">${receiveResult.amountUsd?.toFixed(2) || receiveAmount} USD (₦{receiveResult.receivedDetails?.amountNgn?.toLocaleString()} NGN)</span>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        const rec: PaystackReceiptData = {
                          title: "Paystack Dollar Inflow & Credit Receipt",
                          reference: receiveResult.receivedDetails?.reference || `pstk_rcv_${Date.now()}`,
                          receiptNumber: receiveResult.receivedDetails?.receiptNumber || `RCP-RCV-${Date.now().toString().slice(-6)}`,
                          type: "RECEIVE_DEPOSIT",
                          amountUsd: parseFloat(receiveAmount),
                          amountNgn: receiveResult.receivedDetails?.amountNgn,
                          recipient: "HEOFLIX Admin Dollar Wallet",
                          bankOrChannel: "Paystack Dedicated Virtual Account (Wema/Titan)",
                          clearingRail: "Paystack Website DVA Settlement Rail",
                          timestamp: new Date().toISOString(),
                          status: "SETTLED & CREDITED",
                          senderOrPayer: payerName,
                          memo: `Received $${receiveAmount} USD via Paystack Website Wallet & Checkout`,
                        };
                        setActiveReceipt(rec);
                      }}
                      className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Receipt className="w-3.5 h-3.5 text-sky-400" />
                      <span>View Visual Receipt</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        downloadPaystackReceiptPdf({
                          title: "Paystack Dollar Inflow & Credit Receipt",
                          reference: receiveResult.receivedDetails?.reference || `pstk_rcv_${Date.now()}`,
                          receiptNumber: receiveResult.receivedDetails?.receiptNumber || `RCP-RCV-${Date.now().toString().slice(-6)}`,
                          type: "RECEIVE_DEPOSIT",
                          amountUsd: parseFloat(receiveAmount),
                          amountNgn: receiveResult.receivedDetails?.amountNgn,
                          recipient: "HEOFLIX Admin Dollar Wallet",
                          bankOrChannel: "Paystack Dedicated Virtual Account (Wema/Titan)",
                          clearingRail: "Paystack Website DVA Settlement Rail",
                          timestamp: new Date().toISOString(),
                          status: "SETTLED & CREDITED",
                          senderOrPayer: payerName,
                          memo: `Received $${receiveAmount} USD via Paystack Website Wallet & Checkout`,
                        });
                      }}
                      className="flex-1 py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-xs font-black text-white shadow transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download PDF</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Link Custom Receive Wallet from Paystack Website */}
          <div className="lg:col-span-6 rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-7 shadow-xl space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                <Sliders className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">
                  Connect Custom Paystack Website Wallet
                </h3>
                <p className="text-xs text-slate-400">
                  Paste details from your Paystack Dashboard (paystack.com) to accept custom DVA in app
                </p>
              </div>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Paystack DVA Account Number
                </label>
                <input
                  type="text"
                  value={linkAccNumber}
                  onChange={(e) => setLinkAccNumber(e.target.value)}
                  placeholder="e.g. 9823719284"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-emerald-300 font-mono font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Virtual Settlement Bank
                </label>
                <input
                  type="text"
                  value={linkBankName}
                  onChange={(e) => setLinkBankName(e.target.value)}
                  placeholder="e.g. Wema Bank / Titan Bank / Providus Bank"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Beneficiary Name on Paystack
                </label>
                <input
                  type="text"
                  value={linkAccName}
                  onChange={(e) => setLinkAccName(e.target.value)}
                  placeholder="e.g. HEOFLIX / GEORGE FELIX EGWU"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Paystack Customer / Merchant Code
                </label>
                <input
                  type="text"
                  value={linkCustomerCode}
                  onChange={(e) => setLinkCustomerCode(e.target.value)}
                  placeholder="e.g. CUS_georgefelix_pstk"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Paystack Payment Page URL
                </label>
                <input
                  type="text"
                  value={linkPaymentUrl}
                  onChange={(e) => setLinkPaymentUrl(e.target.value)}
                  placeholder="https://paystack.shop/..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sky-300 font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <button
                id="btn-save-custom-paystack-wallet"
                type="button"
                onClick={handleLinkCustomWallet}
                disabled={isLinkingWallet}
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{isLinkingWallet ? "Verifying..." : "Make Receive Wallet Acceptable in App"}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: COMMAND LOGIC CENTER (NATURAL LANGUAGE SEND & RECEIVE)
      ========================================================================= */}
      {activeTab === "command" && (
        <div className="space-y-6">
          <div className="rounded-3xl border border-indigo-500/30 bg-gradient-to-br from-slate-900 via-indigo-950/20 to-slate-950 p-6 sm:p-7 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                  <Terminal className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-white">
                    Legitimate Paystack Command Logic Engine
                  </h3>
                  <p className="text-xs text-slate-400">
                    Execute intelligent natural-language financial commands to send and receive dollars
                  </p>
                </div>
              </div>

              <span className="rounded-full bg-indigo-500/10 px-2.5 py-0.5 text-xs font-mono font-bold text-indigo-400 border border-indigo-500/30">
                COMMAND PARSER READY
              </span>
            </div>

            {/* Command Input Box */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                Command Directive
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Terminal className="w-4 h-4 text-indigo-400 absolute left-3.5 top-3.5" />
                  <input
                    id="input-paystack-command-text"
                    type="text"
                    value={commandInput}
                    onChange={(e) => setCommandInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") handleExecuteCommand();
                    }}
                    placeholder="e.g. Send $100 to George Felix Egwu at OPAY via Paystack"
                    className="w-full pl-10 pr-3.5 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs sm:text-sm font-mono text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <button
                  id="btn-run-paystack-command"
                  type="button"
                  onClick={() => handleExecuteCommand()}
                  disabled={isExecutingCommand}
                  className="px-5 py-3 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white text-xs font-black shadow-lg transition flex items-center gap-2 cursor-pointer shrink-0"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>{isExecutingCommand ? "Processing..." : "Run Command"}</span>
                </button>
              </div>
            </div>

            {/* Preset Command Buttons */}
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                Preset Financial Directives (Click to Execute):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {[
                  "Send $100 to George Felix Egwu at OPAY via Paystack",
                  "Send $250 to First Bank 3124446187 via Paystack",
                  "Receive $500 from Paystack website wallet",
                  "Receive $250 from Paystack payment link",
                  "Disburse $75 to 8134762646 OPAY via Paystack",
                  "Generate Paystack payment link for $150 USD",
                ].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => {
                      setCommandInput(preset);
                      handleExecuteCommand(preset);
                    }}
                    className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500/50 text-left text-[11px] text-slate-300 hover:text-white transition cursor-pointer flex items-center justify-between gap-2"
                  >
                    <span className="truncate">{preset}</span>
                    <ArrowUpRight className="w-3 h-3 text-indigo-400 shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Execution Log & Step Visualizer */}
          {lastCommandResponse && (
            <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <h4 className="text-sm font-extrabold text-white">Execution Timeline &amp; State Mutation</h4>
                </div>
                <span className="text-xs font-mono text-sky-400 font-bold">
                  {lastCommandResponse.action}
                </span>
              </div>

              {/* Steps Stream */}
              <div className="space-y-2">
                {lastCommandResponse.steps?.map((st: any) => (
                  <div
                    key={st.step}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-3 text-xs font-mono"
                  >
                    <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-black text-[11px] flex items-center justify-center shrink-0">
                      {st.step}
                    </span>
                    <span className="text-slate-200">{st.message}</span>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs font-mono text-emerald-300 flex items-center justify-between">
                <span>Result: {lastCommandResponse.message}</span>
                {lastCommandResponse.receiptNumber && (
                  <strong className="text-white">Receipt: {lastCommandResponse.receiptNumber}</strong>
                )}
              </div>

              {lastCommandResponse.receiptNumber && (
                <div className="flex gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      const isSend = lastCommandResponse.action === "SEND_DOLLARS";
                      const rec: PaystackReceiptData = {
                        title: isSend ? "Paystack Command Transfer Receipt" : "Paystack Command Deposit Receipt",
                        reference: lastCommandResponse.reference || `pstk_cmd_${Date.now()}`,
                        receiptNumber: lastCommandResponse.receiptNumber,
                        type: isSend ? "TRANSFER_SEND" : "RECEIVE_DEPOSIT",
                        amountUsd: lastCommandResponse.amountUsd || 100,
                        amountNgn: lastCommandResponse.amountNgn,
                        recipient: lastCommandResponse.recipient || "George Felix Egwu (OPAY - 8134762646)",
                        bankOrChannel: isSend ? "OPAY / NIP Switch" : "Paystack Dedicated Virtual Account",
                        clearingRail: "Paystack Instant NIP Switch (< 1.5s)",
                        timestamp: new Date().toISOString(),
                        status: "CLEARED & DELIVERED",
                        senderOrPayer: isSend ? "HEOFLIX Master Dollar Wallet" : "Paystack Website Customer",
                        memo: lastCommandResponse.command,
                      };
                      setActiveReceipt(rec);
                    }}
                    className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-white border border-slate-700 transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Receipt className="w-3.5 h-3.5 text-sky-400" />
                    <span>View Visual Receipt</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const isSend = lastCommandResponse.action === "SEND_DOLLARS";
                      downloadPaystackReceiptPdf({
                        title: isSend ? "Paystack Command Transfer Receipt" : "Paystack Command Deposit Receipt",
                        reference: lastCommandResponse.reference || `pstk_cmd_${Date.now()}`,
                        receiptNumber: lastCommandResponse.receiptNumber,
                        type: isSend ? "TRANSFER_SEND" : "RECEIVE_DEPOSIT",
                        amountUsd: lastCommandResponse.amountUsd || 100,
                        amountNgn: lastCommandResponse.amountNgn,
                        recipient: lastCommandResponse.recipient || "George Felix Egwu (OPAY - 8134762646)",
                        bankOrChannel: isSend ? "OPAY / NIP Switch" : "Paystack Dedicated Virtual Account",
                        clearingRail: "Paystack Instant NIP Switch (< 1.5s)",
                        timestamp: new Date().toISOString(),
                        status: "CLEARED & DELIVERED",
                        senderOrPayer: isSend ? "HEOFLIX Master Dollar Wallet" : "Paystack Website Customer",
                        memo: lastCommandResponse.command,
                      });
                    }}
                    className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-black text-white shadow transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* =========================================================================
          TAB 4: PAYSTACK REAL-TIME LEDGER
      ========================================================================= */}
      {activeTab === "ledger" && (
        <div className="rounded-3xl border border-slate-800 bg-slate-900/90 p-6 sm:p-7 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-slate-800">
            <div>
              <h3 className="text-base font-extrabold text-white">Paystack Unified Transaction Ledger</h3>
              <p className="text-xs text-slate-400">All real-time sends, receives, deposits, and webhooks</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                id="btn-export-all-receipts-pdf"
                type="button"
                onClick={() => {
                  downloadPaystackTransactionsStatementPdf(
                    transactions,
                    summaryStats?.totalDisbursedUsd || 0,
                    summaryStats?.totalReceivedUsd || 0
                  );
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-sky-600 to-emerald-600 hover:from-sky-500 hover:to-emerald-500 text-xs font-bold text-white shadow transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Statement (PDF)</span>
              </button>

              <button
                type="button"
                onClick={fetchGatewayData}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300 border border-slate-700 transition cursor-pointer"
              >
                <RefreshCw className="w-3 h-3" />
                <span>Refresh Ledger</span>
              </button>
            </div>
          </div>

          {/* Transactions List */}
          <div className="space-y-2.5">
            {transactions.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No Paystack transactions recorded yet. Use the Send or Receive tabs to execute transfers.
              </div>
            ) : (
              transactions.map((tx) => (
                <div
                  key={tx.id}
                  className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs"
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        tx.type === "TRANSFER_SEND"
                          ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                          : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                      }`}
                    >
                      {tx.type === "TRANSFER_SEND" ? (
                        <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                      ) : (
                        <ArrowDownLeft className="w-4 h-4 stroke-[2.5]" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <strong className="text-white text-sm">{tx.memo}</strong>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            tx.status === "CLEARED"
                              ? "bg-emerald-500/10 text-emerald-400"
                              : "bg-amber-500/10 text-amber-400"
                          }`}
                        >
                          {tx.status}
                        </span>
                      </div>
                      <div className="text-slate-400 text-[11px] mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1">
                        <span>Ref: <strong className="font-mono text-slate-300">{tx.reference}</strong></span>
                        <span>Recipient/Party: <strong className="text-slate-200">{tx.recipient}</strong></span>
                        <span>Rail: {tx.clearingRail}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-1 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
                    <div
                      className={`text-sm sm:text-base font-black font-mono ${
                        tx.type === "TRANSFER_SEND" ? "text-rose-400" : "text-emerald-400"
                      }`}
                    >
                      {tx.type === "TRANSFER_SEND" ? "-" : "+"}
                      ${tx.amountUsd.toFixed(2)} USD
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">
                      (₦{tx.amountNgn.toLocaleString()} NGN)
                    </span>
                    <div className="flex items-center gap-1.5 mt-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          setActiveReceipt({
                            title: tx.type === "TRANSFER_SEND" ? "Paystack Interbank Transfer Receipt" : "Paystack Settlement & Inflow Receipt",
                            reference: tx.reference,
                            receiptNumber: tx.receiptNumber,
                            type: tx.type,
                            amountUsd: tx.amountUsd,
                            amountNgn: tx.amountNgn,
                            recipient: tx.recipient,
                            bankOrChannel: tx.bankOrChannel,
                            clearingRail: tx.clearingRail,
                            timestamp: tx.timestamp,
                            status: tx.status,
                            senderOrPayer: tx.senderOrPayer,
                            memo: tx.memo,
                          })
                        }
                        className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[10px] text-sky-400 font-bold border border-slate-700 transition flex items-center gap-1 cursor-pointer"
                        title="View Visual Receipt"
                      >
                        <Receipt className="w-3 h-3" />
                        <span>View Receipt</span>
                      </button>

                      <button
                        type="button"
                        onClick={() =>
                          downloadPaystackReceiptPdf({
                            title: tx.type === "TRANSFER_SEND" ? "Paystack Interbank Transfer Receipt" : "Paystack Settlement & Inflow Receipt",
                            reference: tx.reference,
                            receiptNumber: tx.receiptNumber,
                            type: tx.type,
                            amountUsd: tx.amountUsd,
                            amountNgn: tx.amountNgn,
                            recipient: tx.recipient,
                            bankOrChannel: tx.bankOrChannel,
                            clearingRail: tx.clearingRail,
                            timestamp: tx.timestamp,
                            status: tx.status,
                            senderOrPayer: tx.senderOrPayer,
                            memo: tx.memo,
                          })
                        }
                        className="px-2 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 text-[10px] text-emerald-400 font-bold border border-emerald-500/30 transition flex items-center gap-1 cursor-pointer"
                        title="Download PDF Receipt"
                      >
                        <Download className="w-3 h-3" />
                        <span>PDF</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 5: API & WEBHOOK CONFIGURATION
      ========================================================================= */}
      {activeTab === "settings" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Key className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">Paystack API Credentials</h3>
                <p className="text-xs text-slate-400">Connect live or test keys from dashboard.paystack.com</p>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Paystack Secret Key (sk_live_... or sk_test_...)
                </label>
                <input
                  type="password"
                  value={secretKeyInput}
                  onChange={(e) => setSecretKeyInput(e.target.value)}
                  placeholder="Paste sk_live_... or sk_test_..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-xs focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <button
                id="btn-validate-paystack-key"
                type="button"
                onClick={handleValidateSecretKey}
                disabled={isValidatingKey}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Key className="w-3.5 h-3.5" />
                <span>{isValidatingKey ? "Validating with Paystack Servers..." : "Validate & Activate Secret Key"}</span>
              </button>

              {keyValidationResult && (
                <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Secret Key Validated Successfully!</span>
                  </div>
                  <div className="text-[11px] text-slate-300">
                    Mode: <strong className="text-white">{keyValidationResult.mode}</strong>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-6 rounded-3xl border border-slate-800 bg-slate-900/90 p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
                <Radio className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">Automated Webhooks Endpoint</h3>
                <p className="text-xs text-slate-400">Instant credit callbacks from Paystack platform</p>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-400 block mb-1">Webhook Callback URL:</span>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-sky-300 break-all select-all">
                  https://ais-dev-ysqnqaqjsxiadsjdlf6jkp-550800810293.europe-west2.run.app/api/v1/paystack/webhook
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div>&bull; Signature header: <strong className="text-white">x-paystack-signature</strong></div>
                <div>&bull; Encryption: <strong className="text-white">HMAC SHA512</strong></div>
                <div>&bull; Events handled: <strong className="text-emerald-400">charge.success</strong>, <strong className="text-sky-300">transfer.success</strong></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          OFFICIAL PAYSTACK VISUAL & DOWNLOADABLE PDF RECEIPT MODAL
      ========================================================================= */}
      <PaystackReceiptModal
        isOpen={Boolean(activeReceipt)}
        onClose={() => setActiveReceipt(null)}
        receipt={activeReceipt}
      />
    </div>
  );
};
