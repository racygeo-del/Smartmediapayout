import React from "react";
import { X, Fingerprint, ShieldCheck, Zap, Lock, Smartphone, CheckCircle2 } from "lucide-react";
import { useBiometrics } from "../hooks/useBiometrics";

interface BiometricSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BiometricSettingsModal: React.FC<BiometricSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    preferences,
    updatePreferences,
    hardwareLabel,
    fingerprintInfo,
    isTesting,
    testBiometrics,
    lastTestResult,
  } = useBiometrics();

  if (!isOpen) return null;

  return (
    <div
      id="modal-biometric-settings"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in"
    >
      <div className="relative w-full max-w-lg rounded-3xl border border-slate-800 bg-slate-900 p-6 sm:p-7 shadow-2xl">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-5 top-5 rounded-full p-2 text-slate-400 hover:bg-slate-800 hover:text-white transition"
          title="Close Settings"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
            <Fingerprint className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white">Biometric Preferences</h3>
              <span className="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[10px] font-bold text-indigo-400 border border-indigo-500/30">
                FIDO2 / WebAuthn
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Customize Touch ID, Face ID, and biometric fast authorization.
            </p>
          </div>
        </div>

        {/* Master Biometric Toggle */}
        <div className="mt-5 p-4 rounded-2xl border border-slate-800 bg-slate-800/40 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl ${preferences.enabled ? "bg-emerald-500/10 text-emerald-400" : "bg-slate-800 text-slate-500"}`}>
              <Fingerprint className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-white">Biometric Authentication</div>
              <div className="text-[11px] text-slate-400">
                {preferences.enabled ? "Enabled for transfers and vault operations" : "Disabled (Master Admin Password required)"}
              </div>
            </div>
          </div>

          <button
            id="btn-header-modal-toggle-biometrics"
            type="button"
            onClick={() => updatePreferences({ enabled: !preferences.enabled })}
            className={`relative inline-flex h-7 w-13 items-center rounded-full transition-colors focus:outline-none cursor-pointer ${
              preferences.enabled ? "bg-emerald-500" : "bg-slate-700"
            }`}
          >
            <span
              className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-md transition-transform ${
                preferences.enabled ? "translate-x-7" : "translate-x-1"
              }`}
            />
          </button>
        </div>

        {/* Sub-Preferences */}
        <div className="space-y-3 mt-4">
          {/* Fast push credit payouts */}
          <div
            onClick={() => updatePreferences({ autoAuthorizeTransfers: !preferences.autoAuthorizeTransfers })}
            className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
              preferences.autoAuthorizeTransfers && preferences.enabled
                ? "border-emerald-500/30 bg-emerald-950/20"
                : "border-slate-800 bg-slate-800/30 opacity-70"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Zap className="w-4 h-4 text-amber-400 shrink-0" />
              <div>
                <div className="text-xs font-bold text-white">One-Touch Push Credit Transfers</div>
                <div className="text-[11px] text-slate-400">Auto-prompt biometric scan on bank disbursements</div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={preferences.autoAuthorizeTransfers && preferences.enabled}
              onChange={() => {}}
              className="h-4 w-4 rounded accent-emerald-500 pointer-events-none"
            />
          </div>

          {/* One-touch vault unlock */}
          <div
            onClick={() => updatePreferences({ vaultUnlockEnabled: !preferences.vaultUnlockEnabled })}
            className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-center justify-between ${
              preferences.vaultUnlockEnabled && preferences.enabled
                ? "border-indigo-500/30 bg-indigo-950/20"
                : "border-slate-800 bg-slate-800/30 opacity-70"
            }`}
          >
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-4 h-4 text-indigo-400 shrink-0" />
              <div>
                <div className="text-xs font-bold text-white">One-Touch Vault Security</div>
                <div className="text-[11px] text-slate-400">Unlock revenue sliders and bank settings with sensor</div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={preferences.vaultUnlockEnabled && preferences.enabled}
              onChange={() => {}}
              className="h-4 w-4 rounded accent-indigo-500 pointer-events-none"
            />
          </div>
        </div>

        {/* Hardware Status */}
        <div className="mt-4 p-3 rounded-2xl border border-emerald-500/30 bg-emerald-950/20 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-300 min-w-0">
            <Fingerprint className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">Fingerprint Machine: <strong className="text-white">{fingerprintInfo.sensorName}</strong></span>
          </div>
          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 shrink-0">
            Detected & Ready
          </span>
        </div>

        {lastTestResult && (
          <div className="mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{lastTestResult.message}</span>
          </div>
        )}

        {/* Footer Actions */}
        <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={testBiometrics}
            disabled={isTesting}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition"
          >
            <Fingerprint className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isTesting ? "Testing Sensor..." : "Test Sensor"}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-xs font-bold text-white transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
