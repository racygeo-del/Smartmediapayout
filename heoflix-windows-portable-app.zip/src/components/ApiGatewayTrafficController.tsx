import React, { useState, useEffect, useMemo } from "react";
import {
  Server,
  Activity,
  Zap,
  ShieldCheck,
  Cpu,
  ArrowRight,
  RefreshCw,
  Sliders,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Layers,
  Radio,
  Clock,
  Send,
  Database,
  Search,
  Check,
  ChevronRight,
  Code2,
  FileCheck,
  Gauge,
  Terminal,
  Coins,
  Sparkles,
  Building,
} from "lucide-react";
import {
  PaymentRailStatus,
  PaymentRailType,
  RoutedTransferOrder,
  TrafficControllerMode,
  TrafficControllerState,
  TrafficExecutionLog,
  TrafficPriority,
  WalletState,
} from "../types";
import { AIFundsGatewayEngine } from "./AIFundsGatewayEngine";
import { RealCryptoTransactionsGateway } from "./RealCryptoTransactionsGateway";

interface ApiGatewayTrafficControllerProps {
  wallet?: WalletState;
  onUpdateWallet?: (newWallet: WalletState) => void;
  onRefreshAllData?: () => void;
}

const defaultGatewayStatus = {
  name: "HEOFLIX Enterprise API Gateway & Traffic Routing Engine",
  version: "v4.2.0-SOVEREIGN",
  status: "OPERATIONAL",
  uptimeSeconds: 1254,
  timestamp: new Date().toISOString(),
};

const defaultTrafficController: TrafficControllerState = {
  mode: "AUTONOMOUS_ADAPTIVE",
  isExecutionEnabled: true,
  lastInterventionExecutedAt: new Date().toISOString(),
  activeConnections: 18,
  currentRps: 24.6,
  peakRps: 188.4,
  avgLatencyMs: 68.2,
  queueDepth: 2,
  maxQueueCapacity: 500,
  totalRequestsProcessed: 489714,
  throttledRequestsCount: 14,
  loadSheddingActive: false,
  rateLimitPerMinute: {
    CRITICAL_FINANCIAL: 600,
    STANDARD_API: 180,
    BACKGROUND_BATCH: 60,
  },
  burstCapacity: {
    CRITICAL_FINANCIAL: 50,
    STANDARD_API: 25,
    BACKGROUND_BATCH: 10,
  },
  circuitBreakerThresholdFailures: 5,
  circuitBreakerCooldownSeconds: 30,
};

export default function ApiGatewayTrafficController({
  wallet,
  onUpdateWallet,
  onRefreshAllData,
}: ApiGatewayTrafficControllerProps = {}) {
  const [activeTab, setActiveTab] = useState<
    "ai_funds_gateway" | "crypto_gateway" | "traffic" | "rails" | "dispatch" | "validator" | "orders"
  >("ai_funds_gateway");

  const [gatewayStatus, setGatewayStatus] = useState<any>(defaultGatewayStatus);
  const [trafficController, setTrafficController] = useState<TrafficControllerState>(defaultTrafficController);
  const [paymentRails, setPaymentRails] = useState<Record<PaymentRailType, PaymentRailStatus> | null>(null);
  const [routedOrders, setRoutedOrders] = useState<RoutedTransferOrder[]>([]);
  const [logs, setLogs] = useState<TrafficExecutionLog[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [actionMessage, setActionMessage] = useState<string>("");

  // Transfer Order Dispatch Form State
  const [orderAmount, setOrderAmount] = useState<string>("15000");
  const [orderCurrency, setOrderCurrency] = useState<string>("USD");
  const [recipientName, setRecipientName] = useState<string>("George Felix Egwu");
  const [recipientAccount, setRecipientAccount] = useState<string>("0847920194");
  const [destinationBank, setDestinationBank] = useState<string>("JPMorgan Chase Bank");
  const [orderPriority, setOrderPriority] = useState<TrafficPriority>("CRITICAL_FINANCIAL");
  const [isDispatching, setIsDispatching] = useState<boolean>(false);
  const [lastDispatchedOrder, setLastDispatchedOrder] = useState<RoutedTransferOrder | null>(null);
  const [dispatchError, setDispatchError] = useState<string | null>(null);

  // Payload Validator Lab State
  const [customJsonPayload, setCustomJsonPayload] = useState<string>(
    JSON.stringify(
      {
        amount: 250000,
        currency: "USD",
        recipientName: "Federal Treasury Settlement",
        recipientAccount: "9823719284",
        destinationBankOrNetwork: "Citibank N.A. (FedNow / RTP)",
        orderType: "INSTANT_SETTLEMENT",
        priority: "CRITICAL_FINANCIAL",
      },
      null,
      2
    )
  );
  const [validationResult, setValidationResult] = useState<any>(null);
  const [isValidating, setIsValidating] = useState<boolean>(false);

  // Filters
  const [orderSearchQuery, setOrderSearchQuery] = useState<string>("");
  const [selectedRailFilter, setSelectedRailFilter] = useState<string>("ALL");

  // Play subtle audio chime
  const playAudioCue = (isSuccess = true) => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(isSuccess ? 880 : 330, ctx.currentTime);
      if (isSuccess) {
        osc.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.15);
      }
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {}
  };

  // Fetch Gateway Data
  const fetchGatewayData = async () => {
    try {
      const [resStatus, resOrders, resLogs, resRails] = await Promise.all([
        fetch("/api/v1/gateway/status")
          .then((r) => (r.ok ? r.json() : null))
          .catch(() => null),
        fetch("/api/v1/gateway/transfer-orders?limit=40")
          .then((r) => (r.ok ? r.json() : null))
          .catch(() => null),
        fetch("/api/v1/gateway/traffic/logs?limit=40")
          .then((r) => (r.ok ? r.json() : null))
          .catch(() => null),
        fetch("/api/v1/gateway/rails/status")
          .then((r) => (r.ok ? r.json() : null))
          .catch(() => null),
      ]);

      if (resStatus?.gateway) {
        setGatewayStatus(resStatus.gateway);
      }
      if (resStatus?.trafficController) {
        setTrafficController(resStatus.trafficController);
      }

      if (resRails?.rails) {
        setPaymentRails(resRails.rails);
      }

      if (resOrders?.orders && Array.isArray(resOrders.orders)) {
        setRoutedOrders(resOrders.orders);
      }

      if (resLogs?.logs && Array.isArray(resLogs.logs)) {
        setLogs(resLogs.logs);
      }
    } catch {
      // Graceful offline fallback without unhandled promise rejections
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchGatewayData();
    const interval = setInterval(fetchGatewayData, 6000);
    return () => clearInterval(interval);
  }, []);

  // Execute Traffic Controller Intervention
  const executeIntervention = async (action: string, payload: any = {}) => {
    try {
      const res = await fetch("/api/v1/gateway/traffic-controller/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, ...payload }),
      });
      const data = await res.json();
      if (data.success) {
        playAudioCue(true);
        setActionMessage(data.message || "Intervention executed successfully.");
        setTimeout(() => setActionMessage(""), 4500);
        fetchGatewayData();
      }
    } catch (e) {
      setActionMessage("Failed to execute intervention.");
      setTimeout(() => setActionMessage(""), 3500);
    }
  };

  // Dispatch Transfer Order
  const handleDispatchOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsDispatching(true);
    setDispatchError(null);
    setLastDispatchedOrder(null);

    try {
      const payload = {
        amount: parseFloat(orderAmount),
        currency: orderCurrency.toUpperCase(),
        recipientName,
        recipientAccount,
        destinationBankOrNetwork: destinationBank,
        priority: orderPriority,
        idempotencyKey: `idem_ui_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
      };

      const res = await fetch("/api/v1/gateway/transfer-orders/route", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Traffic-Priority": orderPriority,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        playAudioCue(false);
        const errDetail = data.details
          ? data.details.map((d: any) => d.message).join(" • ")
          : data.message || data.error || "Order dispatch failed";
        setDispatchError(errDetail);
      } else {
        playAudioCue(true);
        setLastDispatchedOrder(data.order);
        setActionMessage(`Order routed successfully to ${data.order.railName}!`);
        setTimeout(() => setActionMessage(""), 4500);
        fetchGatewayData();
      }
    } catch (e: any) {
      playAudioCue(false);
      setDispatchError(e?.message || "Network error while contacting API Gateway.");
    } finally {
      setIsDispatching(false);
    }
  };

  // Test Custom Payload Validation
  const handleValidatePayload = async () => {
    setIsValidating(true);
    setValidationResult(null);
    try {
      let parsed = {};
      try {
        parsed = JSON.parse(customJsonPayload);
      } catch (err: any) {
        setValidationResult({
          isValid: false,
          error: "MALFORMED_JSON",
          message: `Syntax error in JSON: ${err.message}`,
        });
        playAudioCue(false);
        setIsValidating(false);
        return;
      }

      const res = await fetch("/api/v1/gateway/validate-payload", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed),
      });

      const data = await res.json();
      setValidationResult(data);
      playAudioCue(data.success);
    } catch (e: any) {
      setValidationResult({
        isValid: false,
        error: "GATEWAY_UNREACHABLE",
        message: e?.message || "Failed to reach schema validator endpoint.",
      });
      playAudioCue(false);
    } finally {
      setIsValidating(false);
    }
  };

  // Filtered orders
  const filteredOrders = useMemo(() => {
    return routedOrders.filter((ord) => {
      const matchesSearch =
        orderSearchQuery === "" ||
        ord.trackingNumber.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
        ord.recipientName.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
        ord.recipientAccount.includes(orderSearchQuery) ||
        ord.currency.toLowerCase().includes(orderSearchQuery.toLowerCase()) ||
        ord.railName.toLowerCase().includes(orderSearchQuery.toLowerCase());

      const matchesRail =
        selectedRailFilter === "ALL" || ord.selectedRail === selectedRailFilter;

      return matchesSearch && matchesRail;
    });
  }, [routedOrders, orderSearchQuery, selectedRailFilter]);

  return (
    <div className="space-y-6 pb-16">
      {/* =========================================================================
          TOP EXECUTIVE COMMAND BAR
      ========================================================================= */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-indigo-950 border border-slate-700/80 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-1/3 -mb-20 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                API GATEWAY OPERATIONAL
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-sky-500/15 text-sky-300 border border-sky-500/30 flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5" />
                TRAFFIC CONTROLLER: {trafficController?.mode || "AUTONOMOUS_ADAPTIVE"}
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                ACTIVE RAILS: {paymentRails ? Object.keys(paymentRails).length : 8}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-3">
              <Server className="w-8 h-8 text-sky-400" />
              <span>Back-End API Gateway &amp; Routing Engine</span>
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Autonomous high-throughput traffic controller, cryptographic request payload validation,
              dynamic rate-limit throttling, and intelligent settlement routing across FedNow, RTP, SEPA,
              NIP, Paystack, and Bitcoin payment rails.
            </p>
          </div>

          {/* Quick Intervention Controls */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => executeIntervention("TRIGGER_TRAFFIC_SWEEP")}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-600/80 text-xs font-mono font-bold flex items-center gap-2 transition-all hover:scale-[1.02] shadow-md cursor-pointer"
              title="Flush token bucket queues and re-balance connection pools"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Execute Traffic Sweep</span>
            </button>

            <button
              onClick={() => executeIntervention("TOGGLE_EXECUTION")}
              className={`px-4 py-2.5 rounded-xl text-xs font-mono font-bold flex items-center gap-2 transition-all hover:scale-[1.02] shadow-md cursor-pointer ${
                trafficController?.isExecutionEnabled
                  ? "bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-400/40"
                  : "bg-amber-600 hover:bg-amber-500 text-white border border-amber-400/40"
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>
                {trafficController?.isExecutionEnabled ? "Execution Active" : "Execution Paused"}
              </span>
            </button>

            <button
              onClick={fetchGatewayData}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600/80 hover:text-white transition-all cursor-pointer"
              title="Refresh Gateway Metrics"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>

        {/* Global Action Banner */}
        {actionMessage && (
          <div className="mt-4 p-3 rounded-xl bg-sky-950/80 border border-sky-500/40 text-sky-200 text-xs font-mono flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 text-sky-400 shrink-0" />
            <span>{actionMessage}</span>
          </div>
        )}
      </div>

      {/* =========================================================================
          KEY TELEMETRY METRICS CARDS
      ========================================================================= */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between mb-1">
            <span>Throughput</span>
            <Activity className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold font-mono text-white">
            {(trafficController?.currentRps ?? 24.6).toFixed(1)}{" "}
            <span className="text-xs text-sky-400">rps</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">
            Peak: {(trafficController?.peakRps ?? 188.4).toFixed(1)} rps
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between mb-1">
            <span>Avg Latency</span>
            <Gauge className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold font-mono text-emerald-400">
            {trafficController?.avgLatencyMs || "68"}{" "}
            <span className="text-xs text-slate-400">ms</span>
          </div>
          <div className="text-[10px] text-emerald-400/80 mt-1 font-mono">Sub-100ms SLA OK</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between mb-1">
            <span>Active Conn</span>
            <Radio className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold font-mono text-white">
            {trafficController?.activeConnections || "18"}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Anycast Nodes Pool</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between mb-1">
            <span>Queue Depth</span>
            <Layers className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold font-mono text-amber-300">
            {trafficController?.queueDepth || "2"} /{" "}
            <span className="text-xs text-slate-400">500</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">Non-blocking</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between mb-1">
            <span>Throttled</span>
            <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold font-mono text-white">
            {trafficController?.throttledRequestsCount || "14"}
          </div>
          <div className="text-[10px] text-rose-400 mt-1 font-mono">Rate Limits Guarded</div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider flex items-center justify-between mb-1">
            <span>Orders Routed</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-sky-400" />
          </div>
          <div className="text-xl sm:text-2xl font-extrabold font-mono text-sky-400">
            {routedOrders.length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">100% Finality</div>
        </div>
      </div>

      {/* =========================================================================
          NAVIGATION TABS
      ========================================================================= */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveTab("ai_funds_gateway")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "ai_funds_gateway"
              ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-950/60"
              : "bg-slate-850 hover:bg-slate-800 text-emerald-300 hover:text-white"
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
          <span>🤖 AI Funds Gateway (Bank &amp; Crypto)</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-emerald-950 text-emerald-200 font-mono font-bold">
            ACTIVE
          </span>
        </button>

        <button
          onClick={() => setActiveTab("crypto_gateway")}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "crypto_gateway"
              ? "bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-lg shadow-amber-950/60"
              : "bg-slate-850 hover:bg-slate-800 text-amber-300 hover:text-white"
          }`}
        >
          <Coins className="w-3.5 h-3.5 text-amber-400" />
          <span>🪙 Real Crypto Transactions Gateway</span>
        </button>

        <button
          onClick={() => setActiveTab("traffic")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "traffic"
              ? "bg-sky-600 text-white shadow-lg shadow-sky-950/60"
              : "bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white"
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Traffic Controller</span>
        </button>

        <button
          onClick={() => setActiveTab("rails")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "rails"
              ? "bg-sky-600 text-white shadow-lg shadow-sky-950/60"
              : "bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white"
          }`}
        >
          <Server className="w-3.5 h-3.5" />
          <span>Payment Rails Matrix</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-sky-950 text-sky-200 font-mono">
            {paymentRails ? Object.keys(paymentRails).length : 8}
          </span>
        </button>

        <button
          onClick={() => setActiveTab("dispatch")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "dispatch"
              ? "bg-indigo-600 text-white shadow-lg shadow-indigo-950/60"
              : "bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white"
          }`}
        >
          <Send className="w-3.5 h-3.5" />
          <span>Dispatch &amp; Route Transfer Order</span>
        </button>

        <button
          onClick={() => setActiveTab("validator")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "validator"
              ? "bg-emerald-600 text-white shadow-lg shadow-emerald-950/60"
              : "bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white"
          }`}
        >
          <FileCheck className="w-3.5 h-3.5" />
          <span>Payload Schema Validator Lab</span>
        </button>

        <button
          onClick={() => setActiveTab("orders")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
            activeTab === "orders"
              ? "bg-sky-600 text-white shadow-lg shadow-sky-950/60"
              : "bg-slate-850 hover:bg-slate-800 text-slate-300 hover:text-white"
          }`}
        >
          <Database className="w-3.5 h-3.5" />
          <span>Routed Orders Ledger</span>
          <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-slate-900 text-slate-300 font-mono">
            {routedOrders.length}
          </span>
        </button>
      </div>

      {/* =========================================================================
          TAB 0A: AI GENERATED FUNDS GATEWAY (TRANSFER TO ANY BANK OR CRYPTO WALLET)
      ========================================================================= */}
      {activeTab === "ai_funds_gateway" && (
        <AIFundsGatewayEngine
          wallet={wallet}
          onUpdateWallet={onUpdateWallet}
          onRefreshAllData={onRefreshAllData}
        />
      )}

      {/* =========================================================================
          TAB 0B: REAL-LIFE CRYPTOCURRENCY TRANSACTIONS GATEWAY
      ========================================================================= */}
      {activeTab === "crypto_gateway" && (
        <RealCryptoTransactionsGateway />
      )}

      {/* =========================================================================
          TAB 1: TRAFFIC CONTROLLER & EXECUTION
      ========================================================================= */}
      {activeTab === "traffic" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Controller Mode & Execution Controls */}
          <div className="lg:col-span-1 space-y-5">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Sliders className="w-4 h-4 text-sky-400" />
                <span>Traffic Controller Execution</span>
              </h3>

              <div className="space-y-2">
                <label className="text-xs text-slate-400 block font-mono">Controller Mode</label>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    {
                      mode: "AUTONOMOUS_ADAPTIVE",
                      title: "Autonomous Adaptive",
                      desc: "Dynamically shapes traffic, sheds batch queries, prioritizes financial orders.",
                    },
                    {
                      mode: "ENFORCED_BALANCED",
                      title: "Enforced Balanced",
                      desc: "Strict token-bucket rate limits applied uniformly across all ingress endpoints.",
                    },
                    {
                      mode: "EMERGENCY_PROTECTION",
                      title: "Emergency Protection",
                      desc: "Blocks unauthenticated traffic, reserves 100% capacity for treasury transfers.",
                    },
                  ].map((m) => (
                    <button
                      key={m.mode}
                      onClick={() => executeIntervention("SET_MODE", { mode: m.mode })}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        trafficController?.mode === m.mode
                          ? "bg-sky-950/60 border-sky-500/60 text-white ring-1 ring-sky-500/50"
                          : "bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300"
                      }`}
                    >
                      <div className="text-xs font-bold font-mono flex items-center justify-between">
                        <span>{m.title}</span>
                        {trafficController?.mode === m.mode && (
                          <Check className="w-3.5 h-3.5 text-sky-400" />
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1 leading-snug">{m.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Rate Limit Tier Table */}
              <div className="pt-3 border-t border-slate-800 space-y-2.5">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block font-mono">
                  Token Bucket Tiers &amp; Caps
                </span>
                <div className="space-y-1.5 font-mono text-[11px]">
                  <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="text-emerald-400 font-bold">CRITICAL_FINANCIAL</span>
                    <span className="text-slate-300">600 req/min (Burst: 50)</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="text-sky-400 font-bold">STANDARD_API</span>
                    <span className="text-slate-300">180 req/min (Burst: 25)</span>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <span className="text-amber-400 font-bold">BACKGROUND_BATCH</span>
                    <span className="text-slate-300">60 req/min (Burst: 10)</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
                <button
                  onClick={() => executeIntervention("TRIGGER_TRAFFIC_SWEEP")}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-sky-950/60 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.99]"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Execute Full Traffic Sweep</span>
                </button>
              </div>
            </div>
          </div>

          {/* Live Execution Logs & Stream */}
          <div className="lg:col-span-2 space-y-5">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-400" />
                  <span>Traffic Controller Real-Time Execution Logs</span>
                </h3>
                <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  BUFFER ACTIVE
                </span>
              </div>

              <div className="bg-slate-950 rounded-xl border border-slate-800 p-3 h-[420px] overflow-y-auto font-mono text-xs space-y-2">
                {logs.length === 0 ? (
                  <div className="text-slate-500 text-center py-16">
                    No traffic controller logs in buffer.
                  </div>
                ) : (
                  logs.map((log) => (
                    <div
                      key={log.id}
                      className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800/80 flex items-start gap-3 hover:border-slate-700 transition-colors"
                    >
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold shrink-0 ${
                          log.severity === "SUCCESS"
                            ? "bg-emerald-500/20 text-emerald-300"
                            : log.severity === "WARN"
                            ? "bg-amber-500/20 text-amber-300"
                            : log.severity === "CRITICAL"
                            ? "bg-rose-500/20 text-rose-300"
                            : "bg-sky-500/20 text-sky-300"
                        }`}
                      >
                        {log.eventType}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="text-slate-200 break-words">{log.details}</div>
                        <div className="text-[10px] text-slate-500 mt-1 flex items-center gap-3">
                          <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                          <span>IP: {log.clientIp}</span>
                          <span className="truncate">{log.endpoint}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 2: PAYMENT RAILS MATRIX
      ========================================================================= */}
      {activeTab === "rails" && paymentRails && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Server className="w-4 h-4 text-sky-400" />
              <span>Multi-Currency Payment Rails Network Status</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Auto-Failover Circuit Breakers Enabled
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Object.values(paymentRails).map((rail) => (
              <div
                key={rail.id}
                className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-xl flex flex-col justify-between transition-all"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <span className="px-2.5 py-1 rounded-full text-[10.5px] font-mono font-bold bg-slate-800 text-sky-300 border border-slate-700">
                      {rail.id}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold flex items-center gap-1 ${
                        rail.status === "ONLINE_ACTIVE"
                          ? "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30"
                          : "bg-rose-500/15 text-rose-300 border border-rose-500/30"
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          rail.status === "ONLINE_ACTIVE" ? "bg-emerald-400" : "bg-rose-400"
                        }`}
                      />
                      {rail.status}
                    </span>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-white leading-snug">{rail.name}</h4>
                    <p className="text-xs text-slate-400 mt-0.5">{rail.region}</p>
                  </div>

                  <div className="space-y-2 font-mono text-xs pt-2 border-t border-slate-800">
                    <div className="flex justify-between text-slate-400">
                      <span>Currencies:</span>
                      <span className="text-slate-200 font-bold">
                        {rail.supportedCurrencies.join(", ")}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Finality:</span>
                      <span className="text-emerald-400 font-bold">{rail.settlementTime}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Latency:</span>
                      <span className="text-sky-300 font-bold">{rail.avgLatencyMs} ms</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Success SLA:</span>
                      <span className="text-slate-200 font-bold">{rail.successRate}%</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Fallback Rail:</span>
                      <span className="text-indigo-400 text-[10px]">{rail.redundantBackupRail}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-800 flex items-center justify-between">
                  <div className="text-[10px] font-mono text-slate-400 truncate max-w-[150px]">
                    {rail.endpointSwitch}
                  </div>
                  <button
                    onClick={() =>
                      executeIntervention("UPDATE_RAIL_STATUS", {
                        railId: rail.id,
                        newStatus:
                          rail.status === "ONLINE_ACTIVE" ? "CIRCUIT_BROKEN" : "ONLINE_ACTIVE",
                      })
                    }
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold transition-all cursor-pointer ${
                      rail.status === "ONLINE_ACTIVE"
                        ? "bg-slate-800 hover:bg-rose-950/60 hover:text-rose-300 text-slate-300"
                        : "bg-emerald-950/60 text-emerald-300 hover:bg-emerald-900/60"
                    }`}
                    title="Simulate rail circuit breaker failover"
                  >
                    {rail.status === "ONLINE_ACTIVE" ? "Test Trip" : "Restore"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 3: DISPATCH & ROUTE TRANSFER ORDER
      ========================================================================= */}
      {activeTab === "dispatch" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Order Submission Form */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Send className="w-4 h-4 text-sky-400" />
                <span>Submit Transfer Order to API Gateway</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                The gateway traffic controller will validate payload schema, apply dynamic rate-limit
                throttling, and select the optimal payment rail.
              </p>
            </div>

            <form onSubmit={handleDispatchOrder} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono block mb-1">
                    Amount
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={orderAmount}
                    onChange={(e) => setOrderAmount(e.target.value)}
                    required
                    placeholder="e.g. 15000"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-sm focus:border-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono block mb-1">
                    Currency
                  </label>
                  <select
                    value={orderCurrency}
                    onChange={(e) => setOrderCurrency(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-sm focus:border-sky-500 focus:outline-none"
                  >
                    <option value="USD">USD (FedNow / RTP / Fedwire)</option>
                    <option value="EUR">EUR (SEPA Instant / SCT)</option>
                    <option value="GBP">GBP (UK Faster Payments)</option>
                    <option value="NGN">NGN (NIBSS Instant / Paystack)</option>
                    <option value="BTC">BTC (BlockCypher / Mempool)</option>
                    <option value="SATS">SATS (Lightning Network)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono block mb-1">
                  Recipient Legal Name
                </label>
                <input
                  type="text"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  required
                  placeholder="e.g. George Felix Egwu"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono block mb-1">
                    Account / Wallet / IBAN
                  </label>
                  <input
                    type="text"
                    value={recipientAccount}
                    onChange={(e) => setRecipientAccount(e.target.value)}
                    required
                    placeholder="e.g. 0847920194"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono text-sm focus:border-sky-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono block mb-1">
                    Destination Bank / Rail
                  </label>
                  <input
                    type="text"
                    value={destinationBank}
                    onChange={(e) => setDestinationBank(e.target.value)}
                    placeholder="e.g. JPMorgan Chase Bank"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm focus:border-sky-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono block mb-1">
                  Traffic Priority Level
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(["CRITICAL_FINANCIAL", "STANDARD_API", "BACKGROUND_BATCH"] as TrafficPriority[]).map(
                    (p) => (
                      <button
                        key={p}
                        type="button"
                        onClick={() => setOrderPriority(p)}
                        className={`p-2 rounded-xl text-center font-mono text-[11px] border transition-all cursor-pointer ${
                          orderPriority === p
                            ? "bg-sky-600 text-white border-sky-400 font-bold shadow-md"
                            : "bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200"
                        }`}
                      >
                        {p.replace("_", " ")}
                      </button>
                    )
                  )}
                </div>
              </div>

              {dispatchError && (
                <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/50 text-rose-300 text-xs font-mono flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold">Validation / Throttling Error:</div>
                    <div>{dispatchError}</div>
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={isDispatching}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-sky-600 via-indigo-600 to-emerald-600 hover:from-sky-500 hover:to-emerald-500 text-white text-sm font-extrabold shadow-xl shadow-sky-950/70 border border-sky-400/30 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.99] disabled:opacity-50"
              >
                {isDispatching ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Processing Payload &amp; Routing...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Dispatch Transfer Order</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>

          {/* Result / Routing Receipt Display */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FileCheck className="w-4 h-4 text-emerald-400" />
                  <span>Gateway Routing Receipt &amp; Telemetry</span>
                </h3>
                {lastDispatchedOrder && (
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    SETTLED INSTANT
                  </span>
                )}
              </div>

              {lastDispatchedOrder ? (
                <div className="space-y-3 font-mono text-xs">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                    <div className="flex justify-between text-slate-400">
                      <span>Tracking ID:</span>
                      <span className="text-sky-400 font-bold">
                        {lastDispatchedOrder.trackingNumber}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Amount Routed:</span>
                      <span className="text-emerald-400 font-bold">
                        {lastDispatchedOrder.amount.toLocaleString()}{" "}
                        {lastDispatchedOrder.currency}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Selected Payment Rail:</span>
                      <span className="text-indigo-300 font-bold">
                        {lastDispatchedOrder.railName}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Rail Identifier:</span>
                      <span className="text-slate-300">{lastDispatchedOrder.selectedRail}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Settlement SLA:</span>
                      <span className="text-emerald-300">
                        {lastDispatchedOrder.estimatedSettlement}
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Routing Latency:</span>
                      <span className="text-sky-300">{lastDispatchedOrder.latencyMs} ms</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Gateway Fee:</span>
                      <span className="text-slate-300">
                        ${(lastDispatchedOrder?.fee ?? 0).toFixed(2)}
                      </span>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-slate-400 block text-[10px] uppercase tracking-wider">
                      Routing Decision Rationale
                    </span>
                    <p className="text-slate-200 text-xs font-sans leading-relaxed">
                      {lastDispatchedOrder.routingReason}
                    </p>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                    <span className="text-slate-400 block text-[10px] uppercase tracking-wider">
                      Cryptographic Settlement Receipt
                    </span>
                    <div className="text-emerald-400 font-mono text-[10.5px] break-all">
                      {lastDispatchedOrder.cryptographicReceipt}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-20 text-slate-400 space-y-2">
                  <Server className="w-10 h-10 text-slate-600 mx-auto" />
                  <div className="text-sm font-medium">No order dispatched in this turn yet.</div>
                  <div className="text-xs text-slate-500">
                    Fill out the form on the left to dispatch an order and view instant payment rail
                    routing telemetry.
                  </div>
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800 text-[11px] font-mono text-slate-500 flex items-center justify-between">
              <span>Zero-Loss Guarantee</span>
              <span>Idempotency Deduplication Enabled</span>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 4: PAYLOAD SCHEMA VALIDATOR LAB
      ========================================================================= */}
      {activeTab === "validator" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Code2 className="w-4 h-4 text-emerald-400" />
                <span>JSON Request Payload Schema Tester</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Directly submit arbitrary JSON payloads to test strict validation rules, bound checks,
                and currency whitelist validation.
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-mono text-slate-300 block">
                Edit Request Body (JSON):
              </label>
              <textarea
                value={customJsonPayload}
                onChange={(e) => setCustomJsonPayload(e.target.value)}
                rows={12}
                className="w-full p-4 rounded-xl bg-slate-950 border border-slate-700 text-sky-300 font-mono text-xs focus:border-emerald-500 focus:outline-none"
                spellCheck={false}
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleValidatePayload}
                disabled={isValidating}
                className="flex-1 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-2 cursor-pointer transition-all shadow-lg shadow-emerald-950/60"
              >
                {isValidating ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Validating...</span>
                  </>
                ) : (
                  <>
                    <FileCheck className="w-3.5 h-3.5" />
                    <span>Validate Payload Schema</span>
                  </>
                )}
              </button>

              <button
                onClick={() =>
                  setCustomJsonPayload(
                    JSON.stringify(
                      {
                        amount: -10,
                        currency: "INVALID_COIN",
                        recipientName: "",
                        recipientAccount: "",
                      },
                      null,
                      2
                    )
                  )
                }
                className="px-4 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono cursor-pointer"
              >
                Load Invalid Sample
              </button>
            </div>
          </div>

          {/* Validation Diagnostics Output */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-sky-400" />
              <span>Gateway Validation Response</span>
            </h3>

            {validationResult ? (
              <div className="space-y-3 font-mono text-xs">
                <div
                  className={`p-3 rounded-xl border flex items-center justify-between ${
                    validationResult.success
                      ? "bg-emerald-950/50 border-emerald-500/40 text-emerald-300"
                      : "bg-rose-950/50 border-rose-500/40 text-rose-300"
                  }`}
                >
                  <span className="font-bold flex items-center gap-2">
                    {validationResult.success ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-rose-400" />
                    )}
                    {validationResult.success ? "SCHEMA VALID" : "VALIDATION FAILED"}
                  </span>
                  <span>{validationResult.error || "200 OK"}</span>
                </div>

                {validationResult.errors && (
                  <div className="space-y-1.5">
                    <span className="text-xs text-slate-400 block font-bold">Field-Level Errors:</span>
                    {validationResult.errors.map((err: any, idx: number) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-rose-950/40 border border-rose-500/30 text-rose-300 text-[11px]"
                      >
                        <span className="font-bold text-rose-200">[{err.field}]:</span>{" "}
                        {err.message}
                      </div>
                    ))}
                  </div>
                )}

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  <span className="text-slate-400 block text-[10px] uppercase">
                    Raw Gateway Response
                  </span>
                  <pre className="text-sky-300 text-[11px] overflow-x-auto max-h-60">
                    {JSON.stringify(validationResult, null, 2)}
                  </pre>
                </div>
              </div>
            ) : (
              <div className="text-center py-20 text-slate-400 space-y-2">
                <FileCheck className="w-10 h-10 text-slate-600 mx-auto" />
                <div className="text-sm font-medium">No payload tested yet.</div>
                <div className="text-xs text-slate-500">
                  Click "Validate Payload Schema" to execute gateway validation against the input.
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB 5: ROUTED ORDERS LEDGER
      ========================================================================= */}
      {activeTab === "orders" && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Database className="w-4 h-4 text-sky-400" />
                <span>Routed Transfer Orders Ledger</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Cryptographic audit trail of all transfer orders processed through the API Gateway
                and dispatched across payment rails.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={orderSearchQuery}
                  onChange={(e) => setOrderSearchQuery(e.target.value)}
                  placeholder="Search orders..."
                  className="pl-8 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 w-44"
                />
              </div>

              <select
                value={selectedRailFilter}
                onChange={(e) => setSelectedRailFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white font-mono focus:outline-none"
              >
                <option value="ALL">All Rails</option>
                <option value="FEDNOW_RTP_US">FedNow / RTP</option>
                <option value="ACH_FEDWIRE_US">Fedwire</option>
                <option value="SEPA_INSTANT_EU">SEPA Instant</option>
                <option value="FASTER_PAYMENTS_UK">UK FPS</option>
                <option value="NIP_PAYSTACK_NIGERIA">NIP / Paystack</option>
                <option value="BITCOIN_BLOCKCYPHER">Bitcoin</option>
                <option value="LIGHTNING_NETWORK">Lightning</option>
                <option value="VISA_MASTERCARD_PUSH">Visa / Mastercard</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase">
                  <th className="py-2.5 px-3">Tracking ID</th>
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3">Recipient</th>
                  <th className="py-2.5 px-3">Amount</th>
                  <th className="py-2.5 px-3">Selected Rail</th>
                  <th className="py-2.5 px-3">SLA / Status</th>
                  <th className="py-2.5 px-3 text-right">Latency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredOrders.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-12 text-slate-500">
                      No matching transfer orders in registry.
                    </td>
                  </tr>
                ) : (
                  filteredOrders.map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-850/50 transition-colors">
                      <td className="py-3 px-3 text-sky-400 font-bold">{ord.trackingNumber}</td>
                      <td className="py-3 px-3 text-slate-400 text-[11px]">
                        {new Date(ord.timestamp).toLocaleTimeString()}
                      </td>
                      <td className="py-3 px-3">
                        <div className="text-slate-200 font-sans font-medium">
                          {ord.recipientName}
                        </div>
                        <div className="text-[10px] text-slate-500">{ord.recipientAccount}</div>
                      </td>
                      <td className="py-3 px-3 text-emerald-400 font-bold">
                        {ord.amount.toLocaleString()} {ord.currency}
                      </td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[10.5px] bg-indigo-950/70 border border-indigo-500/30 text-indigo-300">
                          {ord.railName}
                        </span>
                      </td>
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          {ord.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right text-slate-300">{ord.latencyMs} ms</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
