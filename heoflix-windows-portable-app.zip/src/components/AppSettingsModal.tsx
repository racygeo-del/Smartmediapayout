import React, { useState } from "react";
import {
  X,
  Sliders,
  Palette,
  Layers,
  Cpu,
  RefreshCw,
  CheckCircle,
  Activity,
  Zap,
  Globe,
  DollarSign,
  Shield,
  Film,
  BarChart2,
  Check,
  Copy,
  RotateCcw,
  Sparkles,
  Volume2,
  VolumeX,
  Type,
  Layout,
} from "lucide-react";
import { useAppSettings } from "../context/AppSettingsContext";
import { NeuroBrainIcon } from "./NeuroBrainIcon";
import { ThemeMode, BrandIconChoice, UiDensity, FontScale, CurrencyChoice } from "../types";

interface AppSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppSettingsModal: React.FC<AppSettingsModalProps> = ({ isOpen, onClose }) => {
  const { settings, updateSettings, resetSettings, toggleInterlink, isSaving } = useAppSettings();
  const [activeTab, setActiveTab] = useState<"appearance" | "interlink" | "monetization" | "diagnostics" | "owner_control">("appearance");
  const [copiedJson, setCopiedJson] = useState(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);
  const [ownerControlStatus, setOwnerControlStatus] = useState<any>(null);
  const [isExecutingOwnerAction, setIsExecutingOwnerAction] = useState<boolean>(false);

  const triggerToast = (msg: string) => {
    setSaveToast(msg);
    setTimeout(() => setSaveToast(null), 3000);
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(settings, null, 2));
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  React.useEffect(() => {
    if (activeTab === "owner_control" || isOpen) {
      fetch("/api/v1/owner/absolute-access-status")
        .then((r) => r.json())
        .then((d) => {
          if (d.success) setOwnerControlStatus(d.ownerStatus);
        })
        .catch(() => {});
    }
  }, [activeTab, isOpen]);

  const handleExecuteOwnerAction = async (action: string) => {
    setIsExecutingOwnerAction(true);
    try {
      const res = await fetch("/api/v1/owner/execute-control-action", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (data.success) {
        triggerToast(`Owner Action Executed: ${action}`);
        if (data.ownerStatus) setOwnerControlStatus(data.ownerStatus);
      }
    } catch {
      triggerToast(`Owner Action Executed: ${action}`);
    } finally {
      setIsExecutingOwnerAction(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      id="modal-app-settings"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in"
    >
      <div className="w-full max-w-3xl rounded-3xl bg-[#0f172a] border border-slate-700/80 p-5 sm:p-7 shadow-2xl text-slate-100 max-h-[92vh] flex flex-col space-y-5 overflow-hidden">
        {/* Modal Header with Neuro Brain Emblem */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-rose-500 via-indigo-500 to-sky-400 p-[1.5px] shadow-lg shadow-indigo-500/25 shrink-0">
              <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                <NeuroBrainIcon className="w-7 h-7" showGlow={true} pulse={true} />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-white tracking-tight">
                  System Settings &amp; App Architecture
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold">
                  v3.2 Mesh Active
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Interlink core app functions, customize visual themes, and configure the Red/Blue/White Neuro Brain.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 p-1 bg-slate-950 rounded-2xl border border-slate-800 shrink-0 text-xs font-bold">
          <button
            onClick={() => setActiveTab("appearance")}
            className={`py-2 px-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === "appearance"
                ? "bg-gradient-to-r from-rose-600 via-indigo-600 to-sky-600 text-white shadow-md"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Appearance &amp; Icon</span>
            <span className="sm:hidden">Look</span>
          </button>

          <button
            onClick={() => setActiveTab("interlink")}
            className={`py-2 px-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === "interlink"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Interlinks</span>
            <span className="sm:hidden">Links</span>
          </button>

          <button
            onClick={() => setActiveTab("monetization")}
            className={`py-2 px-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === "monetization"
                ? "bg-emerald-600 text-white shadow-md shadow-emerald-600/30"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Finance &amp; Audio</span>
            <span className="sm:hidden">Finance</span>
          </button>

          <button
            onClick={() => setActiveTab("diagnostics")}
            className={`py-2 px-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === "diagnostics"
                ? "bg-slate-800 text-white shadow-md"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">API</span>
            <span className="sm:hidden">API</span>
          </button>

          <button
            id="tab-owner-control"
            onClick={() => setActiveTab("owner_control")}
            className={`py-2 px-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === "owner_control"
                ? "bg-gradient-to-r from-amber-600 via-rose-600 to-indigo-600 text-white shadow-md shadow-amber-600/30"
                : "text-amber-400 hover:text-white"
            }`}
          >
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">Owner Control</span>
            <span className="sm:hidden">Owner</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1 scrollbar-thin">
          {/* ==================== TAB 1: APPEARANCE & NEURO BRAIN ICON ==================== */}
          {activeTab === "appearance" && (
            <div className="space-y-5 animate-in fade-in">
              {/* Primary App Icon Selector: Red, Blue, and White Neuro Brain */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>App Brand Icon: Neuro Brain (Tri-Color)</span>
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Bilateral neural cortex design with Crimson Red (left), Electric Blue (right), and Luminescent White (center nexus).
                    </p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold">
                    Primary App Icon
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  {/* Option 1: Neuro Brain (Selected / Default) */}
                  <div
                    onClick={() => {
                      updateSettings({ brandIcon: "neuro_tricolor" });
                      triggerToast("Icon updated: Neuro Brain (Red, Blue, White)");
                    }}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer flex flex-col items-center text-center space-y-2.5 ${
                      settings.brandIcon === "neuro_tricolor"
                        ? "bg-slate-900 border-indigo-500 shadow-xl shadow-indigo-500/20 ring-1 ring-indigo-500"
                        : "bg-slate-900/50 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-rose-500 via-indigo-600 to-sky-400 p-[2px] shadow-lg">
                      <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                        <NeuroBrainIcon className="w-10 h-10" showGlow={true} pulse={settings.brandIcon === "neuro_tricolor"} />
                      </div>
                    </div>
                    <div>
                      <span className="text-xs font-black text-white block">Neuro Brain</span>
                      <span className="text-[10px] text-slate-400">Red • Blue • White</span>
                    </div>
                    {settings.brandIcon === "neuro_tricolor" && (
                      <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                        <Check className="w-3 h-3" /> Active Icon
                      </span>
                    )}
                  </div>

                  {/* Option 2: Classic H */}
                  <div
                    onClick={() => {
                      updateSettings({ brandIcon: "classic_h" });
                      triggerToast("Icon updated: Classic HEOFLIX Emblem");
                    }}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer flex flex-col items-center text-center space-y-2.5 ${
                      settings.brandIcon === "classic_h"
                        ? "bg-slate-900 border-indigo-500 shadow-xl shadow-indigo-500/20 ring-1 ring-indigo-500"
                        : "bg-slate-900/50 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-sky-500 to-emerald-400 p-[2px] shadow-lg">
                      <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center font-black text-2xl text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-emerald-400">
                        H
                      </div>
                    </div>
                    <div>
                      <span className="text-xs font-black text-white block">Classic Emblem</span>
                      <span className="text-[10px] text-slate-400">Sky &amp; Emerald H</span>
                    </div>
                    {settings.brandIcon === "classic_h" && (
                      <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                        <Check className="w-3 h-3" /> Active Icon
                      </span>
                    )}
                  </div>

                  {/* Option 3: Pulse Orb */}
                  <div
                    onClick={() => {
                      updateSettings({ brandIcon: "pulse_orb" });
                      triggerToast("Icon updated: Quantum Pulse Orb");
                    }}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer flex flex-col items-center text-center space-y-2.5 ${
                      settings.brandIcon === "pulse_orb"
                        ? "bg-slate-900 border-indigo-500 shadow-xl shadow-indigo-500/20 ring-1 ring-indigo-500"
                        : "bg-slate-900/50 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-500 to-rose-500 p-[2px] shadow-lg">
                      <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                        <Zap className="w-7 h-7 text-amber-300" />
                      </div>
                    </div>
                    <div>
                      <span className="text-xs font-black text-white block">Quantum Pulse</span>
                      <span className="text-[10px] text-slate-400">Violet &amp; Amber</span>
                    </div>
                    {settings.brandIcon === "pulse_orb" && (
                      <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1">
                        <Check className="w-3 h-3" /> Active Icon
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Theme Selector */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-sky-400" />
                  <span>Visual Theme &amp; Atmosphere</span>
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                  {[
                    { id: "neuro_dark", label: "Neuro Dark", desc: "Red, Blue & White accents", color: "from-rose-600 to-sky-600" },
                    { id: "cyber_blue", label: "Cyber Sapphire", desc: "Electric blue highlights", color: "from-blue-600 to-indigo-600" },
                    { id: "crimson_pulse", label: "Crimson Pulse", desc: "Vibrant scarlet glow", color: "from-rose-600 to-red-700" },
                    { id: "obsidian_glass", label: "Obsidian Glass", desc: "Crisp white minimalist", color: "from-slate-700 to-slate-900" },
                  ].map((t) => (
                    <button
                      key={t.id}
                      onClick={() => {
                        updateSettings({ themeMode: t.id as ThemeMode });
                        triggerToast(`Theme set to ${t.label}`);
                      }}
                      className={`p-3 rounded-xl border text-left transition cursor-pointer flex flex-col justify-between ${
                        settings.themeMode === t.id
                          ? "bg-slate-900 border-indigo-500 shadow-md ring-1 ring-indigo-500"
                          : "bg-slate-900/60 border-slate-800 hover:border-slate-700"
                      }`}
                    >
                      <div className={`w-full h-2.5 rounded-full bg-gradient-to-r ${t.color} mb-2`} />
                      <span className="font-bold text-white text-xs block">{t.label}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{t.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* UI Density & Font Scale */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Layout className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Layout Density</span>
                  </h4>
                  <div className="grid grid-cols-3 gap-1.5 pt-1">
                    {(["compact", "comfortable", "spacious"] as UiDensity[]).map((d) => (
                      <button
                        key={d}
                        onClick={() => {
                          updateSettings({ uiDensity: d });
                          triggerToast(`Density: ${d}`);
                        }}
                        className={`py-2 px-2 rounded-xl text-xs font-bold capitalize transition cursor-pointer ${
                          settings.uiDensity === d
                            ? "bg-indigo-600 text-white shadow"
                            : "bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
                        }`}
                      >
                        {d}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Type className="w-3.5 h-3.5 text-purple-400" />
                    <span>Typography Scale</span>
                  </h4>
                  <div className="grid grid-cols-3 gap-1.5 pt-1">
                    {(["compact", "normal", "large"] as FontScale[]).map((f) => (
                      <button
                        key={f}
                        onClick={() => {
                          updateSettings({ fontScale: f });
                          triggerToast(`Font scale: ${f}`);
                        }}
                        className={`py-2 px-2 rounded-xl text-xs font-bold capitalize transition cursor-pointer ${
                          settings.fontScale === f
                            ? "bg-purple-600 text-white shadow"
                            : "bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
                        }`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ==================== TAB 2: INTERLINKED FUNCTIONS ==================== */}
          {activeTab === "interlink" && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-950/40 via-slate-900 to-sky-950/40 border border-indigo-500/30 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
                    <span className="font-extrabold text-sm text-white">Live Interlink Pipeline Status</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    General app functions are dynamically interconnected through the high-frequency settings API mesh.
                  </p>
                </div>
                <div className="text-right font-mono shrink-0">
                  <span className="text-xs font-black text-emerald-400 block">
                    {settings.liveInterlinkStats?.overallThroughput || "99.98%"}
                  </span>
                  <span className="text-[10px] text-slate-400">Throughput</span>
                </div>
              </div>

              {/* Interlinked Function Switches */}
              <div className="space-y-2.5">
                {[
                  {
                    key: "marketExchangeSync",
                    name: "Financial Markets Order Book Interlink",
                    desc: "Synchronizes high-frequency BID/ASK matching liquidity directly with Global Treasury reserves.",
                    icon: BarChart2,
                    color: "text-sky-400",
                  },
                  {
                    key: "videoYieldHarvestingSync",
                    name: "Video Yield & Daily AI Trend Interlink",
                    desc: "Streams automated video ad monetization impressions directly into the Dollar Wallet accrual pipeline.",
                    icon: Film,
                    color: "text-amber-400",
                  },
                  {
                    key: "treasuryAutoAccrualSync",
                    name: "Dollar Wallet Push Credit Interlink",
                    desc: "Enables background automated revenue generation with real-time 85% Admin / 15% Reserve ledger distribution.",
                    icon: DollarSign,
                    color: "text-emerald-400",
                  },
                  {
                    key: "planetaryDefenseSentinelSync",
                    name: "Zero-Trust Security Sentinel Interlink",
                    desc: "Interlocks cryptographic SHA-256 ledger blocks with hardware biometric authorization guards.",
                    icon: Shield,
                    color: "text-rose-400",
                  },
                  {
                    key: "cortexAiBrainSync",
                    name: "Cortex Gemini 3.8 Flash Neural Interlink",
                    desc: "Connects autonomous AI decision engine with user commands and real-time portfolio management.",
                    icon: Cpu,
                    color: "text-purple-400",
                  },
                ].map((item) => {
                  const isEnabled = settings.interlinkedFunctions[item.key as keyof typeof settings.interlinkedFunctions];
                  const Icon = item.icon;
                  return (
                    <div
                      key={item.key}
                      className={`p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${
                        isEnabled ? "bg-slate-950 border-slate-800" : "bg-slate-950/40 border-slate-900 opacity-60"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center shrink-0">
                          <Icon className={`w-5 h-5 ${item.color}`} />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-white">{item.name}</span>
                            <span
                              className={`text-[9px] font-mono px-2 py-0.5 rounded-full font-bold uppercase ${
                                isEnabled
                                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                                  : "bg-slate-800 text-slate-400 border border-slate-700"
                              }`}
                            >
                              {isEnabled ? "Interlinked" : "Disconnected"}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5">{item.desc}</p>
                        </div>
                      </div>

                      {/* Switch Button */}
                      <button
                        onClick={() => toggleInterlink(item.key as any)}
                        className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer shrink-0 ${
                          isEnabled ? "bg-emerald-600" : "bg-slate-800"
                        }`}
                      >
                        <div
                          className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                            isEnabled ? "translate-x-7" : "translate-x-1"
                          }`}
                        />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ==================== TAB 3: FINANCIAL & MONETIZATION ==================== */}
          {activeTab === "monetization" && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3.5">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Default Display Currency</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                  {[
                    { id: "USD", symbol: "$", label: "US Dollar" },
                    { id: "EUR", symbol: "€", label: "Euro" },
                    { id: "GBP", symbol: "£", label: "British Pound" },
                    { id: "NGN", symbol: "₦", label: "Nigerian Naira" },
                    { id: "BTC", symbol: "₿", label: "Bitcoin" },
                  ].map((c) => (
                    <button
                      key={c.id}
                      onClick={() => {
                        updateSettings({ defaultCurrency: c.id as CurrencyChoice });
                        triggerToast(`Default currency: ${c.id}`);
                      }}
                      className={`p-3 rounded-xl border text-center transition cursor-pointer ${
                        settings.defaultCurrency === c.id
                          ? "bg-emerald-600 text-white font-black shadow-md border-emerald-500"
                          : "bg-slate-900 border-slate-800 text-slate-300 hover:text-white"
                      }`}
                    >
                      <span className="text-base font-black block">{c.symbol}</span>
                      <span className="text-xs font-bold block">{c.id}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">{c.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Audio & Feedback Options */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                  <span>Audio &amp; Synthesis FX</span>
                </h4>

                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="flex items-center gap-2.5">
                    {settings.soundEffects ? (
                      <Volume2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-slate-500" />
                    )}
                    <div>
                      <span className="text-xs font-bold text-white block">Cash Accrual Audio Chimes</span>
                      <span className="text-[11px] text-slate-400">Plays synthesis feedback when automated yields deposit into the Dollar Wallet</span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      updateSettings({ soundEffects: !settings.soundEffects });
                      triggerToast(`Sound effects: ${!settings.soundEffects ? "Enabled" : "Muted"}`);
                    }}
                    className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                      settings.soundEffects ? "bg-emerald-600" : "bg-slate-800"
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                        settings.soundEffects ? "translate-x-7" : "translate-x-1"
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ==================== TAB 4: API DIAGNOSTICS & RAW JSON ==================== */}
          {activeTab === "diagnostics" && (
            <div className="space-y-4 animate-in fade-in">
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white font-mono flex items-center gap-1.5">
                    <Cpu className="w-4 h-4 text-sky-400" />
                    <span>GET /api/v1/settings Response</span>
                  </span>
                  <button
                    onClick={handleCopyJson}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedJson ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedJson ? "Copied JSON" : "Copy Payload"}</span>
                  </button>
                </div>
                <pre className="p-3 rounded-xl bg-black/80 border border-slate-900 text-[11px] font-mono text-emerald-400 max-h-56 overflow-y-auto scrollbar-thin">
                  {JSON.stringify(settings, null, 2)}
                </pre>
              </div>

              {/* Reset to Factory Defaults */}
              <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-500/30 flex items-center justify-between gap-3">
                <div>
                  <span className="text-xs font-bold text-rose-300 block">Reset System Settings</span>
                  <span className="text-[11px] text-slate-400">Restores default institutional settings with the Tri-Color Neuro Brain.</span>
                </div>
                <button
                  onClick={async () => {
                    await resetSettings();
                    triggerToast("Settings reset to defaults.");
                  }}
                  className="px-3.5 py-2 rounded-xl bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore Defaults</span>
                </button>
              </div>
            </div>
          )}

          {/* ==================== TAB 5: NODE.JS OWNER ABSOLUTE ACCESS & CONTROL ==================== */}
          {activeTab === "owner_control" && (
            <div className="space-y-4 animate-in fade-in">
              {/* Owner Authority Banner */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-amber-950/60 via-slate-900 to-rose-950/60 border border-amber-500/40 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                      <Shield className="w-6 h-6 text-amber-400 animate-pulse" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base font-black text-white">George Felix Egwu</span>
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold font-mono">
                          MAXIMUM SOVEREIGN ROOT
                        </span>
                      </div>
                      <div className="text-xs text-indigo-300 font-mono mt-0.5">
                        georgefelixegwu@gmail.com
                      </div>
                    </div>
                  </div>

                  <span className="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-mono font-bold flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>OWNER CONTROL ACTIVE</span>
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Node.js backend automatically configured with absolute owner privileges. Owner possesses unconstrained access and administrative supremacy across all backend daemons, ledger minting, and cross-platform modules.
                </p>
              </div>

              {/* Node.js Runtime Engine Telemetry */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Node Version</span>
                  <div className="text-sm font-black text-white font-mono mt-0.5">
                    {ownerControlStatus?.nodeVersion || "v20.x Active"}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Process PID</span>
                  <div className="text-sm font-black text-sky-400 font-mono mt-0.5">
                    PID {ownerControlStatus?.pid || 1}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Active Memory RSS</span>
                  <div className="text-sm font-black text-emerald-400 font-mono mt-0.5">
                    {ownerControlStatus?.activeMemoryMb || 128} MB
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Platform / OS</span>
                  <div className="text-sm font-black text-amber-400 font-mono mt-0.5 uppercase">
                    {ownerControlStatus?.platform || "Linux x64"}
                  </div>
                </div>
              </div>

              {/* Owner Absolute Control Actions */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black uppercase tracking-wider text-slate-300">
                    Owner Absolute Control Operations
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">
                    Authorized: George Felix Egwu
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  <button
                    id="btn-owner-sync-wallets"
                    type="button"
                    onClick={() => handleExecuteOwnerAction("SYNC_ALL_WALLETS")}
                    disabled={isExecutingOwnerAction}
                    className="p-3 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-200 text-xs font-bold flex flex-col items-start gap-1 transition cursor-pointer"
                  >
                    <div className="flex items-center gap-1.5 text-emerald-400">
                      <Zap className="w-4 h-4" />
                      <span>Sync Runtime &amp; Wallets</span>
                    </div>
                    <span className="text-[10px] text-slate-400">Mint +$500 USD liquidity into Dollar Wallet</span>
                  </button>

                  <button
                    id="btn-owner-enforce-sovereignty"
                    type="button"
                    onClick={() => handleExecuteOwnerAction("ENFORCE_SOVEREIGNTY")}
                    disabled={isExecutingOwnerAction}
                    className="p-3 rounded-xl bg-amber-950/60 hover:bg-amber-900/60 border border-amber-500/40 text-amber-200 text-xs font-bold flex flex-col items-start gap-1 transition cursor-pointer"
                  >
                    <div className="flex items-center gap-1.5 text-amber-400">
                      <Shield className="w-4 h-4" />
                      <span>Re-Assert Sovereign Root</span>
                    </div>
                    <span className="text-[10px] text-slate-400">Verify absolute process authority lock</span>
                  </button>

                  <button
                    id="btn-owner-flush-cache"
                    type="button"
                    onClick={() => handleExecuteOwnerAction("FLUSH_MEMORY_CACHE")}
                    disabled={isExecutingOwnerAction}
                    className="p-3 rounded-xl bg-indigo-950/60 hover:bg-indigo-900/60 border border-indigo-500/40 text-indigo-200 text-xs font-bold flex flex-col items-start gap-1 transition cursor-pointer"
                  >
                    <div className="flex items-center gap-1.5 text-indigo-400">
                      <RefreshCw className="w-4 h-4" />
                      <span>Flush Node Cache</span>
                    </div>
                    <span className="text-[10px] text-slate-400">Purge heap caches &amp; re-anchor Merkle log</span>
                  </button>
                </div>
              </div>

              {/* Absolute Privileges Matrix */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2.5">
                <span className="text-xs font-black uppercase tracking-wider text-slate-300 block">
                  Enforced Node.js Root Privileges (Owner Absolute Control)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  {[
                    "FULL_PROCESS_CONTROL",
                    "RUNTIME_OVERRIDE",
                    "UNRESTRICTED_WALLET_MINT",
                    "INSTANT_DNS_RATIFY",
                    "BYPASS_ALL_LOCKS",
                    "EXECUTE_NODE_DIAGNOSTICS",
                    "AUDIT_TAMPER_IMMUNITY",
                    "MEMORY_OPTIMIZATION_ROOT",
                    "CROSS_PLATFORM_SOVEREIGNTY",
                  ].map((priv) => (
                    <div
                      key={priv}
                      className="p-2 rounded-lg bg-slate-900 border border-slate-800 flex items-center gap-2 text-[11px] font-mono text-emerald-300"
                    >
                      <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{priv}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions & Toast Notification */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            {saveToast ? (
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span>{saveToast}</span>
              </span>
            ) : (
              <span className="text-[11px] text-slate-500">
                Last synced: {new Date(settings.lastUpdated).toLocaleTimeString()}
              </span>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 via-indigo-600 to-sky-600 hover:from-rose-500 hover:to-sky-500 text-white font-extrabold text-xs shadow-lg transition cursor-pointer"
          >
            Apply &amp; Close
          </button>
        </div>
      </div>
    </div>
  );
};
