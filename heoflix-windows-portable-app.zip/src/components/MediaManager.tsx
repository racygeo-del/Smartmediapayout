import React, { useState, useEffect } from "react";
import { VideoContent, SocialPlatform, TrendingAiVideo } from "../types";
import { safeParseResponse } from "../utils/api";
import {
  Film,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Shuffle,
  Repeat,
  ListMusic,
  Volume2,
  Star,
  Plus,
  Rss,
  ExternalLink,
  Trash2,
  Sparkles,
  BarChart2,
  Clock,
  Eye,
  Heart,
  MessageCircle,
  Share2,
  CheckCircle2,
  AlertCircle,
  Search,
  Filter,
  Copy,
  Check,
  Radio,
  Tv,
  Flame,
} from "lucide-react";
import { DailyAiTrendMonitorModal } from "./DailyAiTrendMonitorModal";

interface MediaManagerProps {
  videos: VideoContent[];
  platforms: SocialPlatform[];
  onRefreshData: () => void;
  onNavigateToAnalytics: (videoId: string) => void;
  onOpenSecurityModal?: (actionName: string) => void;
}

export const MediaManager: React.FC<MediaManagerProps> = ({
  videos,
  platforms,
  onRefreshData,
  onNavigateToAnalytics,
}) => {
  // State for spotlight video
  const favoriteVideo = videos.find((v) => v.isFavorite) || videos[0] || null;
  const [activePlayerVideo, setActivePlayerVideo] = useState<VideoContent | null>(favoriteVideo);

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedPlatform, setSelectedPlatform] = useState<string>("ALL");

  // Import Modal States
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importMode, setImportMode] = useState<"URL" | "RSS">("URL");
  const [isAiTrendModalOpen, setIsAiTrendModalOpen] = useState(false);

  // Form states for URL import
  const [inputUrl, setInputUrl] = useState("");
  const [inputTitle, setInputTitle] = useState("");
  const [inputPlatform, setInputPlatform] = useState<string>("youtube");
  const [inputDuration, setInputDuration] = useState("10:00");
  const [inputTopic, setInputTopic] = useState("Creator Economy & FinTech");
  const [setAsFavoriteOnImport, setSetAsFavoriteOnImport] = useState(true);

  // Form states for RSS import
  const [rssUrl, setRssUrl] = useState("");
  const [presetFeed, setPresetFeed] = useState("creator_economy");

  // Status feedback
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Continuous Playlist & Queue States
  const [isPlaylistActive, setIsPlaylistActive] = useState(false);
  const [playlistVideos, setPlaylistVideos] = useState<VideoContent[]>(videos);
  const [currentPlaylistIndex, setCurrentPlaylistIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isShuffleEnabled, setIsShuffleEnabled] = useState(false);
  const [isLoopEnabled, setIsLoopEnabled] = useState(true);
  const [isAutoAdvanceEnabled, setIsAutoAdvanceEnabled] = useState(true);
  const [playlistCountdownSeconds, setPlaylistCountdownSeconds] = useState(30);
  const [showQueuePanel, setShowQueuePanel] = useState(true);

  // Sync playlistVideos when catalog updates if playlist is inactive
  useEffect(() => {
    if (!isPlaylistActive) {
      setPlaylistVideos(videos);
    }
  }, [videos, isPlaylistActive]);

  // Handle Play All Tracked Videos
  const handlePlayAllTracked = (customList?: VideoContent[], startIndex: number = 0) => {
    const listToPlay = customList && customList.length > 0 ? customList : (filteredVideos.length > 0 ? filteredVideos : videos);
    if (!listToPlay || listToPlay.length === 0) {
      showToast("No tracked videos available to play.", "error");
      return;
    }

    setPlaylistVideos(listToPlay);
    setCurrentPlaylistIndex(startIndex);
    setActivePlayerVideo(listToPlay[startIndex]);
    setIsPlaylistActive(true);
    setIsPlaying(true);
    setPlaylistCountdownSeconds(30);
    setShowQueuePanel(true);
    showToast(`Continuous Playlist: Playing ${listToPlay.length} Tracked Videos!`);

    const playerEl = document.getElementById("spotlight-media-player");
    if (playerEl) {
      playerEl.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleNextTrack = () => {
    if (!playlistVideos.length) return;
    let nextIdx: number;
    if (isShuffleEnabled && playlistVideos.length > 1) {
      nextIdx = Math.floor(Math.random() * playlistVideos.length);
      if (nextIdx === currentPlaylistIndex) {
        nextIdx = (nextIdx + 1) % playlistVideos.length;
      }
    } else {
      if (currentPlaylistIndex >= playlistVideos.length - 1) {
        if (isLoopEnabled) {
          nextIdx = 0;
        } else {
          setIsPlaying(false);
          showToast("Reached end of playlist.");
          return;
        }
      } else {
        nextIdx = currentPlaylistIndex + 1;
      }
    }

    setCurrentPlaylistIndex(nextIdx);
    setActivePlayerVideo(playlistVideos[nextIdx]);
    setPlaylistCountdownSeconds(30);
  };

  const handlePrevTrack = () => {
    if (!playlistVideos.length) return;
    const prevIdx = currentPlaylistIndex === 0 ? playlistVideos.length - 1 : currentPlaylistIndex - 1;
    setCurrentPlaylistIndex(prevIdx);
    setActivePlayerVideo(playlistVideos[prevIdx]);
    setPlaylistCountdownSeconds(30);
  };

  const handleJumpToTrack = (index: number) => {
    if (index >= 0 && index < playlistVideos.length) {
      setCurrentPlaylistIndex(index);
      setActivePlayerVideo(playlistVideos[index]);
      setIsPlaylistActive(true);
      setIsPlaying(true);
      setPlaylistCountdownSeconds(30);
    }
  };

  const handlePlayAllFromDailyTrends = (trends: TrendingAiVideo[]) => {
    if (!trends || trends.length === 0) return;
    const trendCatalogVideos: VideoContent[] = trends.map((t) => ({
      id: t.id,
      title: t.title,
      platform: t.platform,
      thumbnail: t.thumbnail,
      uploadDate: t.discoveredDate || new Date().toISOString().split("T")[0],
      duration: t.duration,
      views: t.views24h,
      likes: t.likes,
      comments: t.comments,
      shares: t.shares,
      retentionRate: t.retentionRate,
      hookScore: t.hookScore,
      sentiment: "Very Positive",
      revenueGenerated: t.projectedRevenue,
      topic: t.topic,
      videoUrl: t.videoUrl,
      embedUrl: t.embedUrl,
      cpm: t.cpm,
      verifiedAdPayout: t.projectedRevenue,
      importSource: "SYSTEM",
      notes: `Daily AI Trend Queue (#${t.aiTrendCategory})`,
    }));

    handlePlayAllTracked(trendCatalogVideos, 0);
  };

  // Auto-advance countdown timer
  useEffect(() => {
    let timer: any = null;
    if (isPlaylistActive && isPlaying && isAutoAdvanceEnabled) {
      timer = setInterval(() => {
        setPlaylistCountdownSeconds((prev) => {
          if (prev <= 1) {
            handleNextTrack();
            return 30;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isPlaylistActive, isPlaying, isAutoAdvanceEnabled, currentPlaylistIndex, playlistVideos.length, isShuffleEnabled, isLoopEnabled]);

  // Filtered list
  const filteredVideos = videos.filter((video) => {
    const matchesSearch =
      video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      video.topic.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPlatform = selectedPlatform === "ALL" || video.platform === selectedPlatform;
    return matchesSearch && matchesPlatform;
  });

  // Handle URL Import
  const handleImportUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUrl.trim() && !inputTitle.trim()) {
      showToast("Please provide a video URL or title.", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch("/api/v1/social/videos/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: inputUrl.trim(),
          title: inputTitle.trim() || undefined,
          platform: inputPlatform,
          duration: inputDuration,
          topic: inputTopic,
          isFavorite: setAsFavoriteOnImport,
        }),
      });

      const parsed = await safeParseResponse(res);
      if (parsed.ok && parsed.data?.success) {
        showToast(parsed.data.message || "Video imported successfully!");
        if (parsed.data.video && setAsFavoriteOnImport) {
          setActivePlayerVideo(parsed.data.video);
        }
        setIsImportModalOpen(false);
        setInputUrl("");
        setInputTitle("");
        onRefreshData();
      } else {
        showToast(parsed.error || parsed.data?.error || "Import failed.", "error");
      }
    } catch (err: any) {
      showToast(err.message || "Network error importing video", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle RSS Import
  const handleImportRss = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const res = await fetch("/api/v1/social/videos/import-rss", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          feedUrl: rssUrl.trim() || undefined,
          presetFeed,
        }),
      });

      const parsed = await safeParseResponse(res);
      if (parsed.ok && parsed.data?.success) {
        showToast(parsed.data.message || "Videos imported from RSS!");
        setIsImportModalOpen(false);
        setRssUrl("");
        onRefreshData();
      } else {
        showToast(parsed.error || parsed.data?.error || "RSS import failed.", "error");
      }
    } catch (err: any) {
      showToast(err.message || "Network error importing RSS feed", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Set as favorite video spotlight
  const handleSetFavorite = async (video: VideoContent) => {
    try {
      const res = await fetch(`/api/v1/social/videos/${video.id}/set-favorite`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const parsed = await safeParseResponse(res);
      if (parsed.ok && parsed.data?.success) {
        setActivePlayerVideo(video);
        showToast(`"${video.title.slice(0, 30)}..." set as Primary Favorite Spotlight!`);
        onRefreshData();
      } else {
        showToast(parsed.error || "Failed to update favorite video", "error");
      }
    } catch (err: any) {
      showToast(err.message || "Error updating favorite", "error");
    }
  };

  // Delete Video
  const handleDeleteVideo = async (videoId: string, title: string) => {
    if (!confirm(`Remove "${title}" from Media Manager?`)) return;

    try {
      const res = await fetch(`/api/v1/social/videos/${videoId}`, {
        method: "DELETE",
      });
      const parsed = await safeParseResponse(res);
      if (parsed.ok && parsed.data?.success) {
        showToast("Video removed from library.");
        if (activePlayerVideo?.id === videoId) {
          setActivePlayerVideo(null);
        }
        onRefreshData();
      } else {
        showToast(parsed.error || "Failed to delete video.", "error");
      }
    } catch (err: any) {
      showToast(err.message || "Error deleting video", "error");
    }
  };

  // Copy embed code
  const handleCopyEmbed = (video: VideoContent) => {
    const embedCode = `<iframe width="560" height="315" src="${video.embedUrl || video.videoUrl}" title="${video.title}" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>`;
    navigator.clipboard.writeText(embedCode);
    setCopiedId(video.id);
    showToast("Embed iframe code copied to clipboard!");
    setTimeout(() => setCopiedId(null), 2500);
  };

  // Choose which video to show in the player
  const currentVideo = activePlayerVideo || favoriteVideo || videos[0];

  return (
    <div className="space-y-6 animate-in fade-in duration-300 pb-12">
      {/* Toast Feedback */}
      {toastMessage && (
        <div
          className={`fixed top-20 right-6 z-50 rounded-2xl px-5 py-3 shadow-2xl text-xs font-bold flex items-center gap-2 border animate-in slide-in-from-top ${
            toastMessage.type === "success"
              ? "bg-emerald-950/90 text-emerald-200 border-emerald-500/40"
              : "bg-rose-950/90 text-rose-200 border-rose-500/40"
          }`}
        >
          {toastMessage.type === "success" ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400" />
          )}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-[#161f2e]/85 border border-slate-700/80 backdrop-blur-xl shadow-xl">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-500 via-indigo-600 to-emerald-400 p-0.5 shadow-lg shadow-indigo-500/20">
            <div className="w-full h-full bg-[#131926] rounded-[14px] flex items-center justify-center text-sky-400">
              <Film className="w-6 h-6" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black text-white tracking-tight">
                Media Manager & Video Importer
              </h1>
              <span className="px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20 text-[10px] font-extrabold uppercase tracking-wider">
                Full-Featured Software
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Import YouTube, Vimeo, RSS feeds, and embed your favorite social media video with high-definition playback
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            id="btn-play-all-tracked-videos-header"
            onClick={() => handlePlayAllTracked()}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-sky-500 hover:from-emerald-400 hover:to-sky-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition hover:scale-[1.02] cursor-pointer"
          >
            <Play className="w-4 h-4 fill-slate-950" />
            <span>Play All Tracked ({filteredVideos.length})</span>
          </button>

          <button
            id="btn-open-daily-ai-trend-monitor"
            onClick={() => setIsAiTrendModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-white font-extrabold text-xs flex items-center gap-2 shadow-lg shadow-rose-500/20 transition hover:scale-[1.02] cursor-pointer"
          >
            <Flame className="w-4 h-4 text-amber-300 animate-pulse" />
            <span>Daily AI Trend Radar</span>
          </button>

          <button
            onClick={() => {
              setImportMode("URL");
              setIsImportModalOpen(true);
            }}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition hover:scale-[1.02] cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Import Video URL</span>
          </button>

          <button
            onClick={() => {
              setImportMode("RSS");
              setIsImportModalOpen(true);
            }}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-bold text-xs flex items-center gap-2 transition hover:scale-[1.02] cursor-pointer"
          >
            <Rss className="w-4 h-4 text-amber-400" />
            <span>RSS Feed Importer</span>
          </button>
        </div>
      </div>

      {/* Daily AI Trending Video Radar Banner */}
      <div className="rounded-2xl border border-rose-500/40 bg-gradient-to-r from-rose-950/30 via-slate-900 to-indigo-950/30 p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500 to-amber-500 p-[1px] shadow-md shadow-rose-500/30 shrink-0">
            <div className="w-full h-full rounded-xl bg-slate-950 flex items-center justify-center">
              <Flame className="w-5 h-5 text-amber-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-white text-sm">
                Daily AI Trending Video Monitor &amp; Tracker
              </span>
              <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-bold border border-rose-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                Live 24h Scan Active
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Continuously monitoring viral AI videos across YouTube Shorts, TikTok, and Instagram with automated monetization yield harvesting.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 self-end sm:self-auto shrink-0">
          <button
            onClick={() => handlePlayAllTracked()}
            className="px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-slate-950" />
            <span>Play All Tracked</span>
          </button>

          <button
            onClick={() => setIsAiTrendModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-white font-extrabold text-xs shadow-md shadow-rose-500/20 transition flex items-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Track &amp; Add AI Trends</span>
          </button>
        </div>
      </div>

      {/* Primary Embedded Video Spotlight & Continuous Playlist Player */}
      {currentVideo && (
        <div id="spotlight-media-player" className="rounded-3xl border border-slate-700/80 bg-[#161f2e]/90 overflow-hidden shadow-2xl backdrop-blur-xl">
          {/* Playlist Control Header (Active when isPlaylistActive) */}
          {isPlaylistActive ? (
            <div className="p-3.5 sm:p-4 bg-slate-950 border-b border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="flex h-3 w-3 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-mono font-bold text-[10px] uppercase">
                      Track {currentPlaylistIndex + 1} of {playlistVideos.length}
                    </span>
                    <span className="text-xs font-bold text-white truncate max-w-xs sm:max-w-md">
                      {currentVideo.title}
                    </span>
                  </div>
                  {isAutoAdvanceEnabled && (
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] font-mono text-slate-400">
                        Auto-advance next in {playlistCountdownSeconds}s
                      </span>
                      <div className="w-24 h-1.5 rounded-full bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-emerald-500 transition-all duration-1000"
                          style={{ width: `${(playlistCountdownSeconds / 30) * 100}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Playlist Player Controls */}
              <div className="flex flex-wrap items-center gap-1.5 self-end md:self-auto">
                <button
                  onClick={handlePrevTrack}
                  className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition cursor-pointer"
                  title="Previous Track"
                >
                  <SkipBack className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition shadow-md shadow-emerald-600/30 cursor-pointer"
                  title={isPlaying ? "Pause Playlist" : "Resume Playlist"}
                >
                  {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                </button>

                <button
                  onClick={handleNextTrack}
                  className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 transition cursor-pointer"
                  title="Next Track"
                >
                  <SkipForward className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setIsShuffleEnabled(!isShuffleEnabled)}
                  className={`p-2 rounded-xl border transition cursor-pointer ${
                    isShuffleEnabled
                      ? "bg-indigo-600 border-indigo-500 text-white"
                      : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
                  }`}
                  title={isShuffleEnabled ? "Shuffle Active" : "Enable Shuffle"}
                >
                  <Shuffle className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setIsLoopEnabled(!isLoopEnabled)}
                  className={`p-2 rounded-xl border transition cursor-pointer ${
                    isLoopEnabled
                      ? "bg-purple-600 border-purple-500 text-white"
                      : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
                  }`}
                  title={isLoopEnabled ? "Loop Playlist Active" : "Enable Loop"}
                >
                  <Repeat className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setShowQueuePanel(!showQueuePanel)}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition cursor-pointer ${
                    showQueuePanel
                      ? "bg-sky-600 border-sky-500 text-white"
                      : "bg-slate-900 border-slate-800 text-slate-300 hover:text-white"
                  }`}
                  title="Toggle Queue Panel"
                >
                  <ListMusic className="w-3.5 h-3.5" />
                  <span>Queue ({playlistVideos.length})</span>
                </button>

                <button
                  onClick={() => {
                    setIsPlaylistActive(false);
                    setIsPlaying(false);
                  }}
                  className="px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-slate-800 text-xs font-bold transition cursor-pointer"
                >
                  Exit Playlist
                </button>
              </div>
            </div>
          ) : (
            // Standard Header with Play All Shortcut
            <div className="p-4 sm:p-5 border-b border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
                  <Star className="w-4 h-4 fill-amber-400" />
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black uppercase tracking-wider text-amber-400">
                      {currentVideo.isFavorite ? "Favorite Video Spotlight" : "Active Media Player"}
                    </span>
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300">
                      {currentVideo.platform}
                    </span>
                  </div>
                  <h2 className="text-base sm:text-lg font-bold text-white truncate max-w-2xl">
                    {currentVideo.title}
                  </h2>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  id="btn-play-all-tracked-player"
                  onClick={() => handlePlayAllTracked()}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md transition cursor-pointer"
                >
                  <Play className="w-3.5 h-3.5 fill-slate-950" />
                  <span>Play All Tracked</span>
                </button>

                <button
                  onClick={() => handleSetFavorite(currentVideo)}
                  className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition ${
                    currentVideo.isFavorite
                      ? "bg-amber-500/20 border-amber-500 text-amber-300"
                      : "bg-slate-800 border-slate-700 text-slate-300 hover:border-slate-600"
                  }`}
                >
                  <Star className={`w-3.5 h-3.5 ${currentVideo.isFavorite ? "fill-amber-400" : ""}`} />
                  <span>{currentVideo.isFavorite ? "Primary Favorite" : "Set as Favorite"}</span>
                </button>

                <button
                  onClick={() => onNavigateToAnalytics(currentVideo.id)}
                  className="px-3 py-1.5 rounded-xl bg-sky-500/20 border border-sky-500/40 text-sky-300 hover:bg-sky-500/30 text-xs font-bold flex items-center gap-1.5 transition"
                >
                  <BarChart2 className="w-3.5 h-3.5" />
                  <span>Track Analytics</span>
                </button>

                <button
                  onClick={() => handleCopyEmbed(currentVideo)}
                  className="p-2 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition"
                  title="Copy Embed Code"
                >
                  {copiedId === currentVideo.id ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Interactive Player Grid (With Side Queue Panel when in Playlist Mode) */}
          <div className={`grid grid-cols-1 ${isPlaylistActive && showQueuePanel ? "lg:grid-cols-12" : ""}`}>
            {/* Player Frame */}
            <div className={`relative aspect-video w-full bg-black/90 ${isPlaylistActive && showQueuePanel ? "lg:col-span-8" : ""}`}>
              {currentVideo.embedUrl && currentVideo.embedUrl.includes("youtube") ? (
                <iframe
                  src={`${currentVideo.embedUrl}?rel=0&modestbranding=1${isPlaylistActive ? "&autoplay=1" : ""}`}
                  title={currentVideo.title}
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
              ) : currentVideo.videoUrl && currentVideo.videoUrl.endsWith(".mp4") ? (
                <video
                  src={currentVideo.videoUrl}
                  controls
                  autoPlay={isPlaylistActive}
                  className="w-full h-full object-contain"
                  poster={currentVideo.thumbnail}
                />
              ) : currentVideo.embedUrl && currentVideo.embedUrl.includes("vimeo") ? (
                <iframe
                  src={`${currentVideo.embedUrl}${isPlaylistActive ? "?autoplay=1" : ""}`}
                  title={currentVideo.title}
                  className="w-full h-full border-0"
                  allow="autoplay; fullscreen; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <div className="relative w-full h-full flex flex-col items-center justify-center overflow-hidden">
                  <img
                    src={currentVideo.thumbnail}
                    alt={currentVideo.title}
                    className="absolute inset-0 w-full h-full object-cover opacity-40 filter blur-sm"
                  />
                  <div className="relative z-10 text-center p-6 max-w-lg bg-slate-950/80 rounded-2xl border border-slate-700/80 backdrop-blur-md">
                    <div className="w-14 h-14 mx-auto mb-3 rounded-full bg-indigo-600/30 border border-indigo-500/50 flex items-center justify-center text-indigo-400">
                      <Tv className="w-7 h-7" />
                    </div>
                    <h3 className="text-white font-bold text-base mb-1">{currentVideo.title}</h3>
                    <p className="text-xs text-slate-400 mb-4">
                      Embedded from <strong>{currentVideo.platform.toUpperCase()}</strong> ({currentVideo.topic})
                    </p>
                    <div className="flex items-center justify-center gap-3">
                      {currentVideo.videoUrl && (
                        <a
                          href={currentVideo.videoUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>Watch on Platform</span>
                        </a>
                      )}
                      <button
                        onClick={handleNextTrack}
                        className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <SkipForward className="w-3.5 h-3.5" />
                        <span>Next Track</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Playlist Queue Rail */}
            {isPlaylistActive && showQueuePanel && (
              <div className="lg:col-span-4 bg-slate-950/90 border-t lg:border-t-0 lg:border-l border-slate-800 flex flex-col h-[280px] lg:h-auto overflow-hidden">
                <div className="p-3 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
                  <div className="flex items-center gap-2">
                    <ListMusic className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">
                      Tracked Queue ({playlistVideos.length})
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Track {currentPlaylistIndex + 1} / {playlistVideos.length}
                  </span>
                </div>

                <div className="flex-1 overflow-y-auto p-2 space-y-1.5 scrollbar-thin">
                  {playlistVideos.map((video, idx) => {
                    const isCurrent = idx === currentPlaylistIndex;
                    return (
                      <div
                        key={video.id || idx}
                        onClick={() => handleJumpToTrack(idx)}
                        className={`p-2 rounded-xl transition cursor-pointer flex items-center gap-2.5 ${
                          isCurrent
                            ? "bg-emerald-950/50 border border-emerald-500/50 text-white"
                            : "hover:bg-slate-900 border border-transparent text-slate-300"
                        }`}
                      >
                        <div className="w-6 text-center font-mono text-xs font-bold shrink-0">
                          {isCurrent ? (
                            <span className="text-emerald-400 animate-pulse">▶</span>
                          ) : (
                            <span className="text-slate-500">{idx + 1}</span>
                          )}
                        </div>

                        <div className="w-14 h-9 rounded-lg overflow-hidden shrink-0 bg-slate-900 relative">
                          <img
                            src={video.thumbnail}
                            alt={video.title}
                            className="w-full h-full object-cover"
                          />
                        </div>

                        <div className="flex-1 min-w-0">
                          <h5 className="text-xs font-bold truncate leading-tight">
                            {video.title}
                          </h5>
                          <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                            <span className="uppercase font-semibold text-sky-400">{video.platform}</span>
                            <span>•</span>
                            <span>{video.duration}</span>
                            <span>•</span>
                            <span className="text-emerald-400 font-mono">+${(video.verifiedAdPayout || video.revenueGenerated || 0).toFixed(0)}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Quick Metrics Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 p-4 bg-[#131926]/80 border-t border-slate-800 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">Platform Views</span>
              <span className="text-sm font-extrabold text-white">
                {currentVideo.views.toLocaleString()}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">Watch Time</span>
              <span className="text-sm font-bold text-sky-400">
                {(currentVideo.watchTimeHours || 0).toLocaleString()} hrs
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">Duration</span>
              <span className="text-sm font-bold text-slate-200 font-mono">
                {currentVideo.duration}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">Hook Retention</span>
              <span className="text-sm font-bold text-emerald-400">
                {currentVideo.retentionRate}%
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">Estimated Ad RPM</span>
              <span className="text-sm font-bold text-amber-400">
                ${(currentVideo.cpm || 3.5).toFixed(2)}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">Verified Earnings</span>
              <span className="text-sm font-extrabold text-emerald-400">
                ${(currentVideo.verifiedAdPayout || currentVideo.revenueGenerated || 0).toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Catalog Search & Filter Controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search videos by title or topic..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#161f2e] border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Platform Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 scrollbar-none">
          {["ALL", "youtube", "tiktok", "instagram", "x", "vimeo"].map((platform) => (
            <button
              key={platform}
              onClick={() => setSelectedPlatform(platform)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition shrink-0 ${
                selectedPlatform === platform
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "bg-[#161f2e] border border-slate-700/80 text-slate-400 hover:text-white"
              }`}
            >
              {platform === "ALL" ? "All Channels" : platform}
            </button>
          ))}
        </div>
      </div>

      {/* Video Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredVideos.map((video) => {
          const isSelected = activePlayerVideo?.id === video.id;
          return (
            <div
              key={video.id}
              className={`rounded-2xl border transition overflow-hidden flex flex-col group ${
                isSelected
                  ? "bg-[#182335] border-indigo-500 shadow-xl shadow-indigo-500/10"
                  : "bg-[#161f2e]/85 border-slate-700/80 hover:border-slate-600"
              }`}
            >
              {/* Thumbnail Container with Play Overlay */}
              <div className="relative aspect-video w-full bg-slate-950 overflow-hidden cursor-pointer" onClick={() => setActivePlayerVideo(video)}>
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

                {/* Badges */}
                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                  <span className="rounded-lg bg-black/70 backdrop-blur-md px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wider text-white border border-white/10">
                    {video.platform}
                  </span>
                  {video.isFavorite && (
                    <span className="rounded-lg bg-amber-500/90 text-black px-2 py-0.5 text-[10px] font-black uppercase flex items-center gap-1">
                      <Star className="w-3 h-3 fill-black" />
                      <span>Favorite</span>
                    </span>
                  )}
                </div>

                <div className="absolute bottom-2.5 right-2.5 flex items-center gap-1 bg-black/80 px-2 py-0.5 rounded-md text-[10px] font-mono text-white">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>{video.duration}</span>
                </div>

                {/* Hover Play Button */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition bg-black/40">
                  <div className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-xl transform scale-90 group-hover:scale-100 transition">
                    <Play className="w-5 h-5 fill-white ml-0.5" />
                  </div>
                </div>
              </div>

              {/* Video Info */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                    <span className="truncate max-w-[180px] font-medium text-sky-400">{video.topic}</span>
                    <span>{video.uploadDate}</span>
                  </div>

                  <h3 className="text-sm font-bold text-white line-clamp-2 mb-2 group-hover:text-indigo-300 transition">
                    {video.title}
                  </h3>

                  <div className="grid grid-cols-3 gap-2 py-2 border-t border-b border-slate-800/80 text-[11px] text-slate-300 mb-3">
                    <div className="flex items-center gap-1">
                      <Eye className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-bold">{(video.views / 1000).toFixed(0)}k</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="w-3.5 h-3.5 text-rose-400" />
                      <span className="font-bold">{(video.likes / 1000).toFixed(1)}k</span>
                    </div>
                    <div className="flex items-center gap-1 text-emerald-400">
                      <span className="font-extrabold">+${video.revenueGenerated.toFixed(0)}</span>
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="flex items-center justify-between gap-2 pt-1">
                  <button
                    onClick={() => setActivePlayerVideo(video)}
                    className="flex-1 py-1.5 rounded-xl bg-indigo-600/20 hover:bg-indigo-600/40 border border-indigo-500/40 text-indigo-300 font-bold text-xs flex items-center justify-center gap-1.5 transition"
                  >
                    <Play className="w-3 h-3 fill-indigo-300" />
                    <span>Play & Embed</span>
                  </button>

                  <button
                    onClick={() => onNavigateToAnalytics(video.id)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white transition"
                    title="Open in Analytics Dashboard"
                  >
                    <BarChart2 className="w-3.5 h-3.5 text-sky-400" />
                  </button>

                  <button
                    onClick={() => handleSetFavorite(video)}
                    className={`p-2 rounded-xl border transition ${
                      video.isFavorite
                        ? "bg-amber-500/20 border-amber-500 text-amber-300"
                        : "bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-400 hover:text-amber-400"
                    }`}
                    title={video.isFavorite ? "Favorite Video" : "Set as Favorite"}
                  >
                    <Star className={`w-3.5 h-3.5 ${video.isFavorite ? "fill-amber-400" : ""}`} />
                  </button>

                  <button
                    onClick={() => handleDeleteVideo(video.id, video.title)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950/60 border border-slate-700 hover:border-rose-500/50 text-slate-400 hover:text-rose-400 transition"
                    title="Remove Video"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Import Modal */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="relative w-full max-w-lg rounded-3xl bg-[#161f2e] border border-slate-700 shadow-2xl p-6 sm:p-7">
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                  {importMode === "URL" ? <Film className="w-5 h-5" /> : <Rss className="w-5 h-5 text-amber-400" />}
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {importMode === "URL" ? "Import Video to Media Manager" : "Import from RSS Creator Feed"}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {importMode === "URL"
                      ? "Paste any YouTube, Vimeo, or video URL"
                      : "Parse video items from RSS XML / Atom feed"}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsImportModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            {/* Mode Switcher Tabs */}
            <div className="flex items-center gap-2 mt-4 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setImportMode("URL")}
                className={`flex-1 py-1.5 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
                  importMode === "URL" ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                <Film className="w-3.5 h-3.5" />
                <span>Single Video URL</span>
              </button>
              <button
                type="button"
                onClick={() => setImportMode("RSS")}
                className={`flex-1 py-1.5 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
                  importMode === "RSS" ? "bg-amber-600 text-white" : "text-slate-400 hover:text-white"
                }`}
              >
                <Rss className="w-3.5 h-3.5" />
                <span>RSS / Podcast Feed</span>
              </button>
            </div>

            {/* URL Form */}
            {importMode === "URL" && (
              <form onSubmit={handleImportUrl} className="mt-4 space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Video URL (YouTube, Vimeo, MP4) *
                  </label>
                  <input
                    type="url"
                    placeholder="https://www.youtube.com/watch?v=SSo_EIwHSd4"
                    value={inputUrl}
                    onChange={(e) => setInputUrl(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Supports YouTube links, Shorts, Vimeo, or direct MP4 streams.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Custom Title (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="E.g., Automated Push Credit Guide & Monetization Analysis"
                    value={inputTitle}
                    onChange={(e) => setInputTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Platform</label>
                    <select
                      value={inputPlatform}
                      onChange={(e) => setInputPlatform(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="youtube">YouTube</option>
                      <option value="tiktok">TikTok</option>
                      <option value="instagram">Instagram</option>
                      <option value="vimeo">Vimeo</option>
                      <option value="x">X (Twitter)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">Duration</label>
                    <input
                      type="text"
                      placeholder="12:30"
                      value={inputDuration}
                      onChange={(e) => setInputDuration(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    >
                    </input>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Category / Topic</label>
                  <input
                    type="text"
                    placeholder="FinTech, FedNow, AI, Creator Growth"
                    value={inputTopic}
                    onChange={(e) => setInputTopic(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="chk-set-fav"
                    checked={setAsFavoriteOnImport}
                    onChange={(e) => setSetAsFavoriteOnImport(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-indigo-500"
                  />
                  <label htmlFor="chk-set-fav" className="text-xs text-slate-300 cursor-pointer">
                    Set as my Primary Favorite Spotlight video on import
                  </label>
                </div>

                <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsImportModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 transition disabled:opacity-50"
                  >
                    {isSubmitting ? "Importing..." : "Import Video"}
                  </button>
                </div>
              </form>
            )}

            {/* RSS Form */}
            {importMode === "RSS" && (
              <form onSubmit={handleImportRss} className="mt-4 space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Select Curated Channel Feed
                  </label>
                  <select
                    value={presetFeed}
                    onChange={(e) => setPresetFeed(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="creator_economy">
                      FinTech, FedNow & High-Yield Creator Feeds (3 Videos)
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Custom RSS / Atom Feed URL (Optional)
                  </label>
                  <input
                    type="url"
                    placeholder="https://www.youtube.com/feeds/videos.xml?channel_id=..."
                    value={rssUrl}
                    onChange={(e) => setRssUrl(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    You can paste any YouTube channel XML feed or podcast feed to extract playable video entries.
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Instant Batch Import</span>
                  </div>
                  <p className="text-[11px] text-amber-200/80">
                    Imports published video entries into your library with pre-calculated hook retention curves, view statistics, and embed links.
                  </p>
                </div>

                <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsImportModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center gap-2 transition disabled:opacity-50"
                  >
                    {isSubmitting ? "Importing Feeds..." : "Import Feed Items"}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Daily AI Trending Video Monitor & Tracker Modal */}
      <DailyAiTrendMonitorModal
        isOpen={isAiTrendModalOpen}
        onClose={() => setIsAiTrendModalOpen(false)}
        onRefreshMediaData={onRefreshData}
        onSelectVideoForPlay={(v) => setActivePlayerVideo(v)}
        onPlayAllTrends={handlePlayAllFromDailyTrends}
      />
    </div>
  );
};
