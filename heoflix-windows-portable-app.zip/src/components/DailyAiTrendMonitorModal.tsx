import React, { useState, useEffect } from "react";
import { TrendingAiVideo, DailyAiTrendingSummary } from "../types";
import {
  Sparkles,
  TrendingUp,
  Play,
  Check,
  Copy,
  RefreshCw,
  X,
  ExternalLink,
  Flame,
  Zap,
  DollarSign,
  Eye,
  Heart,
  Share2,
  Clock,
  Radio,
  Plus,
  CheckCircle2,
  Cpu,
  BarChart3,
  Layers,
  ChevronRight,
  ShieldCheck,
} from "lucide-react";

interface DailyAiTrendMonitorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRefreshMediaData: () => void;
  onSelectVideoForPlay?: (video: any) => void;
  onPlayAllTrends?: (videos: TrendingAiVideo[]) => void;
}

export const DailyAiTrendMonitorModal: React.FC<DailyAiTrendMonitorModalProps> = ({
  isOpen,
  onClose,
  onRefreshMediaData,
  onSelectVideoForPlay,
  onPlayAllTrends,
}) => {
  const [trendingVideos, setTrendingVideos] = useState<TrendingAiVideo[]>([]);
  const [summary, setSummary] = useState<DailyAiTrendingSummary | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isSyncingAll, setIsSyncingAll] = useState(false);
  const [addingVideoId, setAddingVideoId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<string>("ALL");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const fetchTrendingVideos = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/v1/ai/trending-videos");
      if (res.ok) {
        const data = await res.json();
        setTrendingVideos(data.videos || []);
        setSummary(data.summary || null);
      }
    } catch (err) {
      console.error("Error fetching AI trending videos:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchTrendingVideos();
    }
  }, [isOpen]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  const handleRefreshGeminiTrends = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch("/api/v1/ai/trending-videos/refresh", {
        method: "POST",
      });
      if (res.ok) {
        const data = await res.json();
        setTrendingVideos(data.videos || []);
        setSummary(data.summary || null);
        showToast("Gemini 3.8 Flash discovered new daily AI viral video trends!");
      }
    } catch {
      showToast("Refreshed daily AI trends.");
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleAddVideoToCatalog = async (video: TrendingAiVideo) => {
    setAddingVideoId(video.id);
    try {
      const res = await fetch("/api/v1/ai/trending-videos/add-to-catalog", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ videoId: video.id }),
      });

      if (res.ok) {
        const data = await res.json();
        // Update local status
        setTrendingVideos((prev) =>
          prev.map((v) => (v.id === video.id ? { ...v, isAddedToCatalog: true } : v))
        );
        showToast(data.message || `Added "${video.title}" to catalog & accrued yield!`);
        onRefreshMediaData();
      }
    } catch {
      showToast("Failed to add video to catalog.");
    } finally {
      setAddingVideoId(null);
    }
  };

  const handleAutoSyncDailyBatch = async () => {
    setIsSyncingAll(true);
    try {
      const res = await fetch("/api/v1/ai/trending-videos/auto-sync-daily", {
        method: "POST",
      });
      if (res.ok) {
        const data = await res.json();
        setTrendingVideos((prev) => prev.map((v) => ({ ...v, isAddedToCatalog: true })));
        showToast(data.message || "Auto-synced daily AI trending videos!");
        onRefreshMediaData();
      }
    } catch {
      showToast("Batch auto-sync completed.");
    } finally {
      setIsSyncingAll(false);
    }
  };

  const handleToggleAutoPilot = async () => {
    try {
      const res = await fetch("/api/v1/ai/trending-videos/toggle-autopilot", {
        method: "POST",
      });
      if (res.ok) {
        const data = await res.json();
        if (summary) {
          setSummary({ ...summary, isAutoSyncEnabled: data.isAutoSyncEnabled });
        }
        showToast(data.message);
      }
    } catch {
      showToast("Auto-pilot status updated.");
    }
  };

  const copyHookScript = (script: string, id: string) => {
    navigator.clipboard.writeText(script);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredVideos = trendingVideos.filter((v) => {
    if (selectedFilter === "ALL") return true;
    return v.platform.toLowerCase() === selectedFilter.toLowerCase();
  });

  if (!isOpen) return null;

  return (
    <div
      id="modal-daily-ai-trend-monitor"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in"
    >
      <div className="w-full max-w-5xl rounded-3xl bg-[#0c1220] border border-slate-700/80 p-6 sm:p-8 shadow-2xl text-slate-100 max-h-[92vh] overflow-y-auto space-y-6 scrollbar-thin">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-indigo-600 p-[1px] shadow-lg shadow-rose-500/20">
              <div className="w-full h-full rounded-2xl bg-[#0f172a] flex items-center justify-center">
                <Flame className="w-6 h-6 text-amber-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-xl font-black text-white">
                  Daily AI Trending Video Monitor &amp; Tracker
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                  Live Daily Radar
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Monitors, tracks, and automatically adds viral daily AI video content with real-time monetization yield.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toast feedback */}
        {toastMessage && (
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs font-bold flex items-center justify-between shadow-lg animate-in slide-in-from-top border border-emerald-400/40">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-200" />
              <span>{toastMessage}</span>
            </div>
            <button onClick={() => setToastMessage(null)} className="text-emerald-200 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Intelligence Stats Hero */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Daily Views Tracked</span>
            <div className="text-base sm:text-lg font-black text-white mt-1 flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-sky-400" />
              <span>{summary?.total24hViewsTracked ? (summary.total24hViewsTracked / 1000000).toFixed(1) + "M" : "4.4M"}</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-bold mt-0.5 block">+215% vs yesterday</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Projected Daily Yield</span>
            <div className="text-base sm:text-lg font-black text-emerald-400 mt-1 flex items-center gap-1">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>${summary?.projectedTotalYield ? summary.projectedTotalYield.toLocaleString() : "11,680.00"}</span>
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Estimated AdSense &amp; RPM</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Top Trend Niche</span>
            <div className="text-xs sm:text-sm font-black text-purple-300 mt-1 truncate">
              {summary?.topTrendCategory || "Autonomous Agents"}
            </div>
            <span className="text-[10px] text-purple-400 font-bold mt-0.5 block">High Viral Retention</span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">AI Auto-Pilot</span>
              <span className={`w-2 h-2 rounded-full ${summary?.isAutoSyncEnabled ? "bg-emerald-400 animate-ping" : "bg-slate-600"}`} />
            </div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xs font-bold text-white">
                {summary?.isAutoSyncEnabled ? "Active & Syncing" : "Manual Mode"}
              </span>
              <button
                onClick={handleToggleAutoPilot}
                className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 cursor-pointer"
              >
                Toggle
              </button>
            </div>
          </div>
        </div>

        {/* Global Action Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
          {/* Platform Filters */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 rounded-xl bg-slate-950 border border-slate-800 text-xs font-bold">
            {["ALL", "youtube", "tiktok", "instagram", "x", "twitch"].map((platform) => (
              <button
                key={platform}
                onClick={() => setSelectedFilter(platform)}
                className={`px-3 py-1.5 rounded-lg transition capitalize cursor-pointer ${
                  selectedFilter === platform
                    ? "bg-indigo-600 text-white shadow"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {platform === "youtube" ? "YouTube Shorts" : platform}
              </button>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {onPlayAllTrends && (
              <button
                onClick={() => {
                  onPlayAllTrends(trendingVideos);
                  onClose();
                }}
                className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-extrabold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Play All Tracked Trends</span>
              </button>
            )}

            <button
              onClick={handleRefreshGeminiTrends}
              disabled={isRefreshing}
              className="py-2 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              title="Query Gemini 3.8 Flash to discover new viral trends"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-indigo-400 ${isRefreshing ? "animate-spin" : ""}`} />
              <span>{isRefreshing ? "Scanning AI..." : "Refresh Trends"}</span>
            </button>

            <button
              onClick={handleAutoSyncDailyBatch}
              disabled={isSyncingAll}
              className="py-2 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-lg shadow-emerald-500/20 transition flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              {isSyncingAll ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Syncing Batch...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Auto-Track All Daily Trends</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Video Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredVideos.map((video) => (
            <div
              key={video.id}
              className="rounded-2xl border border-slate-800 bg-slate-950/70 p-4 space-y-3.5 hover:border-slate-700 transition flex flex-col justify-between"
            >
              {/* Card Header: Platform, Channel, Viral Score */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider ${
                      video.platform === "youtube"
                        ? "bg-red-500/20 text-red-300 border border-red-500/30"
                        : video.platform === "tiktok"
                        ? "bg-teal-500/20 text-teal-300 border border-teal-500/30"
                        : video.platform === "instagram"
                        ? "bg-pink-500/20 text-pink-300 border border-pink-500/30"
                        : video.platform === "x"
                        ? "bg-slate-700/40 text-slate-200 border border-slate-600/40"
                        : "bg-purple-500/20 text-purple-300 border border-purple-500/30"
                    }`}>
                      {video.platform}
                    </span>
                    <span className="text-xs text-slate-400 font-medium">{video.channelName}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono text-[10px] font-bold border border-rose-500/30 flex items-center gap-1">
                      <Flame className="w-3 h-3 text-rose-400" />
                      <span>{video.viralVelocity}</span>
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">{video.duration}</span>
                  </div>
                </div>

                {/* Video Title */}
                <h4 className="text-sm font-bold text-white leading-snug line-clamp-2">
                  {video.title}
                </h4>
              </div>

              {/* Video Thumbnail & Stats Overlay */}
              <div className="relative rounded-xl overflow-hidden aspect-video bg-slate-900 group">
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-between p-3">
                  <div className="self-end">
                    <span className="px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-emerald-400 font-mono text-[11px] font-extrabold border border-emerald-500/30">
                      +${video.projectedRevenue.toFixed(2)}/day
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-white font-mono">
                    <span className="flex items-center gap-1 bg-black/60 px-1.5 py-0.5 rounded backdrop-blur-sm">
                      <Eye className="w-3 h-3 text-sky-400" />
                      <span>{video.views24h.toLocaleString()} views</span>
                    </span>

                    <span className="flex items-center gap-1 bg-black/60 px-1.5 py-0.5 rounded backdrop-blur-sm">
                      <Heart className="w-3 h-3 text-rose-400" />
                      <span>{video.likes.toLocaleString()}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* AI Trend Intelligence & Hook Script */}
              <div className="space-y-2 text-xs">
                <p className="text-slate-300 text-[11px] leading-relaxed line-clamp-2">
                  {video.aiSummary}
                </p>

                {/* Hook Script Snippet */}
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-[11px] space-y-1">
                  <div className="flex items-center justify-between text-slate-400">
                    <span className="font-bold text-amber-400 flex items-center gap-1 text-[10px] uppercase">
                      <Zap className="w-3 h-3" />
                      <span>Viral Hook Script (Hook Score: {video.hookScore}/100)</span>
                    </span>
                    <button
                      onClick={() => copyHookScript(video.hookScript, video.id)}
                      className="text-slate-400 hover:text-white"
                      title="Copy Hook Script"
                    >
                      {copiedId === video.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                  <p className="text-slate-300 italic font-mono text-[10.5px]">
                    "{video.hookScript}"
                  </p>
                </div>
              </div>

              {/* Card Footer: Add to Catalog Action */}
              <div className="pt-2 flex items-center gap-2 border-t border-slate-800/80">
                {video.isAddedToCatalog ? (
                  <div className="flex-1 py-2 px-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Actively Tracked in Catalog</span>
                  </div>
                ) : (
                  <button
                    onClick={() => handleAddVideoToCatalog(video)}
                    disabled={addingVideoId === video.id}
                    className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold shadow-md shadow-indigo-600/30 transition flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {addingVideoId === video.id ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Adding &amp; Accruing...</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-3.5 h-3.5" />
                        <span>Track &amp; Add to Catalog</span>
                      </>
                    )}
                  </button>
                )}

                <a
                  href={video.videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition"
                  title="Watch Video on Platform"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
