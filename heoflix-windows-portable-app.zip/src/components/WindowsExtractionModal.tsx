import React, { useState, useEffect } from "react";
import {
  Download,
  Terminal,
  CheckCircle2,
  FileArchive,
  RefreshCw,
  X,
  ExternalLink,
  Laptop,
  Copy,
  Check,
  FolderArchive,
  ShieldCheck,
  Play,
} from "lucide-react";

interface WindowsExtractionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WindowsExtractionModal: React.FC<WindowsExtractionModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [compatInfo, setCompatInfo] = useState<any>(null);
  const [isExtracting, setIsExtracting] = useState<boolean>(false);
  const [extractSuccessMsg, setExtractSuccessMsg] = useState<string>("");
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const fetchCompatibility = async () => {
    try {
      const res = await fetch("/api/v1/app/windows-compatibility");
      const data = await res.json();
      if (data.success) {
        setCompatInfo(data);
      }
    } catch {}
  };

  useEffect(() => {
    if (isOpen) {
      fetchCompatibility();
    }
  }, [isOpen]);

  const handleTriggerExtraction = async () => {
    setIsExtracting(true);
    setExtractSuccessMsg("");
    try {
      const res = await fetch("/api/v1/app/trigger-extraction", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        setExtractSuccessMsg(`Extracted ${data.fileCount} items (${data.sizeKb} KB). Standalone archive ready!`);
        await fetchCompatibility();
      }
    } catch (e: any) {
      setExtractSuccessMsg("Failed to re-extract: " + e.message);
    } finally {
      setIsExtracting(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-sky-500/30 p-6 sm:p-8 shadow-2xl space-y-6 text-slate-200 scrollbar-thin">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-6 right-6 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-sky-500/20">
            <Laptop className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-sky-400 uppercase tracking-wider font-mono">
                Windows 10/11 &amp; Cross-Platform
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold font-mono">
                100% READY
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              App Extraction &amp; Windows Runner
            </h2>
          </div>
        </div>

        {/* Primary Extraction Download Action */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-sky-950/60 via-slate-950/80 to-indigo-950/60 border border-sky-500/30 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <FileArchive className="w-4 h-4 text-sky-400" />
                <span>Portable Windows Archive</span>
                <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-sky-500/20 text-sky-300">
                  {compatInfo?.extraction?.sizeKb ? `${compatInfo.extraction.sizeKb} KB` : "631 KB"}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Complete self-contained bundle with source code, backend, public assets, and Windows double-click batch scripts.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <a
                id="btn-download-windows-zip"
                href="/api/v1/app/download-zip"
                download="heoflix-windows-portable-app.zip"
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs transition flex items-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/20 whitespace-nowrap"
              >
                <Download className="w-4 h-4" />
                <span>Download App ZIP</span>
              </a>

              <button
                type="button"
                onClick={handleTriggerExtraction}
                disabled={isExtracting}
                title="Re-run extraction to update archive"
                className="p-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
              >
                <RefreshCw className={`w-4 h-4 ${isExtracting ? "animate-spin" : ""}`} />
              </button>
            </div>
          </div>

          {extractSuccessMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{extractSuccessMsg}</span>
            </div>
          )}
        </div>

        {/* Windows 3-Step Execution Instructions */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
            How to Run on Windows (3 Steps)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
              <span className="w-6 h-6 rounded-lg bg-sky-500/20 text-sky-400 font-mono text-xs font-bold flex items-center justify-center">
                1
              </span>
              <div className="text-xs font-bold text-white">Extract Archive</div>
              <p className="text-[11px] text-slate-400">
                Right-click the downloaded <code className="text-sky-300">.zip</code> and select <strong>"Extract All..."</strong> to any folder (e.g. Desktop).
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
              <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-mono text-xs font-bold flex items-center justify-center">
                2
              </span>
              <div className="text-xs font-bold text-white">Double-Click Launcher</div>
              <p className="text-[11px] text-slate-400">
                Double-click <code className="text-emerald-300 font-bold">run-windows.bat</code>. It verifies Node.js and installs dependencies automatically.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-1.5">
              <span className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 font-mono text-xs font-bold flex items-center justify-center">
                3
              </span>
              <div className="text-xs font-bold text-white">Instant Launch</div>
              <p className="text-[11px] text-slate-400">
                Your browser automatically opens to <code className="text-indigo-300">http://localhost:3000</code> with the full application running!
              </p>
            </div>
          </div>
        </div>

        {/* Windows Launchers Included */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
            Included Windows Launchers
          </h3>

          <div className="space-y-2">
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <Terminal className="w-4 h-4 text-emerald-400 shrink-0" />
                <div>
                  <span className="font-mono font-bold text-emerald-300">run-windows.bat</span>
                  <span className="text-slate-400 block text-[11px]">
                    Interactive batch script for Command Prompt with color diagnostic output
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => copyToClipboard(".\\run-windows.bat", "run_bat")}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] flex items-center gap-1 font-mono transition"
              >
                {copiedCode === "run_bat" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>Copy</span>
              </button>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <Play className="w-4 h-4 text-sky-400 shrink-0" />
                <div>
                  <span className="font-mono font-bold text-sky-300">start-windows.ps1</span>
                  <span className="text-slate-400 block text-[11px]">
                    Modern PowerShell runner with execution policy support
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => copyToClipboard("powershell -ExecutionPolicy Bypass -File .\\start-windows.ps1", "run_ps1")}
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] flex items-center gap-1 font-mono transition"
              >
                {copiedCode === "run_ps1" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>Copy</span>
              </button>
            </div>
          </div>
        </div>

        {/* CLI Extraction Command */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-slate-400">Terminal Command to Re-Extract:</span>
            <button
              type="button"
              onClick={() => copyToClipboard("npm run extract", "cli_cmd")}
              className="text-sky-400 hover:underline flex items-center gap-1"
            >
              {copiedCode === "cli_cmd" ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>Copy</span>
            </button>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-900 font-mono text-xs text-emerald-300 select-all border border-slate-800">
            npm run extract
          </div>
        </div>

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Node.js v18 / v20 / v22 LTS Compatible</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
