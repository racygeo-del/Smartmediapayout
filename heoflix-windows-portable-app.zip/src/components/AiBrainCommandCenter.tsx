import React, { useState, useEffect } from "react";
import {
  Brain,
  Cpu,
  Server,
  Zap,
  Send,
  Globe,
  ShieldCheck,
  CheckCircle2,
  RefreshCw,
  Terminal,
  Activity,
  ArrowRight,
  Sparkles,
  Lock,
  Building2,
  DollarSign,
  Layers,
  Search,
  Check,
  AlertCircle,
  Radio,
} from "lucide-react";
import { WalletState, GlobalServerNode, WorldBankEntry, BrainCommandResult, Transaction } from "../types";

interface AiBrainCommandCenterProps {
  wallet: WalletState;
  onUpdateWallet: (wallet: WalletState) => void;
  onRefreshAllData: () => void;
  onOpenSecurityModal: (title: string) => void;
  isUnlocked: boolean;
}

const PRESET_COMMANDS = [
  {
    label: "Transfer $100 to OPAY (George Felix Egwu)",
    cmd: "Transfer $100 to George Felix Egwu at OPAY Nigeria via Paystack NIP rail",
    icon: "⚡",
    category: "Transfer",
  },
  {
    label: "Transfer $100 to FIRST BANK (GEORGE FELIX EGWU)",
    cmd: "Transfer $100 to GEORGE FELIX EGWU at FIRST BANK Nigeria (Account: 3124446187) via NIP rail",
    icon: "🏦",
    category: "Transfer",
  },
  {
    label: "SWIFT Wire $250 to JPMorgan Chase USA",
    cmd: "Execute direct USD push credit of $250 to JPMorgan Chase Bank via FedNow / RTP",
    icon: "🇺🇸",
    category: "Transfer",
  },
  {
    label: "SEPA Instant €200 to Deutsche Bank Germany",
    cmd: "Send €200 to Deutsche Bank Frankfurt via SEPA Instant clearing rail",
    icon: "💶",
    category: "Transfer",
  },
  {
    label: "Faster Payments £150 to Barclays London",
    cmd: "Transfer £150 to Barclays Bank UK via Faster Payments Service",
    icon: "🇬🇧",
    category: "Transfer",
  },
  {
    label: "Generate $250 Automated Monetization",
    cmd: "Accelerate automated revenue stream: harvest $250 across social media channels",
    icon: "💵",
    category: "Yield",
  },
  {
    label: "Ping & Sync All 8 Global Banking Servers",
    cmd: "Ping all global banking servers, test handshakes and synchronize network mesh",
    icon: "🌐",
    category: "Servers",
  },
  {
    label: "Cryptographic Proof of Reserves Audit",
    cmd: "Audit cryptographic ledger and verify SHA-256 Merkle chain integrity",
    icon: "🔐",
    category: "Security",
  },
  {
    label: "Rebalance Vault to 85% Admin Allocation",
    cmd: "Rebalance wallet reserves: allocate 85% to Admin Vault and 15% to liquid reserves",
    icon: "⚖️",
    category: "Treasury",
  },
];

const WORLD_COUNTRIES = [
  { name: "Nigeria", flag: "🇳🇬", currency: "NGN", defaultBank: "OPAY", rate: 1550 },
  { name: "United States", flag: "🇺🇸", currency: "USD", defaultBank: "JPMorgan Chase Bank", rate: 1.0 },
  { name: "United Kingdom", flag: "🇬🇧", currency: "GBP", defaultBank: "Barclays Bank UK", rate: 0.78 },
  { name: "Germany", flag: "🇩🇪", currency: "EUR", defaultBank: "Deutsche Bank AG", rate: 0.92 },
  { name: "France", flag: "🇫🇷", currency: "EUR", defaultBank: "BNP Paribas", rate: 0.92 },
  { name: "United Arab Emirates", flag: "🇦🇪", currency: "AED", defaultBank: "Emirates NBD", rate: 3.67 },
  { name: "Canada", flag: "🇨🇦", currency: "CAD", defaultBank: "Royal Bank of Canada (RBC)", rate: 1.36 },
  { name: "South Africa", flag: "🇿🇦", currency: "ZAR", defaultBank: "Standard Bank of South Africa", rate: 18.25 },
  { name: "Kenya", flag: "🇰🇪", currency: "KES", defaultBank: "KCB Bank Kenya", rate: 129.5 },
];

export const AiBrainCommandCenter: React.FC<AiBrainCommandCenterProps> = ({
  wallet,
  onUpdateWallet,
  onRefreshAllData,
  onOpenSecurityModal,
  isUnlocked,
}) => {
  // Command execution state
  const [commandInput, setCommandInput] = useState<string>("");
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [lastResult, setLastResult] = useState<BrainCommandResult | null>(null);
  const [commandHistory, setCommandHistory] = useState<string[]>([
    "Transfer $100 to George Felix Egwu at OPAY Nigeria via Paystack NIP rail",
    "Ping all global banking servers and synchronize network mesh",
  ]);

  // Global Servers Mesh state
  const [servers, setServers] = useState<GlobalServerNode[]>([]);
  const [isLoadingServers, setIsLoadingServers] = useState<boolean>(true);
  const [isPingingServers, setIsPingingServers] = useState<boolean>(false);
  const [serversMeshStatus, setServersMeshStatus] = useState<string>("ALL_NODES_SYNCHRONIZED");

  // World Transfer Tab State
  const [activeSubTab, setActiveSubTab] = useState<"terminal" | "world-transfer" | "servers">("terminal");
  const [transferCountry, setTransferCountry] = useState<string>("Nigeria");
  const [transferRecipient, setTransferRecipient] = useState<string>("George Felix Egwu");
  const [transferAccount, setTransferAccount] = useState<string>("8134762646");
  const [transferBank, setTransferBank] = useState<string>("OPAY");
  const [transferAmountUsd, setTransferAmountUsd] = useState<number>(100);
  const [banksList, setBanksList] = useState<WorldBankEntry[]>([]);
  const [isSubmittingTransfer, setIsSubmittingTransfer] = useState<boolean>(false);
  const [transferSuccessToast, setTransferSuccessToast] = useState<string>("");

  // Load server mesh and banks
  const fetchServers = async () => {
    try {
      setIsLoadingServers(true);
      const res = await fetch("/api/v1/brain/servers");
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.servers) {
          setServers(data.servers);
          setServersMeshStatus(data.meshStatus || "ALL_NODES_SYNCHRONIZED");
        }
      }
    } catch (err) {
      console.warn("Server mesh fetch error:", err);
    } finally {
      setIsLoadingServers(false);
    }
  };

  const fetchBanks = async (countryName: string) => {
    try {
      const res = await fetch(`/api/v1/brain/banks-directory?country=${encodeURIComponent(countryName)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.banks) {
          setBanksList(data.banks);
          if (data.banks.length > 0) {
            setTransferBank(data.banks[0].name);
          }
        }
      }
    } catch (err) {
      console.warn("Banks directory error:", err);
    }
  };

  useEffect(() => {
    fetchServers();
    fetchBanks(transferCountry);
  }, []);

  const handleCountryChange = (cName: string) => {
    setTransferCountry(cName);
    const countryObj = WORLD_COUNTRIES.find((c) => c.name === cName);
    if (countryObj) {
      setTransferBank(countryObj.defaultBank);
      if (cName === "Nigeria") {
        setTransferRecipient("George Felix Egwu");
        setTransferAccount("8134762646");
      }
    }
    fetchBanks(cName);
  };

  // Ping All Servers
  const handlePingServers = async () => {
    setIsPingingServers(true);
    try {
      const res = await fetch("/api/v1/brain/ping-servers", { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.servers) {
          setServers(data.servers);
        }
      }
    } catch (err) {
      console.warn("Ping servers error:", err);
    } finally {
      setIsPingingServers(false);
    }
  };

  // Execute Command via AI Brain
  const handleExecuteCommand = async (cmdText?: string) => {
    const textToRun = cmdText || commandInput;
    if (!textToRun.trim() || isExecuting) return;

    setIsExecuting(true);
    setLastResult(null);

    try {
      const res = await fetch("/api/v1/brain/execute-command", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          command: textToRun,
          authCredential: isUnlocked ? "LEAHUSS" : "PASSWORD_LEAHUS",
        }),
      });

      if (res.ok) {
        const data: BrainCommandResult = await res.json();
        setLastResult(data);
        if (data.wallet) {
          onUpdateWallet(data.wallet);
        }
        if (data.servers) {
          setServers(data.servers);
        }
        onRefreshAllData();

        // Update history
        setCommandHistory((prev) => [textToRun, ...prev.filter((c) => c !== textToRun)].slice(0, 8));
        setCommandInput("");
      } else {
        const errData = await res.json().catch(() => ({}));
        setLastResult({
          success: false,
          error: errData.error || "Execution failed. Check banking server logs.",
        });
      }
    } catch (err: any) {
      setLastResult({
        success: false,
        error: err.message || "Network execution error. All fallback rails remain active.",
      });
    } finally {
      setIsExecuting(false);
    }
  };

  // Execute AI World Financial Transfer
  const handleExecuteWorldTransfer = async () => {
    if (transferAmountUsd <= 0 || isSubmittingTransfer) return;

    setIsSubmittingTransfer(true);
    setTransferSuccessToast("");

    try {
      const countryObj = WORLD_COUNTRIES.find((c) => c.name === transferCountry);
      const res = await fetch("/api/v1/brain/world-transfer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipientName: transferRecipient,
          recipientAccount: transferAccount,
          bankName: transferBank,
          country: transferCountry,
          amountUsd: transferAmountUsd,
          targetCurrency: countryObj ? countryObj.currency : "USD",
          authCredential: isUnlocked ? "LEAHUSS" : "PASSWORD_LEAHUS",
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          setTransferSuccessToast(data.message);
          if (data.wallet) {
            onUpdateWallet(data.wallet);
          }
          onRefreshAllData();
          setLastResult({
            success: true,
            commandExecuted: `AI World Transfer: $${transferAmountUsd} to ${transferRecipient} (${transferBank})`,
            intent: "TRANSFER_FUNDS",
            actionSummary: data.message,
            confidenceScore: 99.9,
            executionSteps: [
              { step: "Target Country & Bank Selection", status: "COMPLETED", latencyMs: 8, details: `Matched ${transferCountry} banking node (${transferBank})` },
              { step: "Beneficiary Verification", status: "COMPLETED", latencyMs: 12, details: `Account ${transferAccount} resolved to ${transferRecipient}` },
              { step: "Currency & FX Interbank Lock", status: "COMPLETED", latencyMs: 6, details: `Converted at live interbank rate with zero spread` },
              { step: "Push Credit Settlement", status: "COMPLETED", latencyMs: 15, details: `Dispatched via ${data.settlementDetails?.serverNode || "Banking Mesh"} (< 1.5s)` },
              { step: "Cryptographic SHA-256 Ledger Block", status: "COMPLETED", latencyMs: 4, details: `Block #${data.auditBlock?.index || 4} sealed with SHA-256` },
            ],
            transaction: data.transaction,
            auditBlock: data.auditBlock,
            wallet: data.wallet,
          });
          setActiveSubTab("terminal");
        } else {
          alert(data.error || "Transfer failed");
        }
      }
    } catch (err: any) {
      alert("Transfer request failed: " + err.message);
    } finally {
      setIsSubmittingTransfer(false);
    }
  };

  const selectedCountryObj = WORLD_COUNTRIES.find((c) => c.name === transferCountry) || WORLD_COUNTRIES[0];
  const convertedLocalAmount = (transferAmountUsd * selectedCountryObj.rate).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

  return (
    <div className="space-y-6">
      {/* Top Banner: CORTEX-9 AI Autonomous Brain Engine */}
      <div className="relative overflow-hidden rounded-2xl border border-indigo-500/30 bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 p-6 shadow-2xl">
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none"></div>
        <div className="absolute right-12 bottom-2 opacity-10 pointer-events-none hidden lg:block">
          <Brain className="w-48 h-48 text-indigo-400" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="rounded-md bg-indigo-500/20 px-2.5 py-0.5 text-xs font-mono font-bold text-indigo-300 border border-indigo-500/30 flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                CORTEX-9 AUTONOMOUS FINANCIAL BRAIN
              </span>
              <span className="rounded-md bg-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-500/30">
                100% SUCCESS DISPATCH
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              AI Command & World Banking Execution Engine
            </h1>
            <p className="mt-1.5 text-sm text-slate-300 max-w-2xl leading-relaxed">
              Autonomous cognitive executor engineered to parse, validate, and execute financial commands to{" "}
              <span className="text-white font-semibold underline decoration-indigo-400">any bank in the world</span>,
              interconnect 8 global central bank rails, and seal every action with SHA-256 Merkle proofs.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="rounded-xl border border-slate-800 bg-slate-900/80 px-4 py-3 text-left">
              <div className="text-[10px] uppercase font-bold text-slate-400">Connected Global Servers</div>
              <div className="text-lg font-extrabold text-emerald-400 flex items-center gap-1.5">
                <Server className="w-4 h-4 text-emerald-400" />
                <span>8 / 8 Synchronized</span>
              </div>
            </div>

            <div className="rounded-xl border border-slate-800 bg-slate-900/80 px-4 py-3 text-left">
              <div className="text-[10px] uppercase font-bold text-slate-400">Wallet Liquidity</div>
              <div className="text-lg font-extrabold text-white">
                ${wallet.availableBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>
        </div>

        {/* Sub Navigation Tabs */}
        <div className="mt-6 flex items-center gap-2 border-t border-slate-800/80 pt-4 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveSubTab("terminal")}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-bold transition cursor-pointer ${
              activeSubTab === "terminal"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>AI Brain Terminal & Commands</span>
          </button>

          <button
            onClick={() => setActiveSubTab("world-transfer")}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-bold transition cursor-pointer ${
              activeSubTab === "world-transfer"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
            }`}
          >
            <Globe className="w-4 h-4 text-sky-400" />
            <span>Transfer to Any Bank in the World</span>
          </button>

          <button
            onClick={() => setActiveSubTab("servers")}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-2 text-xs font-bold transition cursor-pointer ${
              activeSubTab === "servers"
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
            }`}
          >
            <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>Global Banking Server Mesh (8 Nodes)</span>
          </button>
        </div>
      </div>

      {/* SUCCESS TOAST */}
      {transferSuccessToast && (
        <div className="rounded-xl border border-emerald-500/40 bg-emerald-950/40 p-4 text-emerald-300 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
            <span className="text-sm font-medium">{transferSuccessToast}</span>
          </div>
          <button
            onClick={() => setTransferSuccessToast("")}
            className="text-emerald-400/80 hover:text-white text-xs px-2 py-1"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* TAB 1: AI BRAIN TERMINAL & COMMAND EXECUTION */}
      {activeSubTab === "terminal" && (
        <div className="space-y-6">
          {/* Natural Language Command Bar */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  CORTEX-9 Natural Language Financial Executor
                </h3>
              </div>
              <span className="text-[11px] font-mono text-slate-400">Status: AUTONOMOUS_ACTIVE</span>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleExecuteCommand();
              }}
              className="relative"
            >
              <div className="relative flex items-center">
                <div className="absolute left-4 pointer-events-none text-indigo-400 font-mono text-sm font-bold">
                  $&gt;
                </div>
                <input
                  type="text"
                  value={commandInput}
                  onChange={(e) => setCommandInput(e.target.value)}
                  placeholder="Type any command: e.g. 'Transfer $100 to George Felix Egwu at OPAY', 'Send $100 to FIRST BANK', 'Ping all servers'..."
                  disabled={isExecuting}
                  className="w-full rounded-xl border border-slate-700/80 bg-slate-950 py-3.5 pl-10 pr-28 text-sm text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 font-mono transition"
                />
                <button
                  type="submit"
                  disabled={!commandInput.trim() || isExecuting}
                  className="absolute right-2 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-bold text-white hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition flex items-center gap-1.5 shadow-md cursor-pointer"
                >
                  {isExecuting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Executing...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5" />
                      <span>Execute</span>
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Quick Command Suggestions Chips */}
            <div className="mt-4">
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-indigo-400" />
                <span>Instant Autonomous Action Presets:</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {PRESET_COMMANDS.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleExecuteCommand(preset.cmd)}
                    disabled={isExecuting}
                    className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-950/60 px-3 py-1.5 text-xs text-slate-300 hover:border-indigo-500/40 hover:bg-indigo-950/20 hover:text-white transition cursor-pointer"
                  >
                    <span>{preset.icon}</span>
                    <span className="font-medium">{preset.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Real-time Execution Output Card */}
          {lastResult && (
            <div
              className={`rounded-2xl border p-5 shadow-2xl transition ${
                lastResult.success
                  ? "border-emerald-500/30 bg-gradient-to-b from-slate-900 via-slate-900 to-emerald-950/20"
                  : "border-red-500/30 bg-slate-900"
              }`}
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
                <div className="flex items-center gap-2.5">
                  {lastResult.success ? (
                    <div className="h-7 w-7 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                  ) : (
                    <div className="h-7 w-7 rounded-lg bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400">
                      <AlertCircle className="w-4 h-4" />
                    </div>
                  )}
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {lastResult.success ? "Command Executed Successfully" : "Command Execution Notice"}
                    </h4>
                    <p className="text-xs text-slate-400 font-mono">
                      Intent: {lastResult.intent || "AUTONOMOUS"} • Confidence: {lastResult.confidenceScore || 99.8}%
                    </p>
                  </div>
                </div>

                <span className="rounded bg-slate-800 px-2.5 py-1 text-[11px] font-mono text-slate-300">
                  {new Date().toLocaleTimeString()}
                </span>
              </div>

              {/* Action Summary */}
              {lastResult.actionSummary && (
                <div className="rounded-xl border border-emerald-500/20 bg-emerald-950/30 p-3.5 text-sm text-emerald-200 font-medium mb-4">
                  {lastResult.actionSummary}
                </div>
              )}

              {/* Step-by-Step AI Execution Trace */}
              {lastResult.executionSteps && lastResult.executionSteps.length > 0 && (
                <div className="space-y-2 mb-4">
                  <div className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                    Cognitive Execution Pipeline:
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {lastResult.executionSteps.map((step, sIdx) => (
                      <div
                        key={sIdx}
                        className="rounded-lg border border-slate-800 bg-slate-950/80 p-3 flex items-start gap-2.5"
                      >
                        <div className="h-5 w-5 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">
                          {sIdx + 1}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-semibold text-white truncate">{step.step}</span>
                            <span className="text-[10px] font-mono text-slate-500">{step.latencyMs}ms</span>
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5 leading-tight">{step.details}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Transaction & Cryptographic Ledger Badge */}
              {lastResult.auditBlock && (
                <div className="rounded-xl border border-indigo-500/20 bg-indigo-950/20 p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs font-mono text-slate-300">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-indigo-400 flex-shrink-0" />
                    <span>
                      SHA-256 Block #{lastResult.auditBlock.index}: {lastResult.auditBlock.hash?.slice(0, 20)}...
                    </span>
                  </div>
                  <span className="text-emerald-400 font-bold">Ledger Sealed & Verified</span>
                </div>
              )}
            </div>
          )}

          {/* Command History */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-indigo-400" />
                <span>Recent Autonomous Directives</span>
              </h4>
              <span className="text-[11px] text-slate-500">{commandHistory.length} cached</span>
            </div>
            <div className="space-y-2">
              {commandHistory.map((cmd, cIdx) => (
                <div
                  key={cIdx}
                  onClick={() => handleExecuteCommand(cmd)}
                  className="group flex items-center justify-between rounded-xl border border-slate-800/80 bg-slate-950/60 p-3 hover:border-indigo-500/40 hover:bg-slate-800/40 transition cursor-pointer"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-slate-500 font-mono text-xs">&gt;</span>
                    <span className="text-xs text-slate-300 group-hover:text-white font-mono truncate">{cmd}</span>
                  </div>
                  <button className="text-[11px] font-semibold text-indigo-400 group-hover:text-indigo-300 flex items-center gap-1">
                    <span>Re-run</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: TRANSFER TO ANY BANK IN THE WORLD */}
      {activeSubTab === "world-transfer" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Transfer Form */}
          <div className="lg:col-span-2 rounded-2xl border border-slate-800 bg-slate-900/90 p-6 shadow-xl space-y-5">
            <div>
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Globe className="w-5 h-5 text-indigo-400" />
                <span>AI Global Bank Transfer Portal</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Direct cross-border push credit into checking, savings, or business accounts worldwide via ISO 20022 and
                Paystack/NIP/FedNow switch rails.
              </p>
            </div>

            {/* Country Selector */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Target Country & Currency Corridor
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                {WORLD_COUNTRIES.map((c) => (
                  <button
                    key={c.name}
                    type="button"
                    onClick={() => handleCountryChange(c.name)}
                    className={`flex flex-col items-center justify-center p-2.5 rounded-xl border transition cursor-pointer ${
                      transferCountry === c.name
                        ? "border-indigo-500 bg-indigo-950/50 text-white shadow-md shadow-indigo-500/20"
                        : "border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                    }`}
                  >
                    <span className="text-xl mb-1">{c.flag}</span>
                    <span className="text-xs font-bold leading-tight">{c.name}</span>
                    <span className="text-[10px] font-mono text-indigo-400 mt-0.5">{c.currency}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Bank Directory Selector */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Destination Bank
              </label>
              <select
                value={transferBank}
                onChange={(e) => setTransferBank(e.target.value)}
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-white focus:border-indigo-500 focus:outline-none"
              >
                {banksList.map((b) => (
                  <option key={b.code} value={b.name}>
                    {b.name} ({b.rail})
                  </option>
                ))}
              </select>
            </div>

            {/* Recipient Account Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  Beneficiary Name
                </label>
                <input
                  type="text"
                  value={transferRecipient}
                  onChange={(e) => setTransferRecipient(e.target.value)}
                  placeholder="e.g. George Felix Egwu"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  Account Number / NUBAN / IBAN
                </label>
                <input
                  type="text"
                  value={transferAccount}
                  onChange={(e) => setTransferAccount(e.target.value)}
                  placeholder="e.g. 8134762646"
                  className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3.5 py-2.5 text-sm text-white placeholder-slate-500 font-mono focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Amount & Real-Time FX Conversion */}
            <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Transfer Amount (USD)
                </label>
                <span className="text-xs text-slate-400">
                  Available: ${wallet.availableBalance.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <span className="absolute left-3.5 top-3 text-slate-500 font-bold">$</span>
                  <input
                    type="number"
                    value={transferAmountUsd}
                    onChange={(e) => setTransferAmountUsd(Math.max(1, parseFloat(e.target.value) || 0))}
                    className="w-full rounded-xl border border-slate-700 bg-slate-900 py-2.5 pl-8 pr-4 text-base font-bold text-white focus:border-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="flex gap-1.5">
                  {[50, 100, 250, 500].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setTransferAmountUsd(amt)}
                      className={`rounded-lg px-2.5 py-2 text-xs font-bold transition cursor-pointer ${
                        transferAmountUsd === amt
                          ? "bg-indigo-600 text-white"
                          : "border border-slate-700 bg-slate-900 text-slate-300 hover:bg-slate-800"
                      }`}
                    >
                      ${amt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Conversion Result Box */}
              <div className="rounded-lg border border-emerald-500/20 bg-emerald-950/20 p-3 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-400">Recipient Receives in {transferCountry}:</span>
                  <div className="text-base font-extrabold text-emerald-400">
                    {convertedLocalAmount} {selectedCountryObj.currency}
                  </div>
                </div>
                <div className="text-right font-mono text-[11px] text-slate-400">
                  <div>Rate: 1 USD = {selectedCountryObj.rate} {selectedCountryObj.currency}</div>
                  <div className="text-emerald-400">Zero Intermediary Spread</div>
                </div>
              </div>
            </div>

            {/* Execute Button */}
            <button
              type="button"
              onClick={handleExecuteWorldTransfer}
              disabled={isSubmittingTransfer || transferAmountUsd <= 0}
              className="w-full rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-sky-600 py-3.5 text-sm font-extrabold text-white shadow-xl shadow-indigo-600/30 hover:opacity-95 disabled:opacity-50 transition cursor-pointer flex items-center justify-center gap-2"
            >
              {isSubmittingTransfer ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Settling via Global Mesh...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>
                    Confirm & Send ${transferAmountUsd.toFixed(2)} USD to {transferRecipient} ({transferBank})
                  </span>
                </>
              )}
            </button>
          </div>

          {/* Right Card: World Rail Specs & Primary Beneficiary */}
          <div className="space-y-6">
            <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 space-y-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h4 className="text-sm font-bold text-white">Pre-Verified Primary Beneficiary</h4>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950 p-3.5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Account Name:</span>
                  <span className="text-xs font-bold text-white">George Felix Egwu</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Primary Bank & Number:</span>
                  <span className="text-xs font-mono font-bold text-emerald-400">OPAY &bull; 8134762646</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Secondary Account:</span>
                  <span className="text-xs font-mono font-bold text-sky-400">FIRST BANK &bull; 3124446187</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Rail:</span>
                  <span className="text-xs font-mono text-sky-400">OPAY / NIP Instant Switch</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Settlement Velocity:</span>
                  <span className="text-xs font-bold text-emerald-400">&lt; 1.5 seconds</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setTransferCountry("Nigeria");
                    setTransferRecipient("George Felix Egwu");
                    setTransferAccount("8134762646");
                    setTransferBank("OPAY");
                    setTransferAmountUsd(100);
                  }}
                  className="rounded-lg border border-emerald-500/30 bg-emerald-950/30 py-2 px-3 text-xs font-bold text-emerald-300 hover:bg-emerald-900/40 hover:text-white transition cursor-pointer text-center"
                >
                  Auto-Fill OPAY (8134762646)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setTransferCountry("Nigeria");
                    setTransferRecipient("GEORGE FELIX EGWU");
                    setTransferAccount("3124446187");
                    setTransferBank("FIRST BANK");
                    setTransferAmountUsd(100);
                  }}
                  className="rounded-lg border border-sky-500/30 bg-sky-950/30 py-2 px-3 text-xs font-bold text-sky-300 hover:bg-sky-900/40 hover:text-white transition cursor-pointer text-center"
                >
                  Auto-Fill FIRST BANK (3124446187)
                </button>
              </div>
            </div>

            {/* Active Security Clearances */}
            <div className="rounded-2xl border border-slate-800 bg-slate-900/80 p-5 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Security & Compliance Guardrails
              </h4>
              <ul className="space-y-2 text-xs text-slate-300">
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                  <span>Master Admin Password Gate: <strong>Cleared &amp; Active</strong></span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                  <span>Touch ID / Face ID Biometric bypass enabled</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                  <span>AES-256-GCM encrypted transfer payload</span>
                </li>
                <li className="flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                  <span>ISO 20022 pacs.008 compliant messaging</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: GLOBAL BANKING SERVER MESH (8 NODES) */}
      {activeSubTab === "servers" && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Server className="w-5 h-5 text-emerald-400" />
                <span>Interconnected Global Banking Server Mesh</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Real-time status of all 8 centralized & decentralized payment servers, switches, and clearing houses.
              </p>
            </div>

            <button
              onClick={handlePingServers}
              disabled={isPingingServers}
              className="flex items-center gap-2 rounded-xl bg-slate-800 px-4 py-2.5 text-xs font-bold text-white hover:bg-slate-700 transition cursor-pointer self-start sm:self-auto"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isPingingServers ? "animate-spin text-indigo-400" : ""}`} />
              <span>Ping & Auto-Heal All 8 Nodes</span>
            </button>
          </div>

          {/* Grid of Server Nodes */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {servers.map((srv) => (
              <div
                key={srv.id}
                className="rounded-2xl border border-slate-800 bg-slate-900/80 p-4 space-y-3 hover:border-slate-700 transition"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <span className="relative flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                    </span>
                    <span className="text-xs font-mono font-bold text-white">{srv.id}</span>
                  </div>
                  <span className="rounded bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-500/20">
                    {srv.status}
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white leading-tight">{srv.name}</h4>
                  <p className="text-xs text-slate-400 mt-0.5">{srv.location} ({srv.region})</p>
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-950 p-2.5 space-y-1 text-[11px] font-mono">
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Latency:</span>
                    <span className="text-emerald-400 font-bold">{srv.latencyMs}ms</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Uptime:</span>
                    <span className="text-white">{srv.uptimePercentage}%</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-400">
                    <span>Protocol:</span>
                    <span className="text-indigo-300 truncate max-w-[140px]">{srv.protocol}</span>
                  </div>
                </div>

                <div>
                  <div className="text-[10px] uppercase font-bold text-slate-500 mb-1">Supported Rails:</div>
                  <div className="flex flex-wrap gap-1">
                    {srv.supportedRails.slice(0, 2).map((rail, rIdx) => (
                      <span
                        key={rIdx}
                        className="rounded bg-slate-800/60 px-1.5 py-0.5 text-[10px] text-slate-300"
                      >
                        {rail}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
