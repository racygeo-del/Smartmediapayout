import React, { useState } from "react";
import {
  Fingerprint,
  ShieldCheck,
  Smartphone,
  Laptop,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Lock,
  ArrowRight,
  RefreshCw,
  Zap,
} from "lucide-react";
import { useBiometrics } from "../hooks/useBiometrics";

interface BiometricSettingsCardProps {
  onOpenSecurityModal?: () => void;
  compact?: boolean;
}

export const BiometricSettingsCard: React.FC<BiometricSettingsCardProps> = ({
  compact = false,
}) => {
  const {
    preferences,
    updatePreferences,
    isHardwareSupported,
    hardwareLabel,
    fingerprintInfo,
    detectFingerprintMachine,
    isTesting,
    testBiometrics,
    lastTestResult,
  } = useBiometrics();

  const [toastMessage, setToastMessage] = useState<string>("");

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 3500);
  };

  const handleMasterToggle = () => {
    const nextVal = !preferences.enabled;
    updatePreferences({ enabled: nextVal });
    triggerToast(
      nextVal
        ? "Biometric authentication ENABLED for transfers and vault access"
        : "Biometric authentication DISABLED (Master Admin Password required)"
    );
  };

  const handleTestSensor = async () => {
    const res = await testBiometrics();
    triggerToast(res.message);
  };

  return (
    <div
      id="card-biometric-settings"
      className={`rounded-3xl border border-slate-800 bg-slate-900/90 shadow-xl transition ${
        compact ? "p-4 sm:p-5" : "p-6 sm:p-8"
      }`}
    >
      {/* Toast Notification */}
      {toastMessage && (
        <div className="mb-4 flex items-center gap-2 rounded-2xl border border-emerald-500/30 bg-emerald-950/40 p-3 text-xs text-emerald-300 animate-in fade-in">
          <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header section with master switch */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-5 border-b border-slate-800">
        <div className="flex items-start gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <Fingerprint className="h-6 w-6 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-base font-bold text-white">
                Biometric Authentication & Fast Unlock
              </h3>
              <span className="rounded-full bg-indigo-500/10 px-2 py-0.5 text-[10px] font-bold text-indigo-400 border border-indigo-500/20">
                FIDO2 / WebAuthn
              </span>
              {preferences.enabled ? (
                <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  Active
                </span>
              ) : (
                <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] font-bold text-slate-400 border border-slate-700">
                  Off
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Conveniently authorize banking push credits and vault settings using your device's biometric sensor.
            </p>
          </div>
        </div>

        {/* Master Toggle Switch */}
        <div className="flex items-center gap-3 self-end sm:self-center">
          <span
            className={`text-xs font-bold uppercase tracking-wider ${
              preferences.enabled ? "text-emerald-400" : "text-slate-500"
            }`}
          >
            {preferences.enabled ? "Biometrics ON" : "Biometrics OFF"}
          </span>
          <button
            id="btn-toggle-biometrics-master"
            type="button"
            onClick={handleMasterToggle}
            className={`relative inline-flex h-7 w-13 items-center rounded-full transition-colors focus:outline-none cursor-pointer ${
              preferences.enabled ? "bg-emerald-500" : "bg-slate-700"
            }`}
            title="Toggle Biometric Authentication"
          >
            <span
              className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-md transition-transform ${
                preferences.enabled ? "translate-x-7" : "translate-x-1"
              }`}
            />
          </button>
        </div>
      </div>

      {/* Hardware info and Sub-preferences */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5">
        {/* Hardware Status Block */}
        <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/10 p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400">
                Fingerprint Machine
              </span>
              <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>Detected</span>
              </span>
            </div>
            <div className="font-extrabold text-sm text-white flex items-center gap-2">
              <Fingerprint className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="truncate">{fingerprintInfo.sensorName}</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
              {fingerprintInfo.busInterface} • {fingerprintInfo.enclaveType}. One-touch unlock enabled.
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px]">
            <span className="text-slate-500 font-mono">Platform API:</span>
            <span className="text-emerald-400 font-mono font-bold">
              WebAuthn L3 / FIDO2
            </span>
          </div>
        </div>

        {/* Transfer Convenience Toggle */}
        <div
          onClick={() =>
            updatePreferences({
              autoAuthorizeTransfers: !preferences.autoAuthorizeTransfers,
            })
          }
          className={`rounded-2xl border p-4 cursor-pointer transition flex flex-col justify-between ${
            preferences.autoAuthorizeTransfers && preferences.enabled
              ? "border-emerald-500/40 bg-emerald-950/20"
              : "border-slate-800 bg-slate-800/40 hover:border-slate-700"
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                Transfer Convenience
              </span>
              <input
                id="checkbox-auto-authorize-transfers"
                type="checkbox"
                checked={preferences.autoAuthorizeTransfers && preferences.enabled}
                onChange={() => {}}
                className="h-4 w-4 rounded accent-emerald-500 pointer-events-none"
              />
            </div>
            <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Fast Push Credit Payouts</span>
            </h4>
            <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
              Skip typing Master Admin Password manually during banking transfers and disburse with one biometric touch.
            </p>
          </div>

          <div className="mt-3 pt-2 text-[11px] font-bold text-emerald-400 flex items-center gap-1">
            <span>{preferences.autoAuthorizeTransfers && preferences.enabled ? "Active" : "Disabled"}</span>
          </div>
        </div>

        {/* Vault Unlock Toggle */}
        <div
          onClick={() =>
            updatePreferences({
              vaultUnlockEnabled: !preferences.vaultUnlockEnabled,
            })
          }
          className={`rounded-2xl border p-4 cursor-pointer transition flex flex-col justify-between ${
            preferences.vaultUnlockEnabled && preferences.enabled
              ? "border-indigo-500/40 bg-indigo-950/20"
              : "border-slate-800 bg-slate-800/40 hover:border-slate-700"
          }`}
        >
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
                Vault Security
              </span>
              <input
                id="checkbox-vault-unlock"
                type="checkbox"
                checked={preferences.vaultUnlockEnabled && preferences.enabled}
                onChange={() => {}}
                className="h-4 w-4 rounded accent-indigo-500 pointer-events-none"
              />
            </div>
            <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-indigo-400 shrink-0" />
              <span>One-Touch Vault Access</span>
            </h4>
            <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
              Use biometric confirmation when adjusting automated funds generation rates and revenue allocation splits.
            </p>
          </div>

          <div className="mt-3 pt-2 text-[11px] font-bold text-indigo-400 flex items-center gap-1">
            <span>{preferences.vaultUnlockEnabled && preferences.enabled ? "Active" : "Disabled"}</span>
          </div>
        </div>
      </div>

      {/* Action Footer: Test Biometric Sensor & Status */}
      <div className="mt-5 pt-4 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="text-xs text-slate-400 flex items-center gap-2">
          <Lock className="w-3.5 h-3.5 text-slate-400" />
          <span>Biometric credentials never leave your secure enclave. Fallback access is secured by Master Admin Password.</span>
        </div>

        <button
          id="btn-test-biometrics"
          type="button"
          onClick={handleTestSensor}
          disabled={isTesting}
          className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs border border-slate-700 transition active:scale-[0.98] disabled:opacity-50"
        >
          {isTesting ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 text-indigo-400 animate-spin" />
              <span>Scanning Biometric Sensor...</span>
            </>
          ) : (
            <>
              <Fingerprint className="w-3.5 h-3.5 text-emerald-400" />
              <span>Test Biometric Sensor Now</span>
            </>
          )}
        </button>
      </div>

      {lastTestResult && (
        <div className="mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{lastTestResult.message}</span>
        </div>
      )}
    </div>
  );
};
