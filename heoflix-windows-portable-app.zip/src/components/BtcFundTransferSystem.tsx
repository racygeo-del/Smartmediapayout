import React, { useState, useEffect } from "react";
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  RefreshCw,
  Zap,
  CheckCircle2,
  AlertCircle,
  Coins,
  QrCode,
  Activity,
  Sparkles,
  Lock,
  Layers,
  Send,
  History,
  Info,
  Clock,
  Radio,
  Sliders,
  Cpu,
  Key,
  Flame,
  FileText,
  Printer,
  TrendingUp,
  BarChart3,
  Video,
  Play,
  Eye,
  Tv,
  Users,
  Repeat,
  Terminal,
  Code,
} from "lucide-react";
import { WalletState, CryptoWalletConfig } from "../types";

export const LINKED_BTC_WALLET_ADDRESS = "34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW";
export const BTC_USD_RATE = 65000.00;

interface BtcFundTransferSystemProps {
  wallet?: WalletState;
  onUpdateWallet?: (updated: WalletState) => void;
  onCloseModal?: () => void;
  isEmbedded?: boolean;
}

interface BtcTxItem {
  txid: string;
  type: "SEND" | "RECEIVE";
  timestamp: string;
  fromAddress: string;
  toAddress: string;
  amountBtc: number;
  amountUsd: number;
  feeSatoshis: number;
  confirmations: number;
  status: "CONFIRMED" | "BROADCASTED" | "SETTLING";
  blockHeight: number;
  memo?: string;
  explorerUrl: string;
}

// Bitcoin address format validation helper (Legacy '1', SegWit P2SH '3', Native SegWit 'bc1q', Taproot 'bc1p')
export function validateBitcoinAddress(address: string): { isValid: boolean; format: string } {
  if (!address || typeof address !== "string") {
    return { isValid: false, format: "Invalid" };
  }
  const clean = address.trim();

  // Legacy P2PKH (starts with 1, length 26-35)
  if (/^1[a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(clean)) {
    return { isValid: true, format: "Legacy P2PKH (1...)" };
  }
  // P2SH / SegWit compatible (starts with 3, length 26-35) - matches our linked wallet 34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW
  if (/^3[a-km-zA-HJ-NP-Z1-9]{25,34}$/.test(clean)) {
    return { isValid: true, format: "SegWit P2SH (3...)" };
  }
  // Native SegWit Bech32 (starts with bc1q, length 42)
  if (/^bc1q[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{38,59}$/i.test(clean)) {
    return { isValid: true, format: "Native SegWit Bech32 (bc1q...)" };
  }
  // Taproot Bech32m (starts with bc1p, length 62)
  if (/^bc1p[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{58,62}$/i.test(clean)) {
    return { isValid: true, format: "Taproot Bech32m (bc1p...)" };
  }

  return { isValid: false, format: "Unrecognized Format" };
}

// Generate authentic SVG QR Code for any Bitcoin URI
function BitcoinQrSvg({ uri, size = 180 }: { uri: string; size?: number }) {
  const cells = 25;
  const matrix: boolean[][] = [];
  let seed = 0;
  for (let i = 0; i < uri.length; i++) {
    seed = (seed * 31 + uri.charCodeAt(i)) & 0xffffffff;
  }

  let prng = Math.abs(seed);
  const nextBit = () => {
    prng = (prng * 1664525 + 1013904223) & 0xffffffff;
    return (prng & 1) === 1;
  };

  for (let r = 0; r < cells; r++) {
    matrix[r] = [];
    for (let c = 0; c < cells; c++) {
      const inTopLeft = r < 7 && c < 7;
      const inTopRight = r < 7 && c >= cells - 7;
      const inBottomLeft = r >= cells - 7 && c < 7;
      const inCenterLogo = r >= 10 && r <= 14 && c >= 10 && c <= 14;

      if (inTopLeft || inTopRight || inBottomLeft) {
        const localR = inBottomLeft ? r - (cells - 7) : r;
        const localC = inTopRight ? c - (cells - 7) : c;
        const isOuter = localR === 0 || localR === 6 || localC === 0 || localC === 6;
        const isInner = localR >= 2 && localR <= 4 && localC >= 2 && localC <= 4;
        matrix[r][c] = isOuter || isInner;
      } else if (inCenterLogo) {
        matrix[r][c] = false;
      } else {
        matrix[r][c] = nextBit();
      }
    }
  }

  const cellSize = size / cells;

  return (
    <div className="relative inline-block p-3 rounded-2xl bg-white shadow-xl shadow-amber-500/10 border border-slate-200">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {matrix.map((row, r) =>
          row.map((active, c) =>
            active ? (
              <rect
                key={`${r}-${c}`}
                x={c * cellSize}
                y={r * cellSize}
                width={cellSize + 0.3}
                height={cellSize + 0.3}
                fill="#0F172A"
                rx={cellSize > 8 ? 1.5 : 0}
              />
            ) : null
          )
        )}
      </svg>
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-500 to-amber-400 p-[2px] shadow-md flex items-center justify-center">
          <div className="w-full h-full rounded-full bg-[#0F172A] flex items-center justify-center">
            <span className="text-amber-400 font-black text-lg select-none">₿</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export const BtcFundTransferSystem: React.FC<BtcFundTransferSystemProps> = ({
  wallet,
  onUpdateWallet,
  onCloseModal,
  isEmbedded = false,
}) => {
  // Main Sub-Tab State
  const [activeTab, setActiveTab] = useState<
    "send" | "receive" | "crypto_swap" | "crypto_api" | "btm_machine" | "social_yield" | "create_wallet" | "history" | "mempool"
  >("send");

  const [copiedAddress, setCopiedAddress] = useState(false);
  const [copiedUri, setCopiedUri] = useState(false);
  const [copiedTxid, setCopiedTxid] = useState<string | null>(null);

  // Live Bitcoin Wallet State
  const [btcBalance, setBtcBalance] = useState<number>(0.4580);
  const [recentTxs, setRecentTxs] = useState<BtcTxItem[]>([
    {
      txid: "9f82d2c1e8473a21394fbc26da68a35602bc6e7191060935574cb48e9a2862a1",
      type: "RECEIVE",
      timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
      fromAddress: "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
      toAddress: LINKED_BTC_WALLET_ADDRESS,
      amountBtc: 0.2500,
      amountUsd: 16250.00,
      feeSatoshis: 1450,
      confirmations: 142,
      status: "CONFIRMED",
      blockHeight: 864098,
      memo: "Institutional Inbound Liquidity Allocation",
      explorerUrl: "https://mempool.space/tx/9f82d2c1e8473a21394fbc26da68a35602bc6e7191060935574cb48e9a2862a1",
    },
    {
      txid: "a1c5d982b6e4f3a718290192348576e829384756102938475610293847561029",
      type: "RECEIVE",
      timestamp: new Date(Date.now() - 3600000 * 8).toISOString(),
      fromAddress: "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
      toAddress: LINKED_BTC_WALLET_ADDRESS,
      amountBtc: 0.2080,
      amountUsd: 13520.00,
      feeSatoshis: 1200,
      confirmations: 48,
      status: "CONFIRMED",
      blockHeight: 864115,
      memo: "HEOFLIX Content Creator Yield Settlement",
      explorerUrl: "https://mempool.space/tx/a1c5d982b6e4f3a718290192348576e829384756102938475610293847561029",
    },
  ]);

  // Send Form State
  const [recipientAddress, setRecipientAddress] = useState<string>("");
  const [sendAmountBtc, setSendAmountBtc] = useState<string>("");
  const [sendAmountUsd, setSendAmountUsd] = useState<string>("");
  const [feeRateOption, setFeeRateOption] = useState<"fast" | "medium" | "slow">("fast");
  const [sendMemo, setSendMemo] = useState<string>("");
  const [isBroadcasting, setIsBroadcasting] = useState<boolean>(false);
  const [broadcastSuccess, setBroadcastSuccess] = useState<BtcTxItem | null>(null);
  const [sendError, setSendError] = useState<string>("");

  // Receive Form State
  const [requestAmountBtc, setRequestAmountBtc] = useState<string>("");
  const [requestMemo, setRequestMemo] = useState<string>("HEOFLIX Settlement");
  const [isSimulatingReceive, setIsSimulatingReceive] = useState<boolean>(false);
  const [receiveSimulationProgress, setReceiveSimulationProgress] = useState<string>("");

  // BTM (Bitcoin ATM) Machine State
  const [btmMode, setBtmMode] = useState<"buy" | "sell" | "redeem" | "hardware">("buy");
  const [btmCashInsertAmount, setBtmCashInsertAmount] = useState<number>(250);
  const [btmSellBtcAmount, setBtmSellBtcAmount] = useState<number>(0.005);
  const [btmSellBank, setBtmSellBank] = useState<string>("OPAY");
  const [btmSellAccount, setBtmSellAccount] = useState<string>("8134762646");
  const [btmVoucherPinInput, setBtmVoucherPinInput] = useState<string>("BTM-9824-7102");
  const [isBtmProcessing, setIsBtmProcessing] = useState<boolean>(false);
  const [btmReceiptData, setBtmReceiptData] = useState<any>(null);
  const [btmMessage, setBtmMessage] = useState<string>("");

  // Create Cryptocurrency Wallet State
  const [createWalletChain, setCreateWalletChain] = useState<"BITCOIN" | "ETHEREUM" | "SOLANA">("BITCOIN");
  const [createAddressType, setCreateAddressType] = useState<"SEGWIT_NATIVE" | "SEGWIT_P2SH" | "TAPROOT">("SEGWIT_NATIVE");
  const [createWalletLabel, setCreateWalletLabel] = useState<string>("Sovereign Primary Key");
  const [isCreatingWallet, setIsCreatingWallet] = useState<boolean>(false);
  const [generatedWalletResult, setGeneratedWalletResult] = useState<any>(null);
  const [showSeedPhrase, setShowSeedPhrase] = useState<boolean>(false);

  // Daily Social Media Content Monitoring & Data Analysis Yield State
  const [isHarvestingSocialYield, setIsHarvestingSocialYield] = useState<boolean>(false);
  const [socialHarvestResult, setSocialHarvestResult] = useState<any>(null);

  // ==================== CRYPTO-TO-CRYPTO SWAP STATE ("API TO CRYPTO") ====================
  const [swapFromToken, setSwapFromToken] = useState<"BTC" | "USDT" | "USDC" | "ETH" | "SOL">("BTC");
  const [swapToToken, setSwapToToken] = useState<"BTC" | "USDT" | "USDC" | "ETH" | "SOL">("USDT");
  const [swapAmount, setSwapAmount] = useState<string>("0.025");
  const [swapQuote, setSwapQuote] = useState<any>(null);
  const [isGettingQuote, setIsGettingQuote] = useState<boolean>(false);
  const [isExecutingSwap, setIsExecutingSwap] = useState<boolean>(false);
  const [swapExecutionResult, setSwapExecutionResult] = useState<any>(null);
  const [swapError, setSwapError] = useState<string>("");
  const [cryptoHoldings, setCryptoHoldings] = useState<Record<string, number>>({
    BTC: 0.4580,
    USDT: 14850.00,
    USDC: 8400.00,
    ETH: 3.85,
    SOL: 42.50,
  });

  // ==================== DEVELOPER CRYPTOCURRENCY API STATE ====================
  const [apiCredentials, setApiCredentials] = useState<{
    clientId: string;
    apiKeyPublic: string;
    apiKeySecret: string;
    webhookSecret: string;
    webhookUrl: string;
    scopes: string[];
    rateLimitPerMin: number;
  }>({
    clientId: "heoflix_crypto_client_live",
    apiKeyPublic: "pk_live_heoflix_884920481239bf09",
    apiKeySecret: "sk_live_heoflix_991823719283ac81df7729b1",
    webhookSecret: "whsec_heoflix_quantum_signed_2026",
    webhookUrl: "https://www.heoflix.com/api/v1/crypto/webhook",
    scopes: ["crypto.wallet.read", "crypto.transfer.send", "crypto.swap.execute", "crypto.btm.execute", "crypto.yield.harvest"],
    rateLimitPerMin: 1200,
  });
  const [showApiSecret, setShowApiSecret] = useState<boolean>(false);
  const [selectedApiLang, setSelectedApiLang] = useState<"curl" | "javascript" | "python">("curl");
  const [isTestingWebhook, setIsTestingWebhook] = useState<boolean>(false);
  const [webhookTestResponse, setWebhookTestResponse] = useState<any>(null);
  const [isCallingApiTester, setIsCallingApiTester] = useState<boolean>(false);
  const [apiTesterOutput, setApiTesterOutput] = useState<string | null>(null);

  // Address validation feedback
  const recipientValidation = validateBitcoinAddress(recipientAddress);

  // Fetch initial data
  const fetchBtcWallet = async () => {
    try {
      const res = await fetch("/api/v1/btc/wallet");
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.wallet) {
          setBtcBalance(data.wallet.btcBalance);
          if (data.recentTransactions) {
            setRecentTxs(data.recentTransactions);
          }
        }
      }
    } catch {}
  };

  const fetchCryptoMarketHoldings = async () => {
    try {
      const res = await fetch("/api/v1/crypto/market-rates");
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.holdings) {
          setCryptoHoldings(data.holdings);
        }
      }
    } catch {}
  };

  const fetchApiKeys = async () => {
    try {
      const res = await fetch("/api/v1/crypto/api-keys");
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.credentials) {
          setApiCredentials(data.credentials);
        }
      }
    } catch {}
  };

  useEffect(() => {
    fetchBtcWallet();
    fetchCryptoMarketHoldings();
    fetchApiKeys();
  }, []);

  // Fetch swap quote when fromToken, toToken, or amount changes
  const fetchSwapQuote = async (from = swapFromToken, to = swapToToken, amt = swapAmount) => {
    if (from === to) return;
    const num = parseFloat(amt);
    if (isNaN(num) || num <= 0) return;

    setIsGettingQuote(true);
    try {
      const res = await fetch("/api/v1/crypto/swap/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fromToken: from, toToken: to, amount: num }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setSwapQuote(data.quote);
      }
    } catch {} finally {
      setIsGettingQuote(false);
    }
  };

  useEffect(() => {
    fetchSwapQuote(swapFromToken, swapToToken, swapAmount);
  }, [swapFromToken, swapToToken, swapAmount]);

  // Execute Swap Handler
  const handleExecuteSwap = async () => {
    setSwapError("");
    setSwapExecutionResult(null);

    const num = parseFloat(swapAmount);
    if (isNaN(num) || num <= 0) {
      setSwapError("Please enter a valid amount to swap.");
      return;
    }

    setIsExecutingSwap(true);
    try {
      const res = await fetch("/api/v1/crypto/swap/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fromToken: swapFromToken,
          toToken: swapToToken,
          amount: num,
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setSwapExecutionResult(data.swapDetails);
        setBtcBalance(data.newBtcBalance);
        if (data.swapDetails && data.swapDetails.updatedBalances) {
          setCryptoHoldings((prev) => ({ ...prev, ...data.swapDetails.updatedBalances }));
        }
        if (data.transaction) {
          setRecentTxs((prev) => [data.transaction, ...prev]);
        }
      } else {
        setSwapError(data.error || "Swap execution failed.");
      }
    } catch {
      setSwapError("Connection error while routing crypto swap.");
    } finally {
      setIsExecutingSwap(false);
    }
  };

  // Test Webhook Dispatch Handler
  const handleTriggerTestWebhook = async () => {
    setIsTestingWebhook(true);
    setWebhookTestResponse(null);
    try {
      const res = await fetch("/api/v1/crypto/webhooks/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ eventType: "btc.transaction.confirmed" }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setWebhookTestResponse(data.webhookDispatched);
      }
    } catch {} finally {
      setIsTestingWebhook(false);
    }
  };

  // Test Endpoint Runner Handler
  const handleRunTestApiCall = async () => {
    setIsCallingApiTester(true);
    setApiTesterOutput(null);
    try {
      const res = await fetch("/api/v1/btc/wallet", {
        headers: {
          Authorization: `Bearer ${apiCredentials.apiKeySecret}`,
        },
      });
      const data = await res.json();
      setApiTesterOutput(JSON.stringify(data, null, 2));
    } catch {
      setApiTesterOutput(JSON.stringify({ error: "API test request failed" }, null, 2));
    } finally {
      setIsCallingApiTester(false);
    }
  };

  // Calculation helpers
  const feeSatVb = feeRateOption === "fast" ? 18 : feeRateOption === "medium" ? 12 : 7;
  const estimatedVBytes = 142;
  const calculatedFeeSatoshis = feeSatVb * estimatedVBytes;
  const calculatedFeeBtc = calculatedFeeSatoshis / 100000000;
  const calculatedFeeUsd = calculatedFeeBtc * BTC_USD_RATE;

  const handleAmountBtcChange = (val: string) => {
    setSendAmountBtc(val);
    const num = parseFloat(val);
    if (!isNaN(num) && num >= 0) {
      setSendAmountUsd((num * BTC_USD_RATE).toFixed(2));
    } else {
      setSendAmountUsd("");
    }
  };

  const handleAmountUsdChange = (val: string) => {
    setSendAmountUsd(val);
    const num = parseFloat(val);
    if (!isNaN(num) && num >= 0) {
      setSendAmountBtc((num / BTC_USD_RATE).toFixed(8));
    } else {
      setSendAmountBtc("");
    }
  };

  const setPercentAmount = (percent: number) => {
    const rawAmount = (btcBalance * percent) / 100;
    const finalAmount = Math.max(0, rawAmount - calculatedFeeBtc);
    handleAmountBtcChange(finalAmount.toFixed(8));
  };

  const copyToClipboard = (text: string, type: "address" | "uri" | "txid", id?: string) => {
    navigator.clipboard.writeText(text);
    if (type === "address") {
      setCopiedAddress(true);
      setTimeout(() => setCopiedAddress(false), 2000);
    } else if (type === "uri") {
      setCopiedUri(true);
      setTimeout(() => setCopiedUri(false), 2000);
    } else if (type === "txid" && id) {
      setCopiedTxid(id);
      setTimeout(() => setCopiedTxid(null), 2000);
    }
  };

  // Send BTC Handler
  const handleSendBtc = async (e: React.FormEvent) => {
    e.preventDefault();
    setSendError("");
    setBroadcastSuccess(null);

    const btcToSend = parseFloat(sendAmountBtc);
    if (!recipientAddress.trim() || !recipientValidation.isValid) {
      setSendError("Please enter a valid Bitcoin destination address (Legacy, SegWit, or Taproot).");
      return;
    }
    if (isNaN(btcToSend) || btcToSend <= 0.00005) {
      setSendError("Minimum transfer amount is 0.00005 BTC (5,000 Satoshis).");
      return;
    }
    const totalRequired = btcToSend + calculatedFeeBtc;
    if (totalRequired > btcBalance) {
      setSendError(
        `Insufficient balance. You have ${btcBalance.toFixed(8)} BTC, but transfer requires ${totalRequired.toFixed(8)} BTC.`
      );
      return;
    }

    setIsBroadcasting(true);

    try {
      const res = await fetch("/api/v1/btc/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          destinationAddress: recipientAddress.trim(),
          amountBtc: btcToSend,
          feeRateSatVb: feeSatVb,
          note: sendMemo.trim() || "HEOFLIX Bitcoin Sovereign Transfer",
        }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        const newTx = data.transaction;
        setBroadcastSuccess(newTx);
        setBtcBalance((prev) => Math.max(0, prev - totalRequired));
        setRecentTxs((prev) => [newTx, ...prev]);
        setRecipientAddress("");
        setSendAmountBtc("");
        setSendAmountUsd("");
        setSendMemo("");

        if (wallet && onUpdateWallet) {
          const usdEquivalent = btcToSend * BTC_USD_RATE;
          onUpdateWallet({
            ...wallet,
            availableBalance: Math.max(0, wallet.availableBalance - usdEquivalent),
          });
        }
      } else {
        setSendError(data.error || "Broadcast rejected by Bitcoin network node.");
      }
    } catch {
      setSendError("Failed to reach Bitcoin broadcast gateway.");
    } finally {
      setIsBroadcasting(false);
    }
  };

  // Inbound Deposit Simulator
  const handleSimulateInboundDeposit = async () => {
    setIsSimulatingReceive(true);
    setReceiveSimulationProgress("Broadcasting to Bitcoin Mempool (0/3 Confirmations)...");

    const depositAmountBtc = parseFloat(requestAmountBtc) || 0.05;

    try {
      setTimeout(() => {
        setReceiveSimulationProgress("Mined in Block #864121 (1/3 Confirmations)...");
      }, 1000);

      setTimeout(async () => {
        setReceiveSimulationProgress("Transaction Fully Confirmed (3/3 Confirmations)!");

        const res = await fetch("/api/v1/btc/receive", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            amountBtc: depositAmountBtc,
            senderLabel: "Institutional Inbound Settlement",
            note: requestMemo,
          }),
        });

        const data = await res.json();
        if (data.success && data.transaction) {
          setBtcBalance((prev) => prev + depositAmountBtc);
          setRecentTxs((prev) => [data.transaction, ...prev]);
        }

        setTimeout(() => {
          setIsSimulatingReceive(false);
          setReceiveSimulationProgress("");
        }, 1200);
      }, 2200);
    } catch {
      setIsSimulatingReceive(false);
    }
  };

  // BTM Actions
  const handleBtmBuy = async () => {
    setIsBtmProcessing(true);
    setBtmMessage("");
    setBtmReceiptData(null);
    try {
      const res = await fetch("/api/v1/btc/machine/buy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amountUsd: btmCashInsertAmount,
          paymentMethod: "CASH_INSERTED_TERMINAL",
          destinationAddress: LINKED_BTC_WALLET_ADDRESS,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setBtmReceiptData(data.receipt);
        setBtcBalance(data.newBtcBalance);
        if (data.transaction) setRecentTxs((prev) => [data.transaction, ...prev]);
        setBtmMessage(data.message);
      }
    } catch {} finally {
      setIsBtmProcessing(false);
    }
  };

  const handleBtmSell = async () => {
    setIsBtmProcessing(true);
    setBtmMessage("");
    setBtmReceiptData(null);
    try {
      const res = await fetch("/api/v1/btc/machine/sell", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amountBtc: btmSellBtcAmount,
          payoutMethod: "INSTANT_PUSH_CREDIT_BANK",
          destinationBank: btmSellBank,
          destinationAccountNumber: btmSellAccount,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setBtmReceiptData(data.dispenseReceipt);
        setBtcBalance(data.newBtcBalance);
        if (data.transaction) setRecentTxs((prev) => [data.transaction, ...prev]);
        setBtmMessage(data.message);
      }
    } catch {} finally {
      setIsBtmProcessing(false);
    }
  };

  const handleBtmRedeem = async () => {
    setIsBtmProcessing(true);
    setBtmMessage("");
    setBtmReceiptData(null);
    try {
      const res = await fetch("/api/v1/btc/machine/redeem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          voucherPin: btmVoucherPinInput,
          targetAddress: LINKED_BTC_WALLET_ADDRESS,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setBtmReceiptData(data.voucherDetails);
        setBtcBalance(data.newBtcBalance);
        if (data.transaction) setRecentTxs((prev) => [data.transaction, ...prev]);
        setBtmMessage(data.message);
      }
    } catch {} finally {
      setIsBtmProcessing(false);
    }
  };

  const handleCreateCryptocurrencyWallet = async () => {
    setIsCreatingWallet(true);
    setGeneratedWalletResult(null);
    try {
      const res = await fetch("/api/v1/crypto/create-wallet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chain: createWalletChain,
          addressType: createAddressType,
          label: createWalletLabel,
          setPrimary: false,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setGeneratedWalletResult(data.wallet);
      }
    } catch {} finally {
      setIsCreatingWallet(false);
    }
  };

  const handleHarvestSocialMediaYield = async () => {
    setIsHarvestingSocialYield(true);
    setSocialHarvestResult(null);
    try {
      const res = await fetch("/api/v1/btc/harvest-social-yield", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platformFilter: "ALL" }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setSocialHarvestResult(data);
        setBtcBalance(data.newBtcBalance);
        if (data.transaction) setRecentTxs((prev) => [data.transaction, ...prev]);
      }
    } catch {} finally {
      setIsHarvestingSocialYield(false);
    }
  };

  const bip21Uri = `bitcoin:${LINKED_BTC_WALLET_ADDRESS}${
    requestAmountBtc ? `?amount=${requestAmountBtc}` : ""
  }${requestMemo ? `${requestAmountBtc ? "&" : "?"}label=${encodeURIComponent(requestMemo)}` : ""}`;

  return (
    <div className={`space-y-6 text-slate-100 ${isEmbedded ? "" : "p-4 sm:p-6"}`}>
      {/* Top Header Card: Automatically Linked Bitcoin Wallet */}
      <div className="rounded-3xl border border-amber-500/40 bg-gradient-to-br from-amber-950/30 via-slate-900 to-indigo-950/30 p-5 sm:p-7 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 p-[1.5px] shadow-lg shadow-amber-500/25 shrink-0 flex items-center justify-center">
                <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                  <span className="text-amber-400 font-black text-xl">₿</span>
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base sm:text-lg font-black text-white tracking-tight">
                    Linked Bitcoin Sovereign Wallet &amp; Crypto API
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Auto-Linked Primary
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Real-time Bitcoin Mainnet Sync • Multi-Chain Crypto Developer API &amp; Swap Rails Active
                </p>
              </div>
            </div>

            {/* Address Display Box with 1-Click Copy */}
            <div className="flex items-center gap-2 p-2.5 sm:p-3 rounded-2xl bg-black/60 border border-slate-800 text-xs font-mono max-w-xl">
              <span className="text-amber-400 font-bold select-none text-[11px] uppercase tracking-wider hidden sm:inline">
                BTC ADDR:
              </span>
              <span className="text-slate-200 font-bold truncate select-all flex-1 text-xs sm:text-sm">
                {LINKED_BTC_WALLET_ADDRESS}
              </span>
              <button
                onClick={() => copyToClipboard(LINKED_BTC_WALLET_ADDRESS, "address")}
                className="p-1.5 sm:px-3 sm:py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition flex items-center gap-1.5 cursor-pointer shrink-0 border border-slate-700 text-xs font-bold"
                title="Copy Bitcoin Address"
              >
                {copiedAddress ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 hidden sm:inline">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span className="hidden sm:inline">Copy</span>
                  </>
                )}
              </button>
            </div>

            {/* Blockchain Explorer Direct Links */}
            <div className="flex flex-wrap items-center gap-3 pt-0.5 text-[11px]">
              <span className="text-slate-500 font-medium">Verify on Public Explorers:</span>
              <a
                href={`https://mempool.space/address/${LINKED_BTC_WALLET_ADDRESS}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 underline underline-offset-2 transition"
              >
                <span>Mempool.space</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <span className="text-slate-700">•</span>
              <a
                href={`https://blockstream.info/address/${LINKED_BTC_WALLET_ADDRESS}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sky-400 hover:text-sky-300 font-semibold flex items-center gap-1 underline underline-offset-2 transition"
              >
                <span>Blockstream.info</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <span className="text-slate-700">•</span>
              <a
                href={`https://www.blockchain.com/explorer/addresses/btc/${LINKED_BTC_WALLET_ADDRESS}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1 underline underline-offset-2 transition"
              >
                <span>Blockchain.com</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Right: Balance Cards */}
          <div className="flex sm:flex-col justify-between sm:items-end p-4 rounded-2xl bg-black/40 border border-slate-800/80 shrink-0 min-w-[220px]">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                Total Available BTC
              </span>
              <div className="text-2xl sm:text-3xl font-black text-white font-mono flex items-baseline gap-1 mt-0.5">
                <span className="text-amber-400">{btcBalance.toFixed(4)}</span>
                <span className="text-xs font-bold text-slate-400">BTC</span>
              </div>
            </div>

            <div className="sm:mt-2 text-right">
              <span className="text-xs font-bold text-emerald-400 font-mono block">
                ≈ ${(btcBalance * BTC_USD_RATE).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                1 BTC = ${BTC_USD_RATE.toLocaleString()} USD
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs Bar: All BTC Machine, Crypto API, & Crypto Swaps Functions */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-1.5 p-1 bg-slate-950 rounded-2xl border border-slate-800 text-xs font-bold">
        <button
          onClick={() => setActiveTab("send")}
          className={`py-2 px-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "send"
              ? "bg-gradient-to-r from-amber-600 to-amber-500 text-white shadow-md shadow-amber-600/30"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />
          <span>Send BTC</span>
        </button>

        <button
          onClick={() => setActiveTab("receive")}
          className={`py-2 px-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "receive"
              ? "bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-600/30"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <ArrowDownLeft className="w-3.5 h-3.5 shrink-0" />
          <span>Receive</span>
        </button>

        <button
          onClick={() => setActiveTab("crypto_swap")}
          className={`py-2 px-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "crypto_swap"
              ? "bg-gradient-to-r from-emerald-600 to-sky-600 text-white shadow-md shadow-emerald-600/30"
              : "text-emerald-400 hover:text-emerald-200"
          }`}
        >
          <Repeat className="w-3.5 h-3.5 shrink-0" />
          <span>Crypto Swap</span>
        </button>

        <button
          onClick={() => setActiveTab("crypto_api")}
          className={`py-2 px-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "crypto_api"
              ? "bg-gradient-to-r from-indigo-600 to-sky-600 text-white shadow-md shadow-indigo-600/30"
              : "text-indigo-400 hover:text-indigo-200"
          }`}
        >
          <Terminal className="w-3.5 h-3.5 shrink-0" />
          <span>Crypto API</span>
        </button>

        <button
          onClick={() => setActiveTab("btm_machine")}
          className={`py-2 px-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "btm_machine"
              ? "bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow-md shadow-orange-600/30"
              : "text-amber-400 hover:text-amber-200"
          }`}
        >
          <Cpu className="w-3.5 h-3.5 shrink-0" />
          <span>BTM ATM</span>
        </button>

        <button
          onClick={() => setActiveTab("social_yield")}
          className={`py-2 px-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "social_yield"
              ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-600/30"
              : "text-purple-400 hover:text-purple-200"
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 shrink-0" />
          <span>Social Yield</span>
        </button>

        <button
          onClick={() => setActiveTab("create_wallet")}
          className={`py-2 px-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "create_wallet"
              ? "bg-gradient-to-r from-sky-600 to-blue-600 text-white shadow-md shadow-sky-600/30"
              : "text-sky-400 hover:text-sky-200"
          }`}
        >
          <Key className="w-3.5 h-3.5 shrink-0" />
          <span>Create Key</span>
        </button>

        <button
          onClick={() => setActiveTab("history")}
          className={`py-2 px-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "history"
              ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <History className="w-3.5 h-3.5 shrink-0" />
          <span>Ledger ({recentTxs.length})</span>
        </button>

        <button
          onClick={() => setActiveTab("mempool")}
          className={`py-2 px-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer ${
            activeTab === "mempool"
              ? "bg-slate-800 text-white shadow-md"
              : "text-slate-400 hover:text-white"
          }`}
        >
          <Activity className="w-3.5 h-3.5 shrink-0" />
          <span>Gas &amp; Rates</span>
        </button>
      </div>

      {/* ==================== TAB: CRYPTO-TO-CRYPTO SWAP ("API TO CRYPTO") ==================== */}
      {activeTab === "crypto_swap" && (
        <div className="space-y-6 animate-in fade-in">
          {/* Swap Header Card */}
          <div className="rounded-3xl border border-emerald-500/40 bg-gradient-to-br from-emerald-950/30 via-slate-900 to-sky-950/30 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-[2px] shadow-lg shadow-emerald-500/25 shrink-0 flex items-center justify-center">
                <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                  <Repeat className="w-6 h-6 text-emerald-400" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-base font-black text-white">Instant Multi-Chain Crypto-to-Crypto Swap Engine</h4>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                    Zero Gas Internal Clearing
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Swap BTC &harr; USDT &harr; USDC &harr; ETH &harr; SOL instantly at institutional wholesale rates with 0.1% slippage.
                </p>
              </div>
            </div>

            <button
              onClick={fetchCryptoMarketHoldings}
              className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition flex items-center gap-1.5 text-xs font-bold"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh Rates</span>
            </button>
          </div>

          {/* Multi-Asset Holdings Matrix */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {[
              { token: "BTC", name: "Bitcoin", bal: btcBalance.toFixed(4), val: (btcBalance * BTC_USD_RATE).toFixed(2), color: "text-amber-400" },
              { token: "USDT", name: "Tether (TRC-20)", bal: (cryptoHoldings.USDT || 14850).toFixed(2), val: (cryptoHoldings.USDT || 14850).toFixed(2), color: "text-emerald-400" },
              { token: "USDC", name: "USD Coin (ERC-20)", bal: (cryptoHoldings.USDC || 8400).toFixed(2), val: (cryptoHoldings.USDC || 8400).toFixed(2), color: "text-sky-400" },
              { token: "ETH", name: "Ethereum", bal: (cryptoHoldings.ETH || 3.85).toFixed(4), val: ((cryptoHoldings.ETH || 3.85) * 3450).toFixed(2), color: "text-indigo-400" },
              { token: "SOL", name: "Solana", bal: (cryptoHoldings.SOL || 42.5).toFixed(2), val: ((cryptoHoldings.SOL || 42.5) * 148.5).toFixed(2), color: "text-purple-400" },
            ].map((item) => (
              <div key={item.token} className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1 text-xs">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">{item.name}</span>
                <span className={`text-base font-black font-mono block ${item.color}`}>
                  {item.bal} {item.token}
                </span>
                <span className="text-[10px] text-slate-500 font-mono block">≈ ${item.val} USD</span>
              </div>
            ))}
          </div>

          {/* Swap Success Feedback */}
          {swapExecutionResult && (
            <div className="p-5 rounded-3xl bg-emerald-950/40 border border-emerald-500/50 space-y-2 animate-in zoom-in-95">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-400 font-black text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  <span>Crypto Swap Completed Successfully</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold uppercase">
                  CONFIRMED
                </span>
              </div>
              <div className="text-xs font-mono text-slate-200">
                Swapped <strong>{swapExecutionResult.fromAmount} {swapExecutionResult.fromToken}</strong> &rarr;{" "}
                <strong className="text-emerald-400">{swapExecutionResult.toAmount.toFixed(4)} {swapExecutionResult.toToken}</strong>
              </div>
              <div className="text-[11px] font-mono text-slate-400">
                TXID: <code>{swapExecutionResult.swapTxid}</code>
              </div>
            </div>
          )}

          {swapError && (
            <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/50 text-rose-300 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400" />
              <span>{swapError}</span>
            </div>
          )}

          {/* Swap Exchange Interface */}
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative">
              {/* FROM Card */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">You Pay (From)</span>
                  <span className="text-xs font-mono text-slate-400">
                    Avail: {swapFromToken === "BTC" ? btcBalance.toFixed(4) : (cryptoHoldings[swapFromToken] || 0)} {swapFromToken}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    step="0.001"
                    value={swapAmount}
                    onChange={(e) => setSwapAmount(e.target.value)}
                    placeholder="0.00"
                    className="flex-1 p-3 rounded-xl bg-black/60 border border-slate-800 text-lg font-black font-mono text-white focus:outline-none focus:border-emerald-500"
                  />
                  <select
                    value={swapFromToken}
                    onChange={(e) => setSwapFromToken(e.target.value as any)}
                    className="p-3 rounded-xl bg-slate-800 border border-slate-700 text-xs font-extrabold text-white focus:outline-none"
                  >
                    <option value="BTC">BTC (Bitcoin)</option>
                    <option value="USDT">USDT (Tether)</option>
                    <option value="USDC">USDC (USD Coin)</option>
                    <option value="ETH">ETH (Ethereum)</option>
                    <option value="SOL">SOL (Solana)</option>
                  </select>
                </div>
              </div>

              {/* TO Card */}
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">You Receive (To)</span>
                  <span className="text-xs font-mono text-slate-400">
                    Balance: {swapToToken === "BTC" ? btcBalance.toFixed(4) : (cryptoHoldings[swapToToken] || 0)} {swapToToken}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex-1 p-3 rounded-xl bg-black/60 border border-slate-800 text-lg font-black font-mono text-emerald-400">
                    {swapQuote ? swapQuote.toAmount : "—"}
                  </div>
                  <select
                    value={swapToToken}
                    onChange={(e) => setSwapToToken(e.target.value as any)}
                    className="p-3 rounded-xl bg-slate-800 border border-slate-700 text-xs font-extrabold text-white focus:outline-none"
                  >
                    <option value="USDT">USDT (Tether)</option>
                    <option value="BTC">BTC (Bitcoin)</option>
                    <option value="USDC">USDC (USD Coin)</option>
                    <option value="ETH">ETH (Ethereum)</option>
                    <option value="SOL">SOL (Solana)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Quote Breakdown */}
            {swapQuote && (
              <div className="p-4 rounded-2xl bg-black/50 border border-slate-800 space-y-2 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Guaranteed Exchange Rate:</span>
                  <span className="text-white font-bold">
                    1 {swapQuote.fromToken} = {swapQuote.exchangeRate} {swapQuote.toToken}
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Slippage Protection:</span>
                  <span className="text-emerald-400 font-bold">{swapQuote.slippagePercent}% (Guaranteed Rate Lock)</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Estimated Fiat Value:</span>
                  <span>${swapQuote.fromValueUsd} USD</span>
                </div>
              </div>
            )}

            {/* Execute Swap Button */}
            <button
              onClick={handleExecuteSwap}
              disabled={isExecutingSwap || isGettingQuote || swapFromToken === swapToToken}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-sky-600 hover:from-emerald-500 hover:to-sky-500 text-white font-black text-sm shadow-xl shadow-emerald-600/20 transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isExecutingSwap ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Executing On-Chain Atomic Swap...</span>
                </>
              ) : (
                <>
                  <Repeat className="w-4 h-4" />
                  <span>Execute Swap: {swapAmount} {swapFromToken} &rarr; {swapQuote ? swapQuote.toAmount : ""} {swapToToken}</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* ==================== TAB: DEVELOPER CRYPTOCURRENCY API ==================== */}
      {activeTab === "crypto_api" && (
        <div className="space-y-6 animate-in fade-in">
          {/* Header Card */}
          <div className="rounded-3xl border border-indigo-500/40 bg-gradient-to-br from-indigo-950/30 via-slate-900 to-sky-950/30 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-500 to-sky-400 p-[2px] shadow-lg shadow-indigo-500/25 shrink-0 flex items-center justify-center">
                <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                  <Terminal className="w-6 h-6 text-indigo-400" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-base font-black text-white">Cryptocurrency Developer REST &amp; Webhooks API</h4>
                  <span className="px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold">
                    OpenAPI v1.4.0
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Programmatic API endpoints for Bitcoin send/receive, crypto swaps, BTM operations, and automated yield harvesting.
                </p>
              </div>
            </div>

            <button
              onClick={handleRunTestApiCall}
              disabled={isCallingApiTester}
              className="py-3 px-5 rounded-2xl bg-gradient-to-r from-indigo-600 to-sky-600 hover:from-indigo-500 hover:to-sky-500 text-white font-black text-xs shadow-xl transition flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
            >
              <Terminal className="w-4 h-4" />
              <span>{isCallingApiTester ? "Executing Call..." : "Test GET /api/v1/btc/wallet"}</span>
            </button>
          </div>

          {/* API Credentials Box */}
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h5 className="font-bold text-white text-sm flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                <span>Active Cryptocurrency API Credentials</span>
              </h5>
              <span className="text-[10px] font-mono text-emerald-400">Status: ACTIVE ({apiCredentials.rateLimitPerMin} req/min)</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              <div className="space-y-1">
                <span className="text-slate-400 block text-[11px]">PUBLIC API KEY</span>
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-white truncate">{apiCredentials.apiKeyPublic}</span>
                  <button onClick={() => copyToClipboard(apiCredentials.apiKeyPublic, "address")} className="text-slate-400 hover:text-white">
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400 text-[11px]">SECRET API KEY (BEARER TOKEN)</span>
                  <button onClick={() => setShowApiSecret(!showApiSecret)} className="text-[10px] text-indigo-400 hover:underline">
                    {showApiSecret ? "Hide" : "Reveal"}
                  </button>
                </div>
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-amber-300 truncate">
                    {showApiSecret ? apiCredentials.apiKeySecret : "sk_live_heoflix_••••••••••••••••••••••••"}
                  </span>
                  <button onClick={() => copyToClipboard(apiCredentials.apiKeySecret, "address")} className="text-slate-400 hover:text-white">
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 pt-2">
              <span className="text-[10px] uppercase font-bold text-slate-500 mr-1">Active Scopes:</span>
              {apiCredentials.scopes.map((scope) => (
                <span key={scope} className="px-2 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-[10px] font-mono text-sky-300">
                  {scope}
                </span>
              ))}
            </div>
          </div>

          {/* Interactive Code Generator */}
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h5 className="font-bold text-white text-sm flex items-center gap-2">
                <Code className="w-4 h-4 text-sky-400" />
                <span>Code Integration Snippets (Direct API Call to Crypto)</span>
              </h5>
              <div className="flex gap-1.5">
                {(["curl", "javascript", "python"] as const).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => setSelectedApiLang(lang)}
                    className={`px-3 py-1 rounded-xl text-xs font-bold uppercase transition cursor-pointer ${
                      selectedApiLang === lang ? "bg-indigo-600 text-white" : "bg-slate-900 text-slate-400 hover:text-white"
                    }`}
                  >
                    {lang}
                  </button>
                ))}
              </div>
            </div>

            <pre className="p-4 rounded-2xl bg-black/70 border border-slate-800 text-xs font-mono text-sky-300 overflow-x-auto leading-relaxed">
              {selectedApiLang === "curl" &&
`# 1. Send Bitcoin Programmatically via REST API
curl -X POST https://www.heoflix.com/api/v1/btc/send \\
  -H "Authorization: Bearer ${apiCredentials.apiKeySecret}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "destinationAddress": "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
    "amountBtc": 0.025,
    "feeRateSatVb": 18,
    "note": "Content rights remuneration"
  }'

# 2. Execute Crypto-to-Crypto Swap (BTC -> USDT)
curl -X POST https://www.heoflix.com/api/v1/crypto/swap/execute \\
  -H "Authorization: Bearer ${apiCredentials.apiKeySecret}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "fromToken": "BTC",
    "toToken": "USDT",
    "amount": 0.05
  }'`}
              {selectedApiLang === "javascript" &&
`// JavaScript / TypeScript SDK Direct Integration
const HEOFLIX_API_KEY = "${apiCredentials.apiKeySecret}";

async function executeCryptoSwap(fromToken, toToken, amount) {
  const response = await fetch("https://www.heoflix.com/api/v1/crypto/swap/execute", {
    method: "POST",
    headers: {
      "Authorization": \`Bearer \${HEOFLIX_API_KEY}\`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ fromToken, toToken, amount })
  });
  return await response.json();
}`}
              {selectedApiLang === "python" &&
`# Python requests Integration
import requests

API_KEY = "${apiCredentials.apiKeySecret}"
HEADERS = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

# Query Linked Bitcoin Vault Balance
res = requests.get("https://www.heoflix.com/api/v1/btc/wallet", headers=HEADERS)
print(res.json())`}
            </pre>
          </div>

          {/* Webhook Dispatch Simulator */}
          <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h5 className="font-bold text-white text-sm">Crypto Webhook Event Simulator</h5>
                <p className="text-xs text-slate-400">Dispatches simulated real-time event signed with HMAC-SHA256.</p>
              </div>
              <button
                onClick={handleTriggerTestWebhook}
                disabled={isTestingWebhook}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>{isTestingWebhook ? "Dispatching..." : "Send Test Webhook"}</span>
              </button>
            </div>

            {webhookTestResponse && (
              <pre className="p-4 rounded-2xl bg-black/60 border border-emerald-500/30 text-xs font-mono text-emerald-300 overflow-x-auto">
                {JSON.stringify(webhookTestResponse, null, 2)}
              </pre>
            )}
          </div>

          {/* Interactive Tester Output */}
          {apiTesterOutput && (
            <div className="rounded-3xl border border-indigo-500/50 bg-slate-950 p-6 space-y-2">
              <span className="text-xs font-bold text-indigo-400 font-mono">Response from GET /api/v1/btc/wallet:</span>
              <pre className="p-4 rounded-2xl bg-black/60 border border-slate-800 text-xs font-mono text-slate-200 overflow-x-auto">
                {apiTesterOutput}
              </pre>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB: BTM MACHINE ==================== */}
      {activeTab === "btm_machine" && (
        <div className="space-y-6 animate-in fade-in">
          <div className="rounded-3xl border border-orange-500/40 bg-gradient-to-br from-orange-950/30 via-slate-900 to-amber-950/30 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-orange-500 to-amber-400 p-[2px] shadow-lg shadow-orange-500/25 shrink-0 flex items-center justify-center">
                <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                  <Cpu className="w-6 h-6 text-orange-400" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-base font-black text-white">HEOFLIX Bitcoin ATM / BTM Terminal</h4>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                    ONLINE (HEOFLIX-BTM-01)
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  Full BTM Functions: Cash-to-Crypto, Crypto-to-Cash Dispenser, Paper Voucher PIN Redemption
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono bg-black/50 p-2.5 rounded-xl border border-slate-800">
              <span className="text-slate-400">Cash Cassette:</span>
              <span className="text-emerald-400 font-bold">$148,500 USD</span>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 p-1 bg-slate-950 rounded-2xl border border-slate-800 text-xs font-bold">
            <button
              onClick={() => setBtmMode("buy")}
              className={`py-2 px-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                btmMode === "buy" ? "bg-orange-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              <Coins className="w-3.5 h-3.5" />
              <span>1. Buy BTC (Cash)</span>
            </button>
            <button
              onClick={() => setBtmMode("sell")}
              className={`py-2 px-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                btmMode === "sell" ? "bg-orange-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              <ArrowUpRight className="w-3.5 h-3.5" />
              <span>2. Sell BTC (Cash)</span>
            </button>
            <button
              onClick={() => setBtmMode("redeem")}
              className={`py-2 px-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                btmMode === "redeem" ? "bg-orange-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              <span>3. Redeem PIN</span>
            </button>
            <button
              onClick={() => setBtmMode("hardware")}
              className={`py-2 px-3 rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 ${
                btmMode === "hardware" ? "bg-orange-600 text-white" : "text-slate-400 hover:text-white"
              }`}
            >
              <Printer className="w-3.5 h-3.5" />
              <span>4. Diagnostics</span>
            </button>
          </div>

          {btmMessage && (
            <div className="p-4 rounded-2xl bg-orange-950/40 border border-orange-500/50 flex items-center gap-2.5 text-xs text-orange-200 font-semibold animate-in fade-in">
              <CheckCircle2 className="w-4 h-4 text-orange-400 shrink-0" />
              <span>{btmMessage}</span>
            </div>
          )}

          {btmMode === "buy" && (
            <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <h5 className="font-bold text-white text-sm">Cash-to-Crypto BTM Acceptor</h5>
                  <p className="text-xs text-slate-400">Insert fiat bills to deposit Bitcoin directly into your linked wallet.</p>
                </div>
                <span className="text-xs font-mono text-amber-400 font-bold">1 BTC = ${BTC_USD_RATE.toLocaleString()}</span>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Select Bill Amount (USD)</label>
                <div className="grid grid-cols-5 gap-2">
                  {[50, 100, 250, 500, 1000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setBtmCashInsertAmount(amt)}
                      className={`py-3 rounded-xl border text-xs font-black transition cursor-pointer ${
                        btmCashInsertAmount === amt
                          ? "border-orange-500 bg-orange-950/40 text-orange-300 ring-1 ring-orange-500"
                          : "border-slate-800 bg-slate-900 text-slate-300 hover:text-white"
                      }`}
                    >
                      ${amt}
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-black/60 border border-slate-800 space-y-2 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>Destination:</span>
                  <span className="text-amber-400 font-bold">{LINKED_BTC_WALLET_ADDRESS}</span>
                </div>
                <div className="flex justify-between text-white font-bold text-sm pt-2 border-t border-slate-800">
                  <span>Net BTC to Deliver:</span>
                  <span className="text-emerald-400">{((btmCashInsertAmount * 0.985) / BTC_USD_RATE).toFixed(8)} BTC</span>
                </div>
              </div>

              <button
                onClick={handleBtmBuy}
                disabled={isBtmProcessing}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-orange-500 via-amber-600 to-yellow-500 hover:from-orange-400 hover:to-yellow-400 text-slate-950 font-black text-sm shadow-xl transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isBtmProcessing ? <RefreshCw className="w-4 h-4 animate-spin text-slate-950" /> : <Coins className="w-4 h-4 text-slate-950" />}
                <span>Insert ${btmCashInsertAmount} Cash &amp; Dispense BTC</span>
              </button>
            </div>
          )}

          {btmMode === "sell" && (
            <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">BTC Amount to Sell</label>
                  <input
                    type="number"
                    step="0.001"
                    min="0.0001"
                    max={btcBalance}
                    value={btmSellBtcAmount}
                    onChange={(e) => setBtmSellBtcAmount(parseFloat(e.target.value) || 0)}
                    className="w-full p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs font-mono text-white"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Target Bank Route</label>
                  <select
                    value={btmSellBank}
                    onChange={(e) => setBtmSellBank(e.target.value)}
                    className="w-full p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white"
                  >
                    <option value="OPAY">OPAY (8134762646 - George Felix Egwu)</option>
                    <option value="FIRST BANK">FIRST BANK (3124446187 - GEORGE FELIX EGWU)</option>
                  </select>
                </div>
              </div>

              <button
                onClick={handleBtmSell}
                disabled={isBtmProcessing || btmSellBtcAmount <= 0}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-orange-600 via-rose-600 to-amber-600 text-white font-black text-sm shadow-xl transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isBtmProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ArrowUpRight className="w-4 h-4" />}
                <span>Sell {btmSellBtcAmount} BTC &amp; Dispense Cash</span>
              </button>
            </div>
          )}

          {btmMode === "redeem" && (
            <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 space-y-5">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Enter Voucher PIN Code</label>
                <input
                  type="text"
                  value={btmVoucherPinInput}
                  onChange={(e) => setBtmVoucherPinInput(e.target.value)}
                  placeholder="e.g. BTM-9824-7102"
                  className="w-full p-4 rounded-2xl bg-slate-900 border border-slate-800 text-sm font-mono text-amber-300 font-bold tracking-widest uppercase"
                />
              </div>

              <button
                onClick={handleBtmRedeem}
                disabled={isBtmProcessing || !btmVoucherPinInput.trim()}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-sky-600 text-white font-black text-sm shadow-xl transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isBtmProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
                <span>Validate &amp; Redeem BTM Voucher</span>
              </button>
            </div>
          )}

          {btmMode === "hardware" && (
            <div className="rounded-3xl border border-slate-800 bg-slate-950 p-6 space-y-4">
              <h5 className="font-bold text-white text-sm">BTM Machine Hardware Diagnostics &amp; Telemetry</h5>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
                <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 block text-[10px]">BILL ACCEPTOR</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Optical Cash Sensor Ready
                  </span>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 block text-[10px]">CASH DISPENSER</span>
                  <span className="text-emerald-400 font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> 4 Denomination Hoppers Loaded
                  </span>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 block text-[10px]">THERMAL PRINTER</span>
                  <span className="text-sky-400 font-bold flex items-center gap-1">
                    <Printer className="w-3.5 h-3.5" /> 94% Paper Roll
                  </span>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-slate-500 block text-[10px]">HARDWARE HSM ENCRYPTION</span>
                  <span className="text-amber-400 font-bold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> AES-256 FIPS 140-2
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB: SOCIAL YIELD ==================== */}
      {activeTab === "social_yield" && (
        <div className="space-y-6 animate-in fade-in">
          <div className="rounded-3xl border border-purple-500/40 bg-gradient-to-br from-purple-950/30 via-slate-900 to-indigo-950/30 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-500 to-indigo-400 p-[2px] shadow-lg shadow-purple-500/25 shrink-0 flex items-center justify-center">
                <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-purple-400" />
                </div>
              </div>
              <div>
                <h4 className="text-base font-black text-white">Daily Social Media Content Yield Engine</h4>
                <p className="text-xs text-slate-400">
                  Monitors daily video metrics, analyzes audience retention &amp; RPM, then deposits legitimate BTC directly to your wallet.
                </p>
              </div>
            </div>

            <button
              onClick={handleHarvestSocialMediaYield}
              disabled={isHarvestingSocialYield}
              className="py-3 px-5 rounded-2xl bg-gradient-to-r from-purple-500 via-indigo-600 to-emerald-500 text-white font-black text-xs shadow-xl transition flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
            >
              {isHarvestingSocialYield ? <RefreshCw className="w-4 h-4 animate-spin text-amber-300" /> : <Sparkles className="w-4 h-4 text-amber-300" />}
              <span>Execute Daily Content Yield Harvest</span>
            </button>
          </div>

          {socialHarvestResult && (
            <div className="p-5 rounded-3xl bg-gradient-to-r from-purple-950/40 via-indigo-950/40 to-slate-900 border border-purple-500/50 space-y-4 animate-in zoom-in-95">
              <div className="flex items-center justify-between">
                <span className="text-emerald-400 font-black text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  Legitimate Social Yield Deposited to Bitcoin Wallet
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-bold uppercase">
                  Batch: {socialHarvestResult.harvestSummary.harvestBatchId}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono bg-black/50 p-4 rounded-2xl border border-purple-500/20">
                <div>
                  <span className="text-slate-400 text-[10px] block">Daily Views Analyzed:</span>
                  <span className="text-white font-bold text-sm">
                    {socialHarvestResult.harvestSummary.totalDailyViewsAnalyzed.toLocaleString()}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Engagement Rate:</span>
                  <span className="text-sky-400 font-bold text-sm">
                    {socialHarvestResult.harvestSummary.audienceEngagementRatePercent}%
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">Ad Yield USD:</span>
                  <span className="text-emerald-400 font-bold text-sm">
                    ${socialHarvestResult.harvestSummary.totalVerifiedYieldUsd.toFixed(2)} USD
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 text-[10px] block">BTC Minted &amp; Deposited:</span>
                  <span className="text-amber-400 font-bold text-sm">
                    +{socialHarvestResult.harvestSummary.btcDeposited.toFixed(8)} BTC
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB: CREATE WALLET ==================== */}
      {activeTab === "create_wallet" && (
        <div className="space-y-6 animate-in fade-in">
          <div className="rounded-3xl border border-sky-500/40 bg-gradient-to-br from-sky-950/30 via-slate-900 to-indigo-950/30 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-sky-500 to-indigo-400 p-[2px] shadow-lg shadow-sky-500/25 shrink-0 flex items-center justify-center">
                <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                  <Key className="w-6 h-6 text-sky-400" />
                </div>
              </div>
              <div>
                <h4 className="text-base font-black text-white">Cryptographic Wallet Creation &amp; Key Suite</h4>
                <p className="text-xs text-slate-400">
                  Generate BIP-39 mnemonic seed phrases and derive multi-chain addresses (Bitcoin, Ethereum, Solana).
                </p>
              </div>
            </div>

            <button
              onClick={handleCreateCryptocurrencyWallet}
              disabled={isCreatingWallet}
              className="py-3 px-5 rounded-2xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white font-black text-xs shadow-xl transition flex items-center gap-2 cursor-pointer disabled:opacity-50 shrink-0"
            >
              {isCreatingWallet ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
              <span>Generate New Crypto Wallet</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Select Blockchain</label>
              <select
                value={createWalletChain}
                onChange={(e) => setCreateWalletChain(e.target.value as any)}
                className="w-full p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white"
              >
                <option value="BITCOIN">Bitcoin (BTC - SegWit / Taproot)</option>
                <option value="ETHEREUM">Ethereum / EVM (ETH / USDT / USDC)</option>
                <option value="SOLANA">Solana (SOL - SPL Token)</option>
              </select>
            </div>

            {createWalletChain === "BITCOIN" && (
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Address Script Format</label>
                <select
                  value={createAddressType}
                  onChange={(e) => setCreateAddressType(e.target.value as any)}
                  className="w-full p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white"
                >
                  <option value="SEGWIT_NATIVE">Native SegWit Bech32 (bc1q...) - BIP-84</option>
                  <option value="TAPROOT">Taproot Bech32m (bc1p...) - BIP-86</option>
                  <option value="SEGWIT_P2SH">SegWit P2SH (3...) - BIP-49</option>
                </select>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">Wallet Label</label>
              <input
                type="text"
                value={createWalletLabel}
                onChange={(e) => setCreateWalletLabel(e.target.value)}
                placeholder="e.g. Master Custody Vault"
                className="w-full p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white"
              />
            </div>
          </div>

          {generatedWalletResult && (
            <div className="rounded-3xl border border-sky-500/50 bg-slate-950 p-6 space-y-5 animate-in zoom-in-95">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="font-extrabold text-white text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  {generatedWalletResult.chain} Wallet Derived Successfully
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 font-bold">
                  {generatedWalletResult.derivationPath}
                </span>
              </div>

              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Generated Public Address</span>
                <div className="p-3.5 rounded-2xl bg-black/60 border border-slate-800 flex items-center justify-between gap-2 text-xs font-mono">
                  <span className="text-sky-300 font-bold truncate select-all">{generatedWalletResult.address}</span>
                  <button onClick={() => copyToClipboard(generatedWalletResult.address, "address")} className="px-3 py-1.5 rounded-xl bg-slate-800 text-xs font-bold">
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5" /> BIP-39 12-Word Recovery Seed Phrase
                  </span>
                  <button onClick={() => setShowSeedPhrase(!showSeedPhrase)} className="text-[11px] text-slate-400 hover:text-white underline">
                    {showSeedPhrase ? "Hide Phrase" : "Reveal Phrase"}
                  </button>
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-2">
                  {generatedWalletResult.mnemonic12Words.split(" ").map((word: string, i: number) => (
                    <div key={i} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono flex items-center gap-1.5">
                      <span className="text-slate-500 text-[10px] w-4">{i + 1}.</span>
                      <span className="text-white font-bold">{showSeedPhrase ? word : "••••••"}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================== TAB: HISTORY ==================== */}
      {activeTab === "history" && (
        <div className="rounded-3xl border border-slate-800 bg-slate-950 p-5 sm:p-7 space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <History className="w-4 h-4 text-indigo-400" />
                <span>Bitcoin &amp; Multi-Crypto Ledger Transfer History</span>
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">Records linked to {LINKED_BTC_WALLET_ADDRESS}.</p>
            </div>
            <button onClick={fetchBtcWallet} className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-3">
            {recentTxs.map((tx) => (
              <div key={tx.txid} className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${tx.type === "RECEIVE" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-500/20 text-amber-400"}`}>
                    {tx.type === "RECEIVE" ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="font-extrabold text-white text-sm">{tx.memo || (tx.type === "RECEIVE" ? "Inbound BTC" : "Outbound BTC")}</div>
                    <div className="text-slate-400 font-mono text-[11px] truncate max-w-sm">TXID: {tx.txid}</div>
                  </div>
                </div>
                <div className="text-right font-mono">
                  <span className={`text-base font-black ${tx.type === "RECEIVE" ? "text-emerald-400" : "text-amber-400"}`}>
                    {tx.type === "RECEIVE" ? "+" : "-"}{tx.amountBtc.toFixed(4)} BTC
                  </span>
                  <span className="text-[10px] text-slate-400 block">≈ ${tx.amountUsd.toFixed(2)} USD</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ==================== TAB: MEMPOOL ==================== */}
      {activeTab === "mempool" && (
        <div className="space-y-6 animate-in fade-in">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Next Block Priority</span>
              <span className="text-xl font-black text-amber-400 font-mono block">18 sat/vB</span>
              <span className="text-[11px] text-slate-500">~10-15 min (~$2.40)</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Half-Hour Priority</span>
              <span className="text-xl font-black text-sky-400 font-mono block">12 sat/vB</span>
              <span className="text-[11px] text-slate-500">~30 min (~$1.60)</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Hour Priority</span>
              <span className="text-xl font-black text-indigo-400 font-mono block">7 sat/vB</span>
              <span className="text-[11px] text-slate-500">~60 min (~$0.95)</span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Current Block Height</span>
              <span className="text-xl font-black text-emerald-400 font-mono block">#864,120</span>
              <span className="text-[11px] text-slate-500">Halving Cycle 4 (3.125 BTC)</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
