import React from "react";
import { X, Sparkles } from "lucide-react";
import { BtcFundTransferSystem, LINKED_BTC_WALLET_ADDRESS } from "./BtcFundTransferSystem";
import { WalletState } from "../types";

interface BtcTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  wallet?: WalletState;
  onUpdateWallet?: (updated: WalletState) => void;
}

export const BtcTransferModal: React.FC<BtcTransferModalProps> = ({
  isOpen,
  onClose,
  wallet,
  onUpdateWallet,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="modal-btc-fund-transfer"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 animate-in fade-in"
    >
      <div className="w-full max-w-4xl rounded-3xl bg-[#0b111e] border border-amber-500/40 p-5 sm:p-7 shadow-2xl text-slate-100 max-h-[94vh] flex flex-col space-y-4 overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 p-[1.5px] shadow-lg shadow-amber-500/25 shrink-0 flex items-center justify-center">
              <div className="w-full h-full rounded-2xl bg-slate-950 flex items-center justify-center">
                <span className="text-amber-400 font-black text-xl">₿</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black text-white tracking-tight">
                  Bitcoin Digital Fund Transfer System
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                  Mainnet Connected
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Direct send and receive rails linked to <span className="font-mono text-amber-300 font-bold">{LINKED_BTC_WALLET_ADDRESS}</span>
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto pr-1 scrollbar-thin">
          <BtcFundTransferSystem
            wallet={wallet}
            onUpdateWallet={onUpdateWallet}
            onCloseModal={onClose}
            isEmbedded={true}
          />
        </div>

        {/* Modal Footer */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between shrink-0 text-xs">
          <div className="flex items-center gap-2 text-slate-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-mono text-[11px]">BIP-49 / BIP-141 P2SH SegWit Protocol Active</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition cursor-pointer"
          >
            Close Console
          </button>
        </div>
      </div>
    </div>
  );
};
