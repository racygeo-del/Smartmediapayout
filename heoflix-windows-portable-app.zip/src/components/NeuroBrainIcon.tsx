import React from "react";

interface NeuroBrainIconProps {
  className?: string;
  size?: number | string;
  showGlow?: boolean;
  pulse?: boolean;
}

export const NeuroBrainIcon: React.FC<NeuroBrainIconProps> = ({
  className = "w-6 h-6",
  size,
  showGlow = true,
  pulse = false,
}) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512 512"
      width={size}
      height={size}
      className={`${className} ${pulse ? "animate-pulse" : ""}`}
      style={{ display: "inline-block", verticalAlign: "middle" }}
    >
      <defs>
        {/* Red Hemisphere Gradient (Left) */}
        <linearGradient id="nb-red" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F87171" />
          <stop offset="45%" stopColor="#EF4444" />
          <stop offset="100%" stopColor="#B91C1C" />
        </linearGradient>

        {/* Blue Hemisphere Gradient (Right) */}
        <linearGradient id="nb-blue" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#60A5FA" />
          <stop offset="45%" stopColor="#3B82F6" />
          <stop offset="100%" stopColor="#1D4ED8" />
        </linearGradient>

        {/* White Core Gradient (Nexus) */}
        <linearGradient id="nb-white" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="60%" stopColor="#F8FAFC" />
          <stop offset="100%" stopColor="#E2E8F0" />
        </linearGradient>

        {showGlow && (
          <filter id="nb-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="12" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        )}
      </defs>

      {/* Background Ambient Aura */}
      <circle cx="256" cy="256" r="220" fill="#0b1120" opacity="0.9" />
      <circle cx="256" cy="256" r="210" fill="none" stroke="#FFFFFF" strokeWidth="2" opacity="0.15" />

      {/* Synaptic Orbital Rings in Red & Blue */}
      <circle cx="256" cy="256" r="190" fill="none" stroke="#EF4444" strokeWidth="3" strokeDasharray="16 16" opacity="0.4" />
      <circle cx="256" cy="256" r="170" fill="none" stroke="#3B82F6" strokeWidth="3" strokeDasharray="16 16" opacity="0.4" />

      {/* LEFT HEMISPHERE: CRIMSON RED */}
      <g filter={showGlow ? "url(#nb-glow)" : undefined}>
        <path
          d="M 242 110 C 185 108, 115 138, 105 200 C 98 238, 120 270, 110 305 C 100 340, 125 385, 175 400 C 215 412, 238 395, 242 385 Z"
          fill="none"
          stroke="url(#nb-red)"
          strokeWidth="14"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 240 150 C 190 150, 145 180, 142 225 C 140 262, 170 285, 160 325 C 150 355, 185 375, 240 370"
          fill="none"
          stroke="url(#nb-red)"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <path
          d="M 238 195 C 205 195, 175 220, 180 255 C 185 285, 215 300, 238 310"
          fill="none"
          stroke="url(#nb-red)"
          strokeWidth="9"
          strokeLinecap="round"
        />
        <path
          d="M 145 240 C 170 245, 195 235, 215 245"
          fill="none"
          stroke="url(#nb-red)"
          strokeWidth="7"
          strokeLinecap="round"
        />

        {/* Red Synaptic Bio-Nodes */}
        <circle cx="108" cy="205" r="9" fill="#F87171" />
        <circle cx="112" cy="308" r="9.5" fill="#EF4444" />
        <circle cx="175" cy="400" r="9" fill="#DC2626" />
        <circle cx="142" cy="225" r="7.5" fill="#FCA5A5" />
        <circle cx="160" cy="325" r="8" fill="#EF4444" />
      </g>

      {/* RIGHT HEMISPHERE: ELECTRIC BLUE */}
      <g filter={showGlow ? "url(#nb-glow)" : undefined}>
        <path
          d="M 270 110 C 327 108, 397 138, 407 200 C 414 238, 392 270, 402 305 C 412 340, 387 385, 337 400 C 297 412, 274 395, 270 385 Z"
          fill="none"
          stroke="url(#nb-blue)"
          strokeWidth="14"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M 272 150 C 322 150, 367 180, 370 225 C 372 262, 342 285, 352 325 C 362 355, 327 375, 272 370"
          fill="none"
          stroke="url(#nb-blue)"
          strokeWidth="10"
          strokeLinecap="round"
        />
        <path
          d="M 274 195 C 307 195, 337 220, 332 255 C 327 285, 297 300, 274 310"
          fill="none"
          stroke="url(#nb-blue)"
          strokeWidth="9"
          strokeLinecap="round"
        />
        <path
          d="M 367 240 C 342 245, 317 235, 297 245"
          fill="none"
          stroke="url(#nb-blue)"
          strokeWidth="7"
          strokeLinecap="round"
        />

        {/* Blue Synaptic Cyber-Nodes */}
        <circle cx="404" cy="205" r="9" fill="#60A5FA" />
        <circle cx="400" cy="308" r="9.5" fill="#3B82F6" />
        <circle cx="337" cy="400" r="9" fill="#2563EB" />
        <circle cx="370" cy="225" r="7.5" fill="#93C5FD" />
        <circle cx="352" cy="325" r="8" fill="#3B82F6" />
      </g>

      {/* CENTER CORE: LUMINESCENT WHITE */}
      <g filter={showGlow ? "url(#nb-glow)" : undefined}>
        {/* Central White Synaptic Spine */}
        <path d="M 256 100 L 256 410" stroke="url(#nb-white)" strokeWidth="10" strokeLinecap="round" />

        {/* Interlinking White Synaptic Bridges */}
        <path d="M 220 135 C 240 145, 272 145, 292 135" stroke="#FFFFFF" strokeWidth="6" strokeLinecap="round" />
        <path d="M 215 180 C 240 195, 272 195, 297 180" stroke="#FFFFFF" strokeWidth="6" strokeLinecap="round" />
        <path d="M 210 230 C 235 245, 277 245, 302 230" stroke="#FFFFFF" strokeWidth="7" strokeLinecap="round" />
        <path d="M 208 280 C 235 295, 277 295, 304 280" stroke="#FFFFFF" strokeWidth="7" strokeLinecap="round" />
        <path d="M 215 330 C 240 345, 272 345, 297 330" stroke="#FFFFFF" strokeWidth="6" strokeLinecap="round" />
        <path d="M 225 375 C 242 385, 270 385, 287 375" stroke="#FFFFFF" strokeWidth="5.5" strokeLinecap="round" />

        {/* Pure White Luminescent Center Orbs */}
        <circle cx="256" cy="100" r="9" fill="#FFFFFF" />
        <circle cx="256" cy="140" r="8.5" fill="#FFFFFF" />
        <circle cx="256" cy="188" r="10" fill="#FFFFFF" />
        <circle cx="256" cy="240" r="12" fill="#FFFFFF" />
        <circle cx="256" cy="290" r="11" fill="#FFFFFF" />
        <circle cx="256" cy="340" r="9.5" fill="#FFFFFF" />
        <circle cx="256" cy="385" r="9" fill="#FFFFFF" />
        <circle cx="256" cy="410" r="7.5" fill="#FFFFFF" />

        {/* Trans-Hemisphere Spark Blends */}
        <circle cx="236" cy="240" r="5" fill="#FCA5A5" />
        <circle cx="276" cy="240" r="5" fill="#93C5FD" />
      </g>
    </svg>
  );
};
