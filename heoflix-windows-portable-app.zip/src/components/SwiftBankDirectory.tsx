import React, { useState, useMemo } from "react";
import { GLOBAL_BANKS_REGISTRY, BankInfo } from "../data/globalBanks";
import {
  Search,
  Building2,
  Copy,
  Check,
  Globe,
  ArrowRight,
  ShieldCheck,
  ExternalLink,
  Layers,
  Sparkles,
} from "lucide-react";

interface SwiftBankDirectoryProps {
  onSelectBank?: (bank: BankInfo) => void;
}

export const SwiftBankDirectory: React.FC<SwiftBankDirectoryProps> = ({ onSelectBank }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFilter, setSelectedFilter] = useState<"ALL" | "NIGERIA" | "USA" | "EUROPE" | "POPULAR">("ALL");
  const [copiedSwift, setCopiedSwift] = useState<string | null>(null);

  const filteredBanks = useMemo(() => {
    let list = GLOBAL_BANKS_REGISTRY;

    if (selectedFilter === "NIGERIA") {
      list = list.filter((b) => b.countryCode === "NG");
    } else if (selectedFilter === "USA") {
      list = list.filter((b) => b.countryCode === "US");
    } else if (selectedFilter === "EUROPE") {
      list = list.filter((b) => b.countryCode === "GB" || b.countryCode === "DE" || b.countryCode === "FR" || b.countryCode === "CH");
    } else if (selectedFilter === "POPULAR") {
      list = list.filter((b) => b.isPopular);
    }

    if (!searchQuery.trim()) return list;

    const q = searchQuery.toLowerCase().trim();
    return list.filter(
      (b) =>
        b.name.toLowerCase().includes(q) ||
        b.swiftCode.toLowerCase().includes(q) ||
        b.country.toLowerCase().includes(q) ||
        b.code.toLowerCase().includes(q) ||
        b.bic.toLowerCase().includes(q)
    );
  }, [searchQuery, selectedFilter]);

  const handleCopySwift = (swift: string) => {
    navigator.clipboard.writeText(swift);
    setCopiedSwift(swift);
    setTimeout(() => setCopiedSwift(null), 2500);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header Banner */}
      <div className="rounded-3xl border border-slate-800 bg-gradient-to-br from-slate-900 via-slate-900/90 to-sky-950/40 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-sky-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full bg-sky-500/20 text-sky-400 font-mono text-[10px] font-extrabold uppercase border border-sky-500/30 flex items-center gap-1.5">
                <Globe className="w-3 h-3" />
                <span>OFFICIAL SWIFT / BIC DIRECTORY</span>
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 font-mono text-[10px] font-bold border border-emerald-500/20">
                {GLOBAL_BANKS_REGISTRY.length} VERIFIED COMMERCIAL BANKS
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Global Commercial Banks &amp; SWIFT Code Registry
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Authoritative directory of Nigerian, US, UK, European, and Global commercial banks.
              Official SWIFT/BIC codes automatically retrieved and linked for direct cross-border monetary transfer dispatch.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-right">
              <span className="text-[10px] text-slate-400 uppercase font-mono block">SWIFT Network</span>
              <span className="text-xs font-bold text-emerald-400 flex items-center justify-end gap-1 mt-0.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>SWIFT GPI Live 24/7</span>
              </span>
            </div>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="mt-6 flex flex-col sm:flex-row gap-3 pt-6 border-t border-slate-800/80">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by bank name, SWIFT code (e.g. PAYNNGLA, CHASUS33, FBNINGLA), country, or sort code..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 font-medium"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1.5 text-xs font-semibold">
            {[
              { id: "ALL", label: "All Banks" },
              { id: "NIGERIA", label: "Nigeria 🇳🇬" },
              { id: "USA", label: "United States 🇺🇸" },
              { id: "EUROPE", label: "UK & Europe 🇪🇺" },
              { id: "POPULAR", label: "Top Commercial" },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedFilter(f.id as any)}
                className={`px-3 py-2 rounded-xl transition cursor-pointer text-xs ${
                  selectedFilter === f.id
                    ? "bg-sky-600 text-white font-bold shadow-md shadow-sky-600/30"
                    : "bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700/60"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Banks Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredBanks.map((bank) => {
          const isCopied = copiedSwift === bank.swiftCode;

          return (
            <div
              key={bank.code + bank.swiftCode}
              className="rounded-2xl border border-slate-800/90 bg-slate-900/80 p-5 shadow-lg hover:border-sky-500/40 transition-all flex flex-col justify-between space-y-4 group"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-base">{bank.countryFlag}</span>
                    <span className="text-xs font-bold text-slate-300">{bank.country}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-800 border border-slate-700 text-slate-300">
                    {bank.type}
                  </span>
                </div>

                <h3 className="text-sm font-black text-white group-hover:text-sky-300 transition line-clamp-1">
                  {bank.name}
                </h3>
                <span className="text-[11px] text-slate-400 block mt-0.5">
                  Currency: <strong className="text-slate-200">{bank.currency}</strong> &bull; Bank Code: <code className="text-slate-300">{bank.code}</code>
                </span>

                {/* SWIFT Code Highlight Badge */}
                <div className="mt-3.5 p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-mono text-slate-400 block font-semibold">
                      Official SWIFT / BIC Code
                    </span>
                    <span className="text-sm font-black font-mono text-emerald-400 tracking-wider">
                      {bank.swiftCode}
                    </span>
                  </div>

                  <button
                    onClick={() => handleCopySwift(bank.swiftCode)}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer"
                    title="Copy SWIFT Code"
                  >
                    {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* Clearing Rails */}
                <div className="mt-3">
                  <span className="text-[10px] text-slate-400 uppercase font-mono block mb-1">
                    Settlement Rails:
                  </span>
                  <div className="flex flex-wrap gap-1">
                    {bank.clearingRails.map((rail) => (
                      <span
                        key={rail}
                        className="px-2 py-0.5 rounded-md bg-slate-800/80 border border-slate-700/60 text-[10px] text-slate-300 font-mono"
                      >
                        {rail}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2 text-xs">
                <span className="text-[11px] font-mono text-slate-400">
                  Sort/Routing: <strong className="text-slate-200">{bank.sortCode}</strong>
                </span>

                {onSelectBank && (
                  <button
                    onClick={() => onSelectBank(bank)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-[11px] transition shadow-md shadow-emerald-600/20 cursor-pointer"
                  >
                    <span>Use for Transfer</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filteredBanks.length === 0 && (
        <div className="p-12 text-center rounded-3xl border border-slate-800 bg-slate-900/60 text-slate-400">
          <Building2 className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <p className="text-sm font-bold text-white">No banks match your search criteria</p>
          <p className="text-xs text-slate-400 mt-1">Try searching by bank name or standard SWIFT prefix.</p>
        </div>
      )}
    </div>
  );
};
