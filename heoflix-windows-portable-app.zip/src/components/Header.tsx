import React, { useState } from "react";
import {
  Wallet,
  Activity,
  Send,
  Receipt,
  Calculator,
  ShieldCheck,
  ShieldAlert,
  Smartphone,
  Monitor,
  Sparkles,
  Fingerprint,
  Brain,
  Cpu,
  Lock,
  Film,
  BarChart3,
  Boxes,
  Key,
  Radar,
  Satellite,
  Globe,
  Sliders,
  Zap,
  Mail,
  Download,
  Server,
} from "lucide-react";
import { ViewTab, DeviceViewMode, WalletState } from "../types";
import { PWAInstallButton } from "./PWAInstallButton";
import { useBiometrics } from "../hooks/useBiometrics";
import { BiometricSettingsModal } from "./BiometricSettingsModal";
import { NeuroBrainIcon } from "./NeuroBrainIcon";
import { useAppSettings } from "../context/AppSettingsContext";

interface HeaderProps {
  currentTab: ViewTab;
  onSelectTab: (tab: ViewTab) => void;
  wallet: WalletState | null;
  deviceMode: DeviceViewMode;
  onSetDeviceMode: (mode: DeviceViewMode) => void;
  isUnlocked: boolean;
  onOpenSecurityModal: () => void;
  onTriggerAccrual: () => void;
  onLockPortal?: () => void;
  marketMode?: "LIVE_PRODUCTION_MARKET" | "STAGING_SANDBOX";
  onOpenMarketModal?: () => void;
  onOpenGoogleLaunchModal?: () => void;
  onOpenSettingsModal?: () => void;
  onOpenBtcModal?: () => void;
  onOpenWindowsExtractionModal?: () => void;
  onOpenPaystackModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  wallet,
  deviceMode,
  onSetDeviceMode,
  isUnlocked,
  onOpenSecurityModal,
  onTriggerAccrual,
  onLockPortal,
  marketMode = "LIVE_PRODUCTION_MARKET",
  onOpenMarketModal,
  onOpenGoogleLaunchModal,
  onOpenSettingsModal,
  onOpenBtcModal,
  onOpenWindowsExtractionModal,
  onOpenPaystackModal,
}) => {
  const [biometricsModalOpen, setBiometricsModalOpen] = useState(false);
  const { preferences, updatePreferences, fingerprintInfo } = useBiometrics();
  const { settings } = useAppSettings();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#151d2b]/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6">
        {/* Left: Brand & Gateway status */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => onSelectTab("monitor")}>
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-rose-500 via-indigo-600 to-sky-400 p-[1.5px] shadow-lg shadow-indigo-500/25 shrink-0">
              <div className="flex h-full w-full items-center justify-center rounded-xl bg-[#131926] overflow-hidden">
                {settings.brandIcon === "neuro_tricolor" ? (
                  <NeuroBrainIcon className="w-7 h-7" showGlow={true} pulse={true} />
                ) : settings.brandIcon === "pulse_orb" ? (
                  <Zap className="w-5 h-5 text-amber-300 animate-pulse" />
                ) : (
                  <span className="bg-gradient-to-r from-sky-400 to-emerald-400 bg-clip-text text-transparent font-black text-lg">H</span>
                )}
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold tracking-tight text-white text-base">HEOFLIX</span>
                <span className="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[10px] font-bold text-indigo-400 border border-indigo-500/30">
                  AI v3.2
                </span>
                <button
                  id="btn-header-website-badge"
                  onClick={() => onSelectTab("website")}
                  className={`rounded px-2 py-0.5 text-[10px] font-bold border flex items-center gap-1.5 transition cursor-pointer shadow-sm ${
                    currentTab === "website"
                      ? "bg-sky-500 text-white border-sky-400 shadow-sky-500/30"
                      : "bg-sky-500/20 text-sky-300 border-sky-500/40 hover:bg-sky-500/30"
                  }`}
                  title="Official Website: https://www.heoflix.com (Real Financial Exchange)"
                >
                  <Globe className="h-2.5 w-2.5 text-sky-400" />
                  <span className="font-mono">www.heoflix.com</span>
                </button>
                <button
                  id="btn-header-google-launch"
                  onClick={onOpenGoogleLaunchModal}
                  className="rounded bg-gradient-to-r from-sky-500/20 via-indigo-500/20 to-emerald-500/20 px-2 py-0.5 text-[10px] font-bold text-sky-300 border border-sky-400/40 flex items-center gap-1.5 hover:from-sky-500/30 hover:to-emerald-500/30 transition cursor-pointer shadow-sm"
                  title="AI Automatic Skill: Launch Website to Google Search & Indexing Engine"
                >
                  <Sparkles className="h-2.5 w-2.5 text-amber-300 animate-pulse" />
                  <span className="bg-gradient-to-r from-sky-300 via-indigo-200 to-emerald-300 bg-clip-text text-transparent font-extrabold">LAUNCH TO GOOGLE</span>
                </button>
                <button
                  id="btn-header-btc-badge"
                  onClick={onOpenBtcModal || (() => onSelectTab("banking"))}
                  className="rounded bg-amber-500/20 px-2 py-0.5 text-[10px] font-bold text-amber-300 border border-amber-500/40 flex items-center gap-1.5 hover:bg-amber-500/30 transition cursor-pointer shadow-sm"
                  title="Linked Sovereign Bitcoin Wallet: 34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW (Send & Receive)"
                >
                  <span className="text-amber-400 font-bold font-mono">₿</span>
                  <span className="font-mono">34m9vs... BTC</span>
                  <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse" />
                </button>
                <button
                  id="btn-header-market-badge"
                  onClick={onOpenMarketModal || (() => onSelectTab("banking"))}
                  className={`rounded px-2 py-0.5 text-[10px] font-bold border flex items-center gap-1.5 transition cursor-pointer shadow-sm ${
                    marketMode === "LIVE_PRODUCTION_MARKET"
                      ? "bg-rose-500/20 text-rose-300 border-rose-500/40 hover:bg-rose-500/30"
                      : "bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30"
                  }`}
                  title="Click to open Real-World Market Launch Console & Direct Clearing Status"
                >
                  <span
                    className={`h-1.5 w-1.5 rounded-full ${
                      marketMode === "LIVE_PRODUCTION_MARKET"
                        ? "bg-rose-500 animate-ping"
                        : "bg-amber-400"
                    }`}
                  />
                  <span>
                    {marketMode === "LIVE_PRODUCTION_MARKET"
                      ? "LIVE MARKET"
                      : "STAGING"}
                  </span>
                </button>
                <button
                  id="btn-header-paystack-badge"
                  onClick={() => {
                    if (onOpenPaystackModal) onOpenPaystackModal();
                    else onSelectTab("banking");
                  }}
                  className="rounded bg-sky-500/20 px-2 py-0.5 text-[10px] font-bold text-sky-400 border border-sky-500/30 flex items-center gap-1 hover:bg-sky-500/30 transition cursor-pointer"
                  title="Paystack Payments & Transfers Gateway (Send & Receive Dollars)"
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-sky-400"></span>
                  <span>PAYSTACK TRANSFER</span>
                </button>
                <button
                  id="btn-header-brain-badge"
                  onClick={() => onSelectTab("brain")}
                  className="rounded bg-indigo-500/20 px-2 py-0.5 text-[10px] font-bold text-indigo-300 border border-indigo-500/30 flex items-center gap-1 hover:bg-indigo-500/30 transition cursor-pointer"
                  title="CORTEX-9 AI Financial Brain & World Transfers"
                >
                  <Brain className="h-2.5 w-2.5 text-indigo-400 animate-pulse" />
                  <span>AI BRAIN</span>
                </button>
                <button
                  id="btn-header-radar-badge"
                  onClick={() => onSelectTab("radar")}
                  className="rounded bg-rose-500/20 px-2 py-0.5 text-[10px] font-bold text-rose-300 border border-rose-500/40 flex items-center gap-1.5 hover:bg-rose-500/30 transition cursor-pointer"
                  title="Security Radar & Satellite Trackers: Autonomous Intruder Defense Active"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-ping" />
                  <Radar className="h-2.5 w-2.5 text-rose-400" />
                  <span>RADAR DEFENSE</span>
                </button>
                <div
                  className="hidden xl:flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold"
                  title="Zero-Knowledge Privacy Guard Active: Sovereign Identity, IP Address, and Real-Time Geo-Location are cloaked."
                >
                  <ShieldCheck className="w-2.5 h-2.5 text-emerald-400" />
                  <span>IP &amp; LOCATION CLOAKED</span>
                </div>
              </div>
              <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-slate-400">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
                </span>
                <span>8 Global Bank Servers Connected</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center: Live Dollar Balance & Accrual Trigger */}
        <div className="flex items-center gap-2">
          <div
            id="wallet-quick-balance-card"
            onClick={() => onSelectTab("wallet")}
            className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-950/20 px-3 py-1.5 cursor-pointer hover:border-emerald-500/50 transition"
            title="Available Dollar Wallet Balance"
          >
            <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-emerald-500/20 text-emerald-400">
              <Wallet className="h-3.5 w-3.5" />
            </div>
            <div>
              <div className="text-[10px] uppercase font-bold text-emerald-400/80 tracking-wider">USD Wallet</div>
              <div className="text-xs sm:text-sm font-extrabold text-white">
                ${wallet ? wallet.availableBalance.toLocaleString("en-US", { minimumFractionDigits: 2 }) : "42,180.25"}
              </div>
            </div>
          </div>

          <button
            id="btn-quick-accrue-funds"
            onClick={onTriggerAccrual}
            className="hidden lg:flex items-center gap-1.5 rounded-xl border border-indigo-500/30 bg-indigo-950/30 px-2.5 py-1.5 text-xs font-semibold text-indigo-300 hover:bg-indigo-900/40 hover:text-white transition"
            title="Trigger Instant Automated Monetization Batch"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            <span>Generate Funds</span>
          </button>
        </div>

        {/* Right: Device view switch, Security status, PWA install */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Device Simulator Toggle for iOS / Android testing */}
          <div className="hidden md:flex items-center rounded-lg border border-slate-800 bg-slate-900 p-0.5">
            <button
              id="viewmode-desktop"
              onClick={() => onSetDeviceMode("desktop")}
              className={`p-1.5 rounded-md transition ${deviceMode === "desktop" ? "bg-slate-800 text-white shadow-sm" : "text-slate-400 hover:text-slate-200"}`}
              title="Full Desktop Mode"
            >
              <Monitor className="w-3.5 h-3.5" />
            </button>
            <button
              id="viewmode-ios"
              onClick={() => onSetDeviceMode("ios")}
              className={`p-1.5 rounded-md transition ${deviceMode === "ios" ? "bg-slate-800 text-sky-400 shadow-sm" : "text-slate-400 hover:text-slate-200"}`}
              title="Apple iOS Simulator (iPhone 16 Pro)"
            >
              <Smartphone className="w-3.5 h-3.5 text-sky-400" />
            </button>
            <button
              id="viewmode-android"
              onClick={() => onSetDeviceMode("android")}
              className={`p-1.5 rounded-md transition ${deviceMode === "android" ? "bg-slate-800 text-emerald-400 shadow-sm" : "text-slate-400 hover:text-slate-200"}`}
              title="Google Android Simulator (Pixel 9)"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            </button>
          </div>

          {/* Biometric Quick Settings Toggle Button */}
          <button
            id="btn-header-biometric-settings"
            onClick={() => setBiometricsModalOpen(true)}
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border transition ${
              preferences.enabled
                ? "border-indigo-500/40 bg-indigo-500/10 text-indigo-300 hover:bg-indigo-500/20"
                : "border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200"
            }`}
            title={
              preferences.enabled
                ? `Fingerprint Machine Detected: ${fingerprintInfo.sensorName} (Click to customize)`
                : "Fingerprint Machine Offline (Click to configure)"
            }
          >
            <Fingerprint className={`w-3.5 h-3.5 ${preferences.enabled ? "text-emerald-400 animate-pulse" : "text-slate-500"}`} />
            <span className="hidden xl:inline">
              {preferences.enabled ? "Fingerprint: Active" : "Fingerprint: Off"}
            </span>
            <span
              className={`h-1.5 w-1.5 rounded-full ${
                preferences.enabled ? "bg-emerald-400 animate-pulse" : "bg-slate-600"
              }`}
            />
          </button>

          {/* Security Clearance Badge (Thumbprint Biometrics) */}
          <button
            id="btn-header-security-badge"
            onClick={onOpenSecurityModal}
            className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border transition ${
              isUnlocked
                ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-400"
                : "border-amber-500/40 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
            }`}
            title={isUnlocked ? "Security Clearance Active (Thumbprint Biometrics Validated)" : "Click to authenticate with thumbprint biometrics"}
          >
            {isUnlocked ? (
              <>
                <Fingerprint className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Thumbprint: Verified</span>
              </>
            ) : (
              <>
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Unlock Vault</span>
              </>
            )}
          </button>

          {/* API Gateway & Traffic Controller Header Button */}
          <button
            id="btn-header-api-gateway"
            type="button"
            onClick={() => onSelectTab("gateway")}
            className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border border-sky-500/40 bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 hover:text-white transition shadow-sm cursor-pointer"
            title="Real-Life Cryptocurrency Transactions & Banking Gateway for AI Funds"
          >
            <Server className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
            <span className="hidden xl:inline">⚡ Crypto &amp; Bank Gateway</span>
            <span className="xl:hidden">Gateway</span>
          </button>

          {/* Paystack Transfer Quick Access Header Button */}
          <button
            id="btn-header-paystack-transfer"
            type="button"
            onClick={() => {
              if (onOpenPaystackModal) onOpenPaystackModal();
              else onSelectTab("banking");
            }}
            className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-black border border-sky-500/50 bg-gradient-to-r from-sky-500/20 via-sky-600/20 to-teal-500/20 hover:from-sky-500/30 hover:to-teal-500/30 text-sky-200 hover:text-white transition shadow-sm cursor-pointer"
            title="Paystack Payments & Transfers Gateway (Send & Receive Dollars)"
          >
            <Zap className="w-3.5 h-3.5 text-sky-400 fill-current" />
            <span className="hidden xl:inline">Paystack Transfer</span>
            <span className="xl:hidden">Paystack</span>
          </button>

          {/* DNS 8.8.8.8 NXDOMAIN Linker Header Button */}
          {onOpenGoogleLaunchModal && (
            <button
              id="btn-header-dns-8888-linker"
              type="button"
              onClick={onOpenGoogleLaunchModal}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border border-sky-500/40 bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 hover:text-white transition shadow-sm cursor-pointer"
              title="DNS 8.8.8.8 NXDOMAIN Linker & Google Launch Console"
            >
              <Globe className="w-3.5 h-3.5 text-sky-400" />
              <span className="hidden xl:inline">DNS 8.8.8.8 Linker</span>
              <span className="xl:hidden">DNS 8.8.8.8</span>
            </button>
          )}

          {/* Email System Quick Access Header Button */}
          <button
            id="btn-header-email-system"
            type="button"
            onClick={() => onSelectTab("email")}
            className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border border-indigo-500/40 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 hover:text-white transition shadow-sm cursor-pointer"
            title="Sovereign Email System (georgefelixegwu@gmail.com)"
          >
            <Mail className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden xl:inline">Email System</span>
            <span className="xl:hidden">Mail</span>
          </button>

          {/* Extract App (Windows Portable Package) Header Button */}
          {onOpenWindowsExtractionModal && (
            <button
              id="btn-header-extract-app"
              type="button"
              onClick={onOpenWindowsExtractionModal}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border border-emerald-500/40 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 hover:from-emerald-500/20 hover:to-teal-500/20 text-emerald-300 hover:text-white transition shadow-sm cursor-pointer"
              title="Extract App & Download Windows Portable Package (.ZIP)"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden xl:inline">Extract App (Windows)</span>
              <span className="xl:hidden">Extract</span>
            </button>
          )}

          {/* Auto Prompt Admin Password Gate Button */}
          <button
            id="btn-header-admin-password-gate"
            type="button"
            onClick={onOpenSecurityModal}
            className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border border-sky-500/40 bg-sky-500/10 hover:bg-sky-500/20 text-sky-300 hover:text-white transition shadow-sm cursor-pointer"
            title="Auto Prompt Admin Password Gate (Sovereign Master Clearance)"
          >
            <Key className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden xl:inline">Auto Prompt Admin Password Gate</span>
            <span className="xl:hidden">Admin Gate</span>
          </button>

          {/* App Settings & Interlinked Functions Button */}
          {onOpenSettingsModal && (
            <button
              id="btn-header-app-settings"
              onClick={onOpenSettingsModal}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border border-slate-700/80 bg-slate-900/90 text-slate-200 hover:text-white hover:border-indigo-500/50 hover:bg-slate-800 transition shadow-sm cursor-pointer"
              title="Professional App Settings & System Interlinkage"
            >
              <Sliders className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden lg:inline">Settings</span>
              <span className="flex h-1.5 w-1.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-sky-500"></span>
              </span>
            </button>
          )}

          {/* Admin Lock Portal Action */}
          {onLockPortal && (
            <button
              id="btn-lock-admin-portal"
              type="button"
              onClick={onLockPortal}
              className="flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs font-semibold border border-rose-500/30 bg-rose-950/30 hover:bg-rose-900/50 hover:border-rose-500/60 text-rose-300 hover:text-white transition shadow-sm cursor-pointer"
              title="Lock App (Requires Admin Password to open)"
            >
              <Lock className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden md:inline">Lock App</span>
            </button>
          )}

          {/* PWA Install Button */}
          <PWAInstallButton />
        </div>
      </div>

      {/* Biometric Preferences Modal Dialog */}
      <BiometricSettingsModal
        isOpen={biometricsModalOpen}
        onClose={() => setBiometricsModalOpen(false)}
      />

      {/* Main Navigation Tabs */}
      <div className="w-full overflow-x-auto border-t border-slate-800/60 bg-[#131926]/75 backdrop-blur-sm px-4 scrollbar-none">
        <nav className="mx-auto flex max-w-7xl items-center gap-1 py-1.5 sm:gap-2">
          <button
            id="nav-tab-website"
            onClick={() => onSelectTab("website")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "website"
                ? "bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-md shadow-sky-600/30 font-bold"
                : "text-sky-300 hover:bg-slate-800/80 hover:text-white"
            }`}
          >
            <Globe className="h-3.5 w-3.5 text-sky-400 animate-pulse" />
            <span>🌐 Website (www.heoflix.com)</span>
          </button>

          <button
            id="nav-tab-media-manager"
            onClick={() => onSelectTab("media_manager")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "media_manager"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800/80 hover:text-slate-200"
            }`}
          >
            <Film className="h-3.5 w-3.5 text-sky-400" />
            <span>Media Manager & Importer</span>
          </button>

          <button
            id="nav-tab-analytics"
            onClick={() => onSelectTab("analytics")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "analytics"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800/80 hover:text-slate-200"
            }`}
          >
            <BarChart3 className="h-3.5 w-3.5 text-emerald-400" />
            <span>Video Analytics & Yield</span>
          </button>

          <button
            id="nav-tab-monitor"
            onClick={() => onSelectTab("monitor")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "monitor"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800/80 hover:text-slate-200"
            }`}
          >
            <Activity className="h-3.5 w-3.5" />
            <span>AI Social Monitor</span>
          </button>

          <button
            id="nav-tab-wallet"
            onClick={() => onSelectTab("wallet")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "wallet"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800/80 hover:text-slate-200"
            }`}
          >
            <Wallet className="h-3.5 w-3.5" />
            <span>Dollar Wallet & Auto-Funds</span>
          </button>

          <button
            id="nav-tab-banking"
            onClick={() => onSelectTab("banking")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "banking"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800/80 hover:text-slate-200"
            }`}
          >
            <Send className="h-3.5 w-3.5 text-emerald-400" />
            <span className="font-bold">⚡ Online Banking Transfer App</span>
          </button>

          <button
            id="nav-tab-gateway"
            onClick={() => onSelectTab("gateway")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "gateway"
                ? "bg-gradient-to-r from-sky-600 via-indigo-600 to-emerald-600 text-white shadow-md shadow-sky-600/30 font-bold"
                : "text-sky-300 hover:bg-slate-800/80 hover:text-white"
            }`}
          >
            <Server className="h-3.5 w-3.5 text-sky-400 animate-pulse" />
            <span className="font-bold">⚡ Real-Life Crypto &amp; Bank Gateway</span>
          </button>

          <button
            id="nav-tab-brain"
            onClick={() => onSelectTab("brain")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "brain"
                ? "bg-gradient-to-r from-indigo-600 to-sky-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-300 hover:bg-slate-800/80 hover:text-white"
            }`}
          >
            <Brain className="h-3.5 w-3.5 text-indigo-400 animate-pulse" />
            <span className="font-bold">AI Brain & World Transfers</span>
          </button>

          <button
            id="nav-tab-transactions"
            onClick={() => onSelectTab("transactions")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "transactions"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800/80 hover:text-slate-200"
            }`}
          >
            <Receipt className="h-3.5 w-3.5" />
            <span>Real-Time Transactions & Audit</span>
          </button>

          <button
            id="nav-tab-tax"
            onClick={() => onSelectTab("tax")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "tax"
                ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                : "text-slate-400 hover:bg-slate-800/80 hover:text-slate-200"
            }`}
          >
            <Calculator className="h-3.5 w-3.5" />
            <span>Automated Tax Tools</span>
          </button>

          <button
            id="nav-tab-blockchain"
            onClick={() => onSelectTab("blockchain")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "blockchain"
                ? "bg-gradient-to-r from-sky-500 to-indigo-600 text-white shadow-md shadow-sky-500/30"
                : "text-slate-300 hover:bg-slate-800/80 hover:text-white"
            }`}
          >
            <Boxes className="h-3.5 w-3.5 text-sky-400 animate-pulse" />
            <span className="font-bold">Blockchain & Secret Key Studio</span>
          </button>

          <button
            id="nav-tab-radar"
            onClick={() => onSelectTab("radar")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "radar"
                ? "bg-gradient-to-r from-rose-600 via-red-600 to-indigo-600 text-white shadow-md shadow-rose-600/30"
                : "text-rose-300/90 hover:bg-slate-800/80 hover:text-rose-200"
            }`}
          >
            <Radar className="h-3.5 w-3.5 text-rose-400 animate-pulse" />
            <span className="font-bold">Security Radar & Satellites</span>
          </button>

          <button
            id="nav-tab-email"
            onClick={() => onSelectTab("email")}
            className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
              currentTab === "email"
                ? "bg-gradient-to-r from-sky-500 via-indigo-600 to-emerald-500 text-white shadow-md shadow-sky-600/30 font-bold"
                : "text-sky-300 hover:bg-slate-800/80 hover:text-white"
            }`}
          >
            <Mail className="h-3.5 w-3.5 text-sky-400 animate-pulse" />
            <span className="font-bold">📬 Email System (georgefelixegwu@gmail.com)</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
