import React, { useState, useEffect } from "react";
import { usePWAInstall } from "../hooks/usePWAInstall";
import {
  Smartphone,
  Download,
  Share,
  PlusSquare,
  X,
  Check,
  QrCode,
  ExternalLink,
  ChevronDown,
  Sparkles,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";

interface MobileInstallBannerProps {
  onDismiss?: () => void;
}

export const MobileInstallBanner: React.FC<MobileInstallBannerProps> = ({ onDismiss }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSModal, setShowIOSModal] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [isDismissed, setIsDismissed] = useState(() => {
    try {
      return sessionStorage.getItem("heoflix_pwa_banner_dismissed") === "true";
    } catch {
      return false;
    }
  });

  const appUrl = typeof window !== "undefined" ? window.location.href : "https://ais-pre-ysqnqaqjsxiadsjdlf6jkp-550800810293.europe-west2.run.app";

  if (isInstalled || isDismissed) {
    return null;
  }

  const handleDismiss = () => {
    setIsDismissed(true);
    try {
      sessionStorage.setItem("heoflix_pwa_banner_dismissed", "true");
    } catch {
      // ignore
    }
    if (onDismiss) onDismiss();
  };

  const handleInstallClick = () => {
    if (isInstallable) {
      install();
    } else if (isIOS) {
      setShowIOSModal(true);
    } else {
      setShowIOSModal(true);
    }
  };

  return (
    <>
      {/* Prominent Mobile Screen Install Floating Dock */}
      <aside
        id="mobile-screen-install-banner"
        aria-label="Add to Mobile Screen banner"
        className="fixed bottom-4 inset-x-3 sm:inset-x-auto sm:right-6 sm:max-w-md z-40 rounded-2xl border border-sky-500/40 bg-slate-900/95 backdrop-blur-xl p-3.5 sm:p-4 shadow-2xl shadow-sky-950/80 animate-in slide-in-from-bottom duration-300"
      >
        <div className="flex items-start gap-3">
          {/* App Icon */}
          <div className="relative w-11 h-11 rounded-xl bg-gradient-to-tr from-sky-400 via-indigo-600 to-emerald-400 p-[1.5px] shadow-lg shadow-sky-500/25 shrink-0">
            <div className="w-full h-full rounded-xl bg-slate-950 flex items-center justify-center font-black text-white text-base">
              <span className="bg-gradient-to-r from-sky-400 to-emerald-400 bg-clip-text text-transparent">H</span>
            </div>
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
          </div>

          {/* Details */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between gap-1">
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs font-black text-white tracking-tight">Add HEOFLIX on Mobile</h4>
                <span className="rounded bg-sky-500/20 px-1.5 py-0.2 text-[9px] font-extrabold text-sky-300 border border-sky-500/30">
                  PWA
                </span>
              </div>
              <button
                onClick={handleDismiss}
                className="text-slate-400 hover:text-white p-0.5 rounded transition cursor-pointer"
                title="Dismiss banner"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            <p className="text-[11px] text-slate-300 mt-0.5 line-clamp-1">
              Tap to install on your phone's home screen for full-screen native experience.
            </p>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 mt-2.5">
              <button
                id="btn-banner-add-to-mobile"
                onClick={handleInstallClick}
                className="flex-1 py-1.5 px-3 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-xs shadow-md shadow-sky-500/20 flex items-center justify-center gap-1.5 transition active:scale-[0.98] cursor-pointer"
              >
                {isInstallable ? (
                  <>
                    <Download className="w-3.5 h-3.5" />
                    <span>Install App</span>
                  </>
                ) : (
                  <>
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>Add to Mobile Screen</span>
                  </>
                )}
              </button>

              <button
                id="btn-banner-qr-code"
                onClick={() => setShowQRModal(true)}
                className="p-1.5 rounded-xl border border-slate-700 bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                title="Scan QR code on mobile camera"
              >
                <QrCode className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* iOS Safari / Mobile Step-by-Step Instructions Modal */}
      {showIOSModal && (
        <div
          id="modal-ios-add-to-home-screen"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in"
        >
          <div className="relative w-full max-w-sm rounded-3xl border border-sky-500/40 bg-gradient-to-b from-slate-900 to-slate-950 p-6 shadow-2xl text-slate-100">
            <button
              onClick={() => setShowIOSModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-xl hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-sky-400 to-indigo-600 flex items-center justify-center font-black text-white text-base shadow-lg shadow-sky-500/25">
                H
              </div>
              <div>
                <h3 className="font-extrabold text-white text-sm">Add to iPhone / Android Screen</h3>
                <p className="text-[11px] text-slate-400">Launch in standalone app mode</p>
              </div>
            </div>

            {/* Interactive 3-Step Guide */}
            <div className="mt-4 space-y-3">
              <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60">
                <div className="w-7 h-7 rounded-xl bg-sky-500/20 text-sky-400 font-bold text-xs flex items-center justify-center shrink-0">
                  1
                </div>
                <div className="text-xs">
                  <span className="font-bold text-white block">Tap the Share Icon</span>
                  <span className="text-slate-300 text-[11px] flex items-center gap-1 mt-0.5">
                    In Safari bottom bar, tap <Share className="w-3.5 h-3.5 text-sky-400 inline" /> (or Chrome menu <span className="font-bold text-white">⋮</span>).
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60">
                <div className="w-7 h-7 rounded-xl bg-indigo-500/20 text-indigo-400 font-bold text-xs flex items-center justify-center shrink-0">
                  2
                </div>
                <div className="text-xs">
                  <span className="font-bold text-white block">Select "Add to Home Screen"</span>
                  <span className="text-slate-300 text-[11px] flex items-center gap-1 mt-0.5">
                    Scroll down the sheet and tap <PlusSquare className="w-3.5 h-3.5 text-emerald-400 inline" /> <strong>Add to Home Screen</strong>.
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60">
                <div className="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold text-xs flex items-center justify-center shrink-0">
                  3
                </div>
                <div className="text-xs">
                  <span className="font-bold text-white block">Tap "Add" in Top-Right</span>
                  <span className="text-slate-300 text-[11px] mt-0.5 block">
                    The official HEOFLIX app emblem is now on your mobile home screen with instant access!
                  </span>
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-5 space-y-2">
              <button
                onClick={() => setShowIOSModal(false)}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-xs shadow-md transition cursor-pointer"
              >
                I Understand / Got It
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QR Code Modal for Desktop-to-Mobile Instant Pairing */}
      {showQRModal && (
        <div
          id="modal-mobile-qr-code"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in"
        >
          <div className="relative w-full max-w-sm rounded-3xl border border-sky-500/40 bg-gradient-to-b from-slate-900 to-slate-950 p-6 shadow-2xl text-slate-100 text-center">
            <button
              onClick={() => setShowQRModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-xl hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="mx-auto w-12 h-12 rounded-2xl bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400 mb-3">
              <QrCode className="w-6 h-6" />
            </div>

            <h3 className="font-extrabold text-white text-base">Open on Your Phone</h3>
            <p className="text-xs text-slate-300 mt-1 max-w-xs mx-auto">
              Scan with your iPhone or Android camera to open and install directly to your home screen:
            </p>

            {/* Generated QR Code preview using SVG matrix */}
            <div className="my-5 p-4 rounded-2xl bg-white mx-auto w-48 h-48 flex items-center justify-center shadow-lg">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
                  appUrl
                )}&color=0f172a&bgcolor=ffffff`}
                alt="Scan to open on mobile"
                className="w-full h-full object-contain"
                onError={(e) => {
                  // Fallback if network offline
                  e.currentTarget.style.display = "none";
                }}
              />
            </div>

            <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-[10px] text-sky-300 font-mono break-all select-all">
              {appUrl}
            </div>

            <button
              onClick={() => {
                navigator.clipboard.writeText(appUrl);
                alert("URL copied to clipboard! Open in Safari or Chrome on your mobile phone.");
              }}
              className="mt-3 w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition cursor-pointer"
            >
              Copy Mobile Link
            </button>
          </div>
        </div>
      )}
    </>
  );
};
