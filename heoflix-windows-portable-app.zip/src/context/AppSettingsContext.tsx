import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { AppSettings, ThemeMode, BrandIconChoice, UiDensity, FontScale, CurrencyChoice } from "../types";

const DEFAULT_SETTINGS: AppSettings = {
  themeMode: "neuro_dark",
  brandIcon: "neuro_tricolor",
  accentGlow: "tricolor",
  uiDensity: "comfortable",
  fontScale: "normal",
  motionEffects: true,
  soundEffects: true,
  autoMonetizationSpeedSec: 15,
  defaultCurrency: "USD",
  interlinkedFunctions: {
    marketExchangeSync: true,
    videoYieldHarvestingSync: true,
    treasuryAutoAccrualSync: true,
    planetaryDefenseSentinelSync: true,
    cortexAiBrainSync: true,
  },
  liveInterlinkStats: {
    activeSyncNodes: 5,
    syncLatencyMs: 12,
    overallThroughput: "99.98%",
    lastSyncTimestamp: new Date().toISOString(),
    healthStatus: "OPTIMAL",
  },
  lastUpdated: new Date().toISOString(),
};

interface AppSettingsContextType {
  settings: AppSettings;
  isLoading: boolean;
  isSaving: boolean;
  updateSettings: (partial: Partial<AppSettings> | any) => Promise<boolean>;
  resetSettings: () => Promise<boolean>;
  refreshSettings: () => Promise<void>;
  toggleInterlink: (key: keyof AppSettings["interlinkedFunctions"]) => Promise<void>;
}

const AppSettingsContext = createContext<AppSettingsContextType | undefined>(undefined);

export const AppSettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const cached = localStorage.getItem("heoflix_app_settings");
      if (cached) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(cached) };
      }
    } catch {}
    return DEFAULT_SETTINGS;
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Apply settings to DOM (Theme, Density, Font, Icon)
  useEffect(() => {
    try {
      const root = document.documentElement;
      
      // Theme Mode
      root.setAttribute("data-theme", settings.themeMode);
      
      // UI Density
      root.setAttribute("data-density", settings.uiDensity);
      
      // Font Scale
      root.setAttribute("data-font-scale", settings.fontScale);

      // Accent Glow
      root.setAttribute("data-accent", settings.accentGlow);

      // Dynamically update favicon if brandIcon is neuro_tricolor
      const faviconLink = document.querySelector("link[rel*='icon']") as HTMLLinkElement | null;
      if (faviconLink) {
        faviconLink.href = "/icon.svg?v=" + Date.now();
      }

      // Persist in localStorage
      localStorage.setItem("heoflix_app_settings", JSON.stringify(settings));
    } catch (err) {
      console.error("Failed to apply app settings to DOM:", err);
    }
  }, [settings]);

  // Fetch initial settings from server API
  const refreshSettings = async () => {
    try {
      const res = await fetch("/api/v1/settings");
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.settings) {
          setSettings((prev) => ({
            ...prev,
            ...data.settings,
          }));
        }
      }
    } catch {
      // Fallback to local state if offline
    }
  };

  useEffect(() => {
    refreshSettings();
  }, []);

  const updateSettings = async (partial: Partial<AppSettings> | any): Promise<boolean> => {
    setIsSaving(true);
    const updated = {
      ...settings,
      ...partial,
      lastUpdated: new Date().toISOString(),
    };

    setSettings(updated);

    try {
      const res = await fetch("/api/v1/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(partial),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.settings) {
          setSettings(data.settings);
        }
        return true;
      }
    } catch {
      // Optimistic update retained locally
    } finally {
      setIsSaving(false);
    }
    return true;
  };

  const resetSettings = async (): Promise<boolean> => {
    setIsSaving(true);
    setSettings(DEFAULT_SETTINGS);
    try {
      const res = await fetch("/api/v1/settings/reset", { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        if (data.settings) setSettings(data.settings);
      }
      return true;
    } catch {
      return false;
    } finally {
      setIsSaving(false);
    }
  };

  const toggleInterlink = async (key: keyof AppSettings["interlinkedFunctions"]) => {
    const updatedInterlinks = {
      ...settings.interlinkedFunctions,
      [key]: !settings.interlinkedFunctions[key],
    };
    await updateSettings({ interlinkedFunctions: updatedInterlinks });
  };

  return (
    <AppSettingsContext.Provider
      value={{
        settings,
        isLoading,
        isSaving,
        updateSettings,
        resetSettings,
        refreshSettings,
        toggleInterlink,
      }}
    >
      {children}
    </AppSettingsContext.Provider>
  );
};

export const useAppSettings = (): AppSettingsContextType => {
  const context = useContext(AppSettingsContext);
  if (!context) {
    throw new Error("useAppSettings must be used within an AppSettingsProvider");
  }
  return context;
};
