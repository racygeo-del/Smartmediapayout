import { Request, Response, Router } from "express";
import crypto from "crypto";
import { CryptoPayoutOrder } from "../types";

export function createCryptoPayoutApiRouter(walletState: any, transactionsState: any[]): Router {
  const router = Router();

  // In-memory Crypto API Keys
  let cryptoApiKeys: any[] = [
    {
      keyId: "cp_key_prod_01",
      apiKey: "cp_live_a89f21b409c8241e73a019485b02f9c4",
      type: "LIVE",
      label: "Automated Sovereign Payout Bot & Treasury Liquidity",
      permissions: ["payout:send", "payout:batch", "rates:read", "transactions:read"],
      createdAt: new Date(Date.now() - 86400000 * 20).toISOString(),
      lastUsedAt: new Date(Date.now() - 180000).toISOString(),
      dailyLimitUsd: 500000,
      multiSigRequired: true,
      status: "ACTIVE",
    },
    {
      keyId: "cp_key_test_01",
      apiKey: "cp_test_301b8924f0c8471a91e84029b3f140de",
      type: "TEST",
      label: "Staging Testnet Payout Worker Key",
      permissions: ["payout:send", "rates:read"],
      createdAt: new Date(Date.now() - 86400000 * 45).toISOString(),
      lastUsedAt: new Date(Date.now() - 7200000).toISOString(),
      dailyLimitUsd: 10000,
      multiSigRequired: false,
      status: "ACTIVE",
    },
  ];

  // In-memory Crypto Payout Transactions Ledger
  let payoutOrders: CryptoPayoutOrder[] = [
    {
      id: "cp_order_98124",
      network: "BITCOIN",
      token: "BTC",
      recipientAddress: "34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW",
      recipientName: "Primary Sovereign Bitcoin Vault",
      amount: 0.25,
      amountUsd: 16250.0,
      fee: 0.00015,
      status: "CONFIRMED",
      txid: "e4a8b792c019485b02f9c4a89f21b409c8241e73a019485b02f9c4a89f21b409",
      timestamp: new Date(Date.now() - 3600000 * 5).toISOString(),
      explorerUrl: "https://mempool.space/tx/e4a8b792c019485b02f9c4a89f21b409c8241e73a019485b02f9c4a89f21b409",
      memo: "Automated Treasury Rebalance Payout",
    },
    {
      id: "cp_order_77190",
      network: "TRC20",
      token: "USDT",
      recipientAddress: "TYDny55a3Ksmk4V2dJ4K5VwU9qE2o3W6Vz",
      recipientName: "Cold Storage TRON Reserve",
      amount: 5000.0,
      amountUsd: 5000.0,
      fee: 1.0,
      status: "CONFIRMED",
      txid: "9c8241e73a019485b02f9c4a89f21b409c8241e73a019485b02f9c4a89f21b40",
      timestamp: new Date(Date.now() - 3600000 * 18).toISOString(),
      explorerUrl: "https://tronscan.org/#/transaction/9c8241e73a019485b02f9c4a89f21b409c8241e73a019485b02f9c4a89f21b40",
      memo: "Cold Storage Liquidity Allocation",
    },
  ];

  // 1. GET STATUS & NETWORK CAPABILITIES
  router.get("/status", (_req: Request, res: Response) => {
    res.json({
      success: true,
      infrastructure: {
        name: "HEOFLIX Enterprise Crypto Payout & Liquidity Rail",
        version: "v5.1-AUTONOMOUS-BROADCAST",
        status: "OPERATIONAL",
        supportedNetworks: [
          { network: "BITCOIN", token: "BTC", standard: "Native SegWit & Taproot", avgTime: "10-20 min" },
          { network: "TRC20", token: "USDT", standard: "TRON TRC-20", avgTime: "30 sec" },
          { network: "ERC20", token: "USDT / USDC", standard: "Ethereum ERC-20", avgTime: "1-2 min" },
          { network: "SOL", token: "USDC", standard: "Solana SPL Token", avgTime: "1.2 sec" },
          { network: "POLYGON", token: "USDT / USDC", standard: "Polygon PoS", avgTime: "15 sec" },
          { network: "ARBITRUM", token: "USDT / USDC", standard: "Arbitrum One Rollup", avgTime: "4 sec" },
        ],
        activeKeysCount: cryptoApiKeys.filter((k) => k.status === "ACTIVE").length,
        totalDisbursedUsd: payoutOrders.reduce((sum, p) => sum + p.amountUsd, 0),
        payoutsCount: payoutOrders.length,
      },
    });
  });

  // 2. GET API KEYS
  router.get("/keys", (_req: Request, res: Response) => {
    res.json({
      success: true,
      count: cryptoApiKeys.length,
      keys: cryptoApiKeys,
    });
  });

  // 3. AUTOMATICALLY GENERATE CRYPTO PAYOUT API KEY
  router.post("/keys/generate", (req: Request, res: Response) => {
    const {
      type = "LIVE",
      label = "Generated Crypto Payout API Key",
      permissions = ["payout:send", "payout:batch", "rates:read", "transactions:read"],
      dailyLimitUsd = 250000,
      multiSigRequired = true,
    } = req.body || {};

    const prefix = type === "LIVE" ? "cp_live_" : "cp_test_";
    const rand = crypto.randomBytes(16).toString("hex");
    const newApiKeyStr = `${prefix}${rand}`;
    const newKeyId = `cp_key_${type.toLowerCase()}_${Date.now().toString(36)}`;

    const newKey = {
      keyId: newKeyId,
      apiKey: newApiKeyStr,
      type: type === "LIVE" ? "LIVE" : "TEST",
      label: String(label).trim(),
      permissions: Array.isArray(permissions) ? permissions : ["payout:send"],
      createdAt: new Date().toISOString(),
      lastUsedAt: "Never used",
      dailyLimitUsd: Number(dailyLimitUsd) || 250000,
      multiSigRequired: Boolean(multiSigRequired),
      status: "ACTIVE",
    };

    cryptoApiKeys.unshift(newKey);
    console.log(`[CRYPTO PAYOUT API] Automatically generated API Key: ${newKey.apiKey} (${newKey.label})`);

    res.status(201).json({
      success: true,
      message: `Crypto Payout API Key automatically generated for ${newKey.type} network broadcasting.`,
      key: newKey,
    });
  });

  // 4. REVOKE API KEY
  router.delete("/keys/:keyId", (req: Request, res: Response) => {
    const key = cryptoApiKeys.find((k) => k.keyId === req.params.keyId);
    if (!key) {
      return res.status(404).json({ success: false, error: "Crypto API Key not found." });
    }
    key.status = "REVOKED";
    res.json({ success: true, message: `Crypto API Key ${key.keyId} revoked.` });
  });

  // 5. GET AUTOMATICALLY GENERATED API DOCUMENTATION & INTERACTIVE CODE SNIPPETS
  router.get("/api-docs", (_req: Request, res: Response) => {
    const activeKey = cryptoApiKeys.find((k) => k.status === "ACTIVE" && k.type === "LIVE")?.apiKey || "cp_live_YOUR_KEY";

    res.json({
      success: true,
      openApiVersion: "3.0.3",
      info: {
        title: "HEOFLIX Crypto Payout Infrastructure API",
        version: "5.1.0",
        description: "Official, automated REST API to disburse programmatic cryptocurrency payouts across Bitcoin, TRON, Ethereum, and Solana networks.",
        contact: { email: "georgefelixegwu@gmail.com", url: "https://www.heoflix.com" },
      },
      authentication: {
        type: "Bearer Token or Header Authorization",
        headerName: "X-Crypto-Payout-Key",
        exampleHeader: `X-Crypto-Payout-Key: ${activeKey}`,
      },
      endpoints: [
        {
          method: "POST",
          path: "/send",
          summary: "Execute Single Crypto Payout",
          description: "Initiates immediate cryptographic payout broadcast to any public address with dynamic gas fee management.",
          parameters: {
            token: "BTC | USDT | USDC (required)",
            network: "BITCOIN | TRC20 | ERC20 | SOL | POLYGON | ARBITRUM",
            recipientAddress: "string (valid public address)",
            amount: "number (token amount)",
            amountUsd: "number (optional USD equivalent)",
            memo: "string (optional reference)",
          },
          curlSnippet: `curl -X POST https://www.heoflix.com/api/v1/crypto-payout/send \\
  -H "Content-Type: application/json" \\
  -H "X-Crypto-Payout-Key: ${activeKey}" \\
  -d '{
    "token": "USDT",
    "network": "TRC20",
    "recipientAddress": "TYDny55a3Ksmk4V2dJ4K5VwU9qE2o3W6Vz",
    "amount": 500.00,
    "memo": "Affiliate Commission Disbursement"
  }'`,
          nodeSnippet: `import axios from "axios";

const res = await axios.post("https://www.heoflix.com/api/v1/crypto-payout/send", {
  token: "BTC",
  network: "BITCOIN",
  recipientAddress: "34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW",
  amount: 0.05,
  memo: "Developer Bounty Payout"
}, {
  headers: { "X-Crypto-Payout-Key": "${activeKey}" }
});
console.log("Broadcasted TXID:", res.data.payout.txid);`,
          pythonSnippet: `import requests

url = "https://www.heoflix.com/api/v1/crypto-payout/send"
headers = {"X-Crypto-Payout-Key": "${activeKey}", "Content-Type": "application/json"}
payload = {
    "token": "USDT",
    "network": "TRC20",
    "recipientAddress": "TYDny55a3Ksmk4V2dJ4K5VwU9qE2o3W6Vz",
    "amount": 250.00
}
resp = requests.post(url, json=payload, headers=headers)
print("TXID:", resp.json()["payout"]["txid"])`,
          phpSnippet: `$ch = curl_init("https://www.heoflix.com/api/v1/crypto-payout/send");
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
  'token' => 'USDC',
  'network' => 'SOL',
  'recipientAddress' => '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU',
  'amount' => 100.00
]));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  'Content-Type: application/json',
  'X-Crypto-Payout-Key: ${activeKey}'
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
curl_close($ch);`,
          goSnippet: `package main

import (
  "bytes"
  "fmt"
  "net/http"
)

func main() {
  body := []byte(\`{"token": "BTC", "network": "BITCOIN", "recipientAddress": "34m9vsUB3f2TFZxCrXsJanaUJTJQEqEKTW", "amount": 0.01}\`)
  req, _ := http.NewRequest("POST", "https://www.heoflix.com/api/v1/crypto-payout/send", bytes.NewBuffer(body))
  req.Header.Set("Content-Type", "application/json")
  req.Header.Set("X-Crypto-Payout-Key", "${activeKey}")
  client := &http.Client{}
  res, _ := client.Do(req)
  fmt.Println("Crypto Payout Broadcast Status:", res.Status)
}`,
        },
        {
          method: "POST",
          path: "/batch",
          summary: "Execute Concurrent Batch Crypto Payouts",
          description: "Distributes funds concurrently to up to 100 addresses with unified gas fee bundling.",
          parameters: {
            payouts: "array of { recipientAddress, amount, token, network }",
          },
        },
      ],
    });
  });

  // 6. EXECUTE SINGLE CRYPTO PAYOUT
  router.post("/send", (req: Request, res: Response) => {
    const {
      token = "USDT",
      network = "TRC20",
      recipientAddress,
      recipientName = "Beneficiary Wallet",
      amount,
      amountUsd,
      memo = "Automated Crypto Payout API",
    } = req.body || {};

    const numAmt = parseFloat(amount);
    if (!recipientAddress || isNaN(numAmt) || numAmt <= 0) {
      return res.status(400).json({ success: false, error: "Valid recipientAddress and positive amount are required." });
    }

    const calculatedUsd = amountUsd ? parseFloat(amountUsd) : token === "BTC" ? numAmt * 65000 : numAmt;

    // Check wallet liquidity
    if (walletState && walletState.availableBalance < calculatedUsd) {
      return res.status(400).json({
        success: false,
        error: `Insufficient Dollar Wallet balance ($${walletState.availableBalance.toFixed(2)} USD available).`,
      });
    }

    const txid = crypto.randomBytes(32).toString("hex");
    const payoutId = `cp_order_${Date.now().toString(36)}`;

    let explorerUrl = `https://tronscan.org/#/transaction/${txid}`;
    if (network === "BITCOIN") explorerUrl = `https://mempool.space/tx/${txid}`;
    else if (network === "ERC20") explorerUrl = `https://etherscan.io/tx/0x${txid}`;
    else if (network === "SOL") explorerUrl = `https://solscan.io/tx/${txid}`;

    const newPayout: CryptoPayoutOrder = {
      id: payoutId,
      network,
      token,
      recipientAddress: String(recipientAddress).trim(),
      recipientName: String(recipientName).trim(),
      amount: numAmt,
      amountUsd: Number(calculatedUsd.toFixed(2)),
      fee: network === "TRC20" ? 1.0 : network === "BITCOIN" ? 0.0001 : 0.05,
      status: "CONFIRMED",
      txid,
      timestamp: new Date().toISOString(),
      explorerUrl,
      memo,
    };

    payoutOrders.unshift(newPayout);

    // Deduct from Dollar Wallet
    if (walletState) {
      walletState.totalBalance = Number((walletState.totalBalance - calculatedUsd).toFixed(2));
      walletState.availableBalance = Number((walletState.availableBalance - calculatedUsd).toFixed(2));
    }

    if (transactionsState) {
      transactionsState.unshift({
        id: `TX-CP-${Math.floor(1000 + Math.random() * 9000)}`,
        timestamp: new Date().toISOString(),
        type: "PUSH_CREDIT",
        title: `Crypto Payout (${numAmt} ${token}) to ${recipientAddress.slice(0, 8)}...`,
        amount: -calculatedUsd,
        status: "CLEARED",
        referenceId: txid.slice(0, 16),
        bankNetwork: `${network} Blockchain Network`,
        recipientAccount: recipientAddress,
        authMethod: "BIOMETRIC",
      });
    }

    res.status(200).json({
      success: true,
      message: `Crypto payout of ${numAmt} ${token} successfully broadcasted to ${network} blockchain!`,
      payout: newPayout,
      walletBalance: walletState?.availableBalance,
    });
  });

  // 7. EXECUTE BATCH PAYOUT
  router.post("/batch", (req: Request, res: Response) => {
    const { payouts = [] } = req.body || {};
    if (!Array.isArray(payouts) || payouts.length === 0) {
      return res.status(400).json({ success: false, error: "Please provide a non-empty array of payouts." });
    }

    const executed: CryptoPayoutOrder[] = [];
    let totalUsd = 0;

    for (const p of payouts) {
      const numAmt = parseFloat(p.amount);
      if (!p.recipientAddress || isNaN(numAmt) || numAmt <= 0) continue;

      const token = p.token || "USDT";
      const network = p.network || "TRC20";
      const calculatedUsd = p.amountUsd ? parseFloat(p.amountUsd) : token === "BTC" ? numAmt * 65000 : numAmt;
      const txid = crypto.randomBytes(32).toString("hex");

      let explorerUrl = `https://tronscan.org/#/transaction/${txid}`;
      if (network === "BITCOIN") explorerUrl = `https://mempool.space/tx/${txid}`;
      else if (network === "ERC20") explorerUrl = `https://etherscan.io/tx/0x${txid}`;
      else if (network === "SOL") explorerUrl = `https://solscan.io/tx/${txid}`;

      const order: CryptoPayoutOrder = {
        id: `cp_order_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
        network,
        token,
        recipientAddress: String(p.recipientAddress).trim(),
        recipientName: p.recipientName || "Batch Beneficiary",
        amount: numAmt,
        amountUsd: Number(calculatedUsd.toFixed(2)),
        fee: network === "TRC20" ? 1.0 : 0.05,
        status: "CONFIRMED",
        txid,
        timestamp: new Date().toISOString(),
        explorerUrl,
        memo: p.memo || "Batch Payout Run",
      };

      executed.push(order);
      totalUsd += calculatedUsd;
      payoutOrders.unshift(order);
    }

    if (walletState && totalUsd > 0) {
      walletState.totalBalance = Number((walletState.totalBalance - totalUsd).toFixed(2));
      walletState.availableBalance = Number((walletState.availableBalance - totalUsd).toFixed(2));
    }

    res.status(200).json({
      success: true,
      message: `Batch payout executed: ${executed.length} crypto transfers broadcasted ($${totalUsd.toFixed(2)} USD).`,
      count: executed.length,
      payouts: executed,
      walletBalance: walletState?.availableBalance,
    });
  });

  // 8. GET CRYPTO PAYOUT TRANSACTIONS
  router.get("/transactions", (_req: Request, res: Response) => {
    res.json({
      success: true,
      count: payoutOrders.length,
      transactions: payoutOrders,
    });
  });

  // 9. GET LIVE RATES & NETWORK FEES
  router.get("/rates", (_req: Request, res: Response) => {
    res.json({
      success: true,
      rates: {
        BTC_USD: 65000.0,
        ETH_USD: 3450.0,
        SOL_USD: 148.5,
        USDT_USD: 1.0,
        USDC_USD: 1.0,
        NGN_USD: 1550.0,
      },
      gasFees: {
        BITCOIN_SAT_VBYTE: 12,
        TRON_ENERGY_SUN: 420,
        SOLANA_LAMPORTS: 5000,
        ETHEREUM_GWEI: 14,
        POLYGON_GWEI: 32,
      },
      updatedAt: new Date().toISOString(),
    });
  });

  return router;
}
