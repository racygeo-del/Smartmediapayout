import { useState, useEffect } from "react";
import { getHmrState, subscribeHmrState, pingHmrEngine, HmrState } from "../utils/hmrManager";

export function useHmr() {
  const [state, setState] = useState<HmrState>(getHmrState());
  const [isPinging, setIsPinging] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeHmrState((newState) => {
      setState(newState);
    });

    // Initial ping to calculate real-world latency
    pingHmrEngine().catch(() => {});

    return () => {
      unsubscribe();
    };
  }, []);

  const triggerPing = async () => {
    setIsPinging(true);
    try {
      const res = await pingHmrEngine();
      return res.latencyMs;
    } finally {
      setIsPinging(false);
    }
  };

  return {
    ...state,
    isPinging,
    triggerPing,
  };
}
