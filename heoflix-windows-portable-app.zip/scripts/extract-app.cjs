const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");

const rootDir = path.resolve(__dirname, "..");
const outputDir = path.join(rootDir, "extracted-app");
const zipOutputPath = path.join(rootDir, "heoflix-windows-portable-app.zip");

console.log("[Extraction] Starting application extraction for Windows & Cross-Platform...");

const zip = new AdmZip();

// Files and folders to include in extraction
const itemsToInclude = [
  "src",
  "public",
  "scripts",
  "server.ts",
  "index.html",
  "package.json",
  "tsconfig.json",
  "tsconfig.node.json",
  "vite.config.ts",
  "metadata.json",
  "run-windows.bat",
  "install-node.bat",
  "start-windows.cmd",
  "start-windows.ps1",
  "README-WINDOWS.md",
  ".env.example",
];

// Ensure output directory exists
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

function copyRecursive(src, dest) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    const entries = fs.readdirSync(src);
    for (const entry of entries) {
      if (entry === "node_modules" || entry === ".git" || entry === "dist") continue;
      copyRecursive(path.join(src, entry), path.join(dest, entry));
    }
  } else {
    fs.copyFileSync(src, dest);
  }
}

let count = 0;
for (const item of itemsToInclude) {
  const fullPath = path.join(rootDir, item);
  if (fs.existsSync(fullPath)) {
    const stat = fs.statSync(fullPath);
    const destPath = path.join(outputDir, item);
    if (stat.isDirectory()) {
      zip.addLocalFolder(fullPath, item);
      copyRecursive(fullPath, destPath);
    } else {
      zip.addLocalFile(fullPath);
      fs.copyFileSync(fullPath, destPath);
    }
    count++;
    console.log(`[Extraction] Added ${item}`);
  }
}

// Write the standalone zip archive
zip.writeZip(zipOutputPath);

console.log(`[Extraction] SUCCESS! Extracted ${count} modules/files.`);
console.log(`[Extraction] Standalone Folder: ${outputDir}`);
console.log(`[Extraction] Portable ZIP Archive: ${zipOutputPath} (${(fs.statSync(zipOutputPath).size / 1024).toFixed(1)} KB)`);
