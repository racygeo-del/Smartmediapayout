const fs = require("fs");
const path = require("path");

const distPath = path.join(__dirname, "..", "dist");
const serverJsPath = path.join(__dirname, "..", "server.js");

try {
  if (fs.existsSync(distPath)) {
    fs.rmSync(distPath, { recursive: true, force: true });
    console.log("[Clean] Removed dist directory successfully.");
  }
  if (fs.existsSync(serverJsPath)) {
    fs.unlinkSync(serverJsPath);
    console.log("[Clean] Removed server.js successfully.");
  }
  console.log("[Clean] Windows & cross-platform clean completed.");
} catch (err) {
  console.error("[Clean] Warning during clean:", err.message);
}
